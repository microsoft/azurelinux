# Local Vitess Cluster

This directory contains example scripts to bring up a Vitess cluster on your
local machine, which may be useful for experimentation. These scripts can
also serve as a starting point for configuring Vitess into your preferred
deployment strategy or toolset.

See the [Run Vitess Locally](https://vitess.io/docs/tutorials/local/)
tutorial ("Start a Vitess cluster" section) for instructions on using these scripts.

