drop table customer;
drop table corder;
