CREATE TABLE IF NOT EXISTS are_you_alive_messages (
    page INT,
    message VARCHAR(255) NOT NULL,
    PRIMARY KEY (page)
)

