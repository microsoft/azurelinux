\! echo 'Using customer/0'
use customer/0;
\! echo 'Customer'
select * from customer;
\! echo 'COrder'
select * from corder;
