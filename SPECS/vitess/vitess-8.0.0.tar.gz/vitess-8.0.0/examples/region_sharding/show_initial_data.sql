use main;
select * from customer;
