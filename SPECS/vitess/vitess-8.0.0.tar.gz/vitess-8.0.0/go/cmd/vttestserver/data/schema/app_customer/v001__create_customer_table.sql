create table customers (
  id bigint,
  name varchar(64),
  age SMALLINT,
  primary key (id)
) Engine=InnoDB;

