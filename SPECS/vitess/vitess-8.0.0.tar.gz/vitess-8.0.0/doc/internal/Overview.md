# Internal Documentation

The documents in this category document internal processes which are taken care of by the Vitess Team e.g. re-publishing the website [vitess.io](https://vitess.io) or creating a new release.

We have put them here to increase transparency and make it easy for others to follow and improve processes.
