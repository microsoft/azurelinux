#!/bin/bash

docker run -p 15000:15000 -p 15001:15001 --rm -it vitess/local
