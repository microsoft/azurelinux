.. automodule :: nose.loader
   :members: