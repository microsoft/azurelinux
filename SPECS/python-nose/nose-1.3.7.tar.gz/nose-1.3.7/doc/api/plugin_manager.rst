.. automodule :: nose.plugins.manager
   :members: