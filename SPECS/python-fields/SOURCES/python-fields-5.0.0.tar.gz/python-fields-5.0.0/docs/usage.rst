=====
Usage
=====

To use Fields in a project::

	import fields
