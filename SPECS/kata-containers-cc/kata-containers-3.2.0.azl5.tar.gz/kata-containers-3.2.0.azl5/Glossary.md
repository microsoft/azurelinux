# Glossary

See the [project glossary hosted in the wiki](https://github.com/kata-containers/kata-containers/wiki/Glossary).
