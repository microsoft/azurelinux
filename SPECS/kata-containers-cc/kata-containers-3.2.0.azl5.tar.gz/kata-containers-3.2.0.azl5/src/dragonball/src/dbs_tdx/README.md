# dbs-tdx

This crate is a collection of modules that provides helpers and utilities to create a TDX Dragonball VM.

Currently this crate involves:
- tdx-ioctls

## Acknowledgement

Part of the code is derived from the [Cloud Hypervisor](https://github.com/cloud-hypervisor/cloud-hypervisor) project.

## License

This project is licensed under [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).
