# dbs-acpi

`dbs-acpi` provides ACPI data structures for VMM to emulate ACPI behavior.

## Acknowledgement

Part of the code is derived from the [Cloud Hypervisor](https://github.com/cloud-hypervisor/cloud-hypervisor) project.

## License

This project is licensed under [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).
