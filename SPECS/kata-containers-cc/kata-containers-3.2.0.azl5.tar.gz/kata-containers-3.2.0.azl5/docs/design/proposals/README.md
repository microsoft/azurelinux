# Design proposals

Kata Containers design proposal documents:

- [Kata Containers tracing](tracing-proposals.md)
