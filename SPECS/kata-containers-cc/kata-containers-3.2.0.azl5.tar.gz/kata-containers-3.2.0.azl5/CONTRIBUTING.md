# Contributing

## This repo is part of [Kata Containers](https://katacontainers.io)

For details on how to contribute to the Kata Containers project, please see the main [contributing document](https://github.com/kata-containers/community/blob/main/CONTRIBUTING.md).
