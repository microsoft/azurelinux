:orphan:

========
pip-list
========

Description
***********

.. pip-command-description:: list

Usage
*****

.. pip-command-usage:: list

Options
*******

.. pip-command-options:: list
