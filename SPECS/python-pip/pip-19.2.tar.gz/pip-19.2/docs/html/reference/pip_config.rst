
.. _`pip config`:

pip config
------------

.. contents::

Usage
*****

.. pip-command-usage:: config

Description
***********

.. pip-command-description:: config

Options
*******

.. pip-command-options:: config
