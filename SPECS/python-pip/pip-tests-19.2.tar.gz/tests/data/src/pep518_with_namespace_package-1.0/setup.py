from setuptools import setup

import simple_namespace.module


setup(
    name='pep518_with_namespace_package',
    version='1.0',
    py_modules=['pep518_with_namespace_package'],
)
