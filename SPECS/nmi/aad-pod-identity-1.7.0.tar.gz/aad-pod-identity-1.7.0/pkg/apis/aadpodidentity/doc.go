// +k8s:deepcopy-gen=package,register
// +groupName=aadpodidentity.k8s.io

package aadpodidentity
