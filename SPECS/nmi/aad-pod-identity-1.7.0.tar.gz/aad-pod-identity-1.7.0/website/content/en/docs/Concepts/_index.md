---
title: "Concepts"
linkTitle: "Concepts"
weight: 2
date: 2020-11-03
description: >
  The API of AAD Pod Identity CRDs and core components: Managed Identity Controller (MIC) and Node Managed Identity (NMI).
---
