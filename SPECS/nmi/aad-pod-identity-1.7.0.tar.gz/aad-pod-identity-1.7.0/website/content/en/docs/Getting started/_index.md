
---
title: "Getting Started"
linkTitle: "Getting Started"
weight: 1
date: 2020-10-04
description: >
  Setup the necessary role assignments on Azure before installing AAD Pod Identity.
---
