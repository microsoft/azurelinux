---
title: "Support"
linkTitle: "Support"
weight: 8
date: 2020-10-04
description: >
  aad-pod-identity is an open source project that is not covered by the Microsoft Azure support policy.
---

## Support

aad-pod-identity is an open source project that is [**not** covered by the Microsoft Azure support policy](https://support.microsoft.com/en-us/help/2941892/support-for-linux-and-open-source-technology-in-azure). [Please search open issues here](https://github.com/Azure/aad-pod-identity/issues), and if your issue isn't already represented please [open a new one](https://github.com/Azure/aad-pod-identity/issues/new/choose). The project maintainers will respond to the best of their abilities.