---
name: Feature request
about: Suggest an idea for AAD Pod Identity
title: ''
labels: enhancement
assignees: ''

---

**Describe the request**

**Explain why AAD Pod Identity needs it**

**Describe the solution you'd like**

**Describe alternatives you've considered**

**Additional context**
