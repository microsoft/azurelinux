# Application Gateway Ingress Controller Development Guide
Welcome to the Application Gateway Ingress Controller development guide!

## Table of contents
- [Understanding the architecture](design.md)
- [Building and running the controller](build.md)
- [Installing the latest nightly build](nightly.md)
- [Running tests](test.md)
- [Contribution Guidelines](contribute.md)