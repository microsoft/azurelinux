# Helm Repository

This is the helm repository for `ingress-azure`.

To add this repository

```bash
helm repo add application-gateway-kubernetes-ingress https://appgwingress.blob.core.windows.net/ingress-azure-helm-package/
helm repo update
```

For more information, please visit https://azure.github.io/application-gateway-kubernetes-ingress