Inspired by this: https://github.com/Azure/application-gateway-kubernetes-ingress/issues/528
