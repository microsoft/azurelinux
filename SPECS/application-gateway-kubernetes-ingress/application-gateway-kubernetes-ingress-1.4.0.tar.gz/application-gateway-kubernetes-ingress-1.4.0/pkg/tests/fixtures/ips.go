package fixtures

const (
	// DefaultIPName is a string constant.
	DefaultIPName = "appGatewayFrontendIP"
)
