=====
Usage
=====

To use Enhanced Sphinx theme (based on Python 3 docs) in a project::

	import sphinx_py3doc_enhanced_theme
