﻿
Authors
=======

* Ionel Cristian Mărieș - http://blog.ionelmc.ro
* Joel Frederico - https://github.com/joelfrederico
* Daniel Oaks - http://danieloaks.net/
* Matthias Geier - https://github.com/mgeier