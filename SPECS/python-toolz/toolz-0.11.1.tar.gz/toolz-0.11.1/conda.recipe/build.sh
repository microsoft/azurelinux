cd $RECIPE_DIR/..
$PYTHON setup.py install
