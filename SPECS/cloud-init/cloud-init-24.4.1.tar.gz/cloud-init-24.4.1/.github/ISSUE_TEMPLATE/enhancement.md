---
name: Enhancement
about: Functionality to improve cloud-init
title: "[enhancement]: "
labels: enhancement, new
---

# Enhancement

