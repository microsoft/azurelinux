# This file is part of cloud-init. See LICENSE file for license information.
