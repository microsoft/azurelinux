int assemble_map (struct multipath *, char *, int);
int disassemble_map (const struct _vector *, const char *, struct multipath *);
int disassemble_status (const char *, struct multipath *);
