py-cpuinfo
==========


Py-cpuinfo gets CPU info with pure Python. Py-cpuinfo should work
without any extra programs or libraries, beyond what your OS provides.
It does not require any compilation(C/C++, assembly, et cetera) to use.
It works with Python 2 and 3.

Documentation can be viewed here: https://github.com/workhorsy/py-cpuinfo
