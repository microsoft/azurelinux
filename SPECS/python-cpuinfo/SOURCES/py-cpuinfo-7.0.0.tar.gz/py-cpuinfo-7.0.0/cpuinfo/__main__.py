
import cpuinfo

cpuinfo.main()

