# Owners
This is the official list of the CNI network plugins owners:
- Bryan Boreham <bryan@weave.works> (@bboreham)
- Casey Callendrello <casey.callendrello@coreos.com> (@squeed)
- Dan Williams <dcbw@redhat.com> (@dcbw)
- Gabe Rosenhouse <grosenhouse@pivotal.io> (@rosenhouse)
- Matt Dupre <matt@tigera.io> (@matthewdupre)
- Stefan Junker <stefan.junker@coreos.com> (@steveeJ)