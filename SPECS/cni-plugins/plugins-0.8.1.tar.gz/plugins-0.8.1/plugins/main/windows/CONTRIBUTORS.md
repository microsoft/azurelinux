# Contributors
This is the official list of the Windows CNI network plugins contributors:
 - @rakelkar
 - @madhanrm
 - @thxCode
 - @nagiesek