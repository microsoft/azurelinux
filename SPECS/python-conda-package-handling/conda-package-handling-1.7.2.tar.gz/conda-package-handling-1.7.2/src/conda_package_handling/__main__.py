from conda_package_handling import cli

cli.cli()
