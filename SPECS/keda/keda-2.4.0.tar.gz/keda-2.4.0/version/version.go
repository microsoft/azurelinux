package version

var (
	// Version defines the current version of keda
	Version = "main"
	// GitCommit stores the current commit hash
	GitCommit string
)
