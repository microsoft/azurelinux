// This file is part of AsmJit project <https://asmjit.com>
//
// See asmjit.h or LICENSE.md for license and copyright information
// SPDX-License-Identifier: Zlib

#ifdef _WIN32
  #pragma pop_macro("min")
  #pragma pop_macro("max")
#endif
