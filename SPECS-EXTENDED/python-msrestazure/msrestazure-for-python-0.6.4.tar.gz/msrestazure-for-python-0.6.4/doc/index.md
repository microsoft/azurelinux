<meta http-equiv="refresh" content="0; url=https://docs.microsoft.com/python/api/msrestazure">
<meta name="robots" content="noindex, nofollow">

<a href="https://docs.microsoft.com/python/api/msrestazure">
    msrestazure's documentation has moved from ReadTheDocs to docs.microsoft.com.
</a>