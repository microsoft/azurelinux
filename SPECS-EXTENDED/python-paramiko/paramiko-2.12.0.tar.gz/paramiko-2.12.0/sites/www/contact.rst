=======
Contact
=======

You can get in touch with the developer & user community in any of the
following ways:

* Submit contributions on Github - see the :doc:`contributing` page.
* Follow ``@bitprophet`` on Twitter, though it's not a dedicated account and
  mostly just retweets funny pictures.
* Subscribe to the ``paramiko`` category on the developer's blog:
  http://bitprophet.org/categories/paramiko/
