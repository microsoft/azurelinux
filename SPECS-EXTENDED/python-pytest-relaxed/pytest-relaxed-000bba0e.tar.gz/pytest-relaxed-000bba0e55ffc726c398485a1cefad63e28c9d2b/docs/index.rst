.. include:: ../README.rst

.. toctree::
    :hidden:
    :glob:

    *
