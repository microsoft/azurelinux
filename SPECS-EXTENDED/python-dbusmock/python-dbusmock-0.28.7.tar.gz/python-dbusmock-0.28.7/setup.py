#!/usr/bin/python3
# this setup.py exists for the benefit of RPM builds. Doing that with PyPA build
# is completely busted still.

import setuptools

setuptools.setup()
