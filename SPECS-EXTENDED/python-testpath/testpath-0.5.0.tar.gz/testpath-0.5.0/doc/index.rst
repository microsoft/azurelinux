Testpath
========

Testpath is a collection of utilities for testing code which uses and
manipulates the filesystem and system commands.

Install it with::

    pip install testpath

Contents:

.. toctree::
   :maxdepth: 2

   fsasserts
   commands
   env
   tempdir

.. toctree::
   :maxdepth: 1

   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

