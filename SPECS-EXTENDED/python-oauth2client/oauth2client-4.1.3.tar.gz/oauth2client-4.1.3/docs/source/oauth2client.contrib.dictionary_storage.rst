oauth2client\.contrib\.dictionary\_storage module
=================================================

.. automodule:: oauth2client.contrib.dictionary_storage
    :members:
    :undoc-members:
    :show-inheritance:
