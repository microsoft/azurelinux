oauth2client\.contrib\.keyring\_storage module
==============================================

.. automodule:: oauth2client.contrib.keyring_storage
    :members:
    :undoc-members:
    :show-inheritance:
