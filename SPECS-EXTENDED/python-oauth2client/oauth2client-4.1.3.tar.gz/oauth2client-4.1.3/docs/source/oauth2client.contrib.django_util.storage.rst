oauth2client\.contrib\.django\_util\.storage module
===================================================

.. automodule:: oauth2client.contrib.django_util.storage
    :members:
    :undoc-members:
    :show-inheritance:
