# Thread lock API

::: fasteners.lock.ReaderWriterLock
