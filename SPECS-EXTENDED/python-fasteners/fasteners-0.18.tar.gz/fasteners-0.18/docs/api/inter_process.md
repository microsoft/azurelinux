# Process Lock API

::: fasteners.process_lock.InterProcessLock

::: fasteners.process_lock.InterProcessReaderWriterLock

## Decorators

::: fasteners.process_lock.interprocess_locked
    rendering:
        heading_level: 3

::: fasteners.process_lock.interprocess_read_locked
    rendering:
        heading_level: 3

::: fasteners.process_lock.interprocess_write_locked
    rendering:
        heading_level: 3