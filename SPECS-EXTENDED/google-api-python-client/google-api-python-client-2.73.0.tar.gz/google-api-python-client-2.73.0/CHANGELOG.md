# Changelog

## [2.73.0](https://github.com/googleapis/google-api-python-client/compare/v2.72.0...v2.73.0) (2023-01-17)


### Features

* **admob:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/80850422b5c225d999f37cdede5547b73c4e0a45 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **androidenterprise:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/ae317af4176b6639a2cec31a80b73f890e1024b6 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **appengine:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/83da6c96aa154cf40c9c7c49496bc48b8b4e511a ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **batch:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/f5c9ee7a3073dea2bb21b089eb875c2675d214c0 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **cloudtasks:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/68d13b309a3890ed461d9ba9f93302624e22201d ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **compute:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/1578648a093a30a08bfacdfab4c70f284ce5b7e4 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **content:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/dd3963ff2cfd590ddb27c7d4cb220a1bec7c4e44 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **dataform:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/568c18d3219ad85f7f7b57635323974ae4933376 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **datamigration:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/702672af09d5f192dac2d1101435751b7979916e ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **datastore:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/fde3afa51163848fad6e5499413762406451eb75 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **dialogflow:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/76b46ba298437c869ef537d75a59ceb956295904 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **discoveryengine:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/81172aee87d282fe9b4d883c39fb9d56532290fc ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **documentai:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/440c842065f0bb98b0d41507b02a515f35864d32 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **firestore:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/c38465229f960fab5143e69badb98e6643db7010 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **managedidentities:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/412d6af71d3c0d92083f955c8ce753105dd11198 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **metastore:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/ffa86c7057bf81ebcc5490413e7f360b755d5414 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **playdeveloperreporting:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/b65e1423dd93c9adb975a3543baaf2fd006c10d5 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **recommender:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/fb319564f354c11a06fd23eefaf80124f8f4af13 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **streetviewpublish:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/9a9bb5a7ce20698646f14b61eb1b869bd040c274 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **translate:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/480158858ff7590a2743c89d7a9918cdd72e5162 ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **vmmigration:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/853b007ed05e6c6c8075d1cf4aff3cb15d3df54b ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))
* **workstations:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/2cfb520b3524dd013d08e9c8b384073623c64e5d ([8543998](https://github.com/googleapis/google-api-python-client/commit/854399862e3e0a7bf1a1fb8af16ac5287ce568be))

## [2.72.0](https://github.com/googleapis/google-api-python-client/compare/v2.71.0...v2.72.0) (2023-01-10)


### Features

* **admin:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/f1139720b73c1ac9f840fb047a832d2a24a9de1e ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **baremetalsolution:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/32e6abbf80e0f20c9de5afbce7a36354ac86566b ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **blogger:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/9874c4a0d2813eea4e01d1bb179180a32b319520 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **chat:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/89266cd86905b84159869a27abfa52f3678127bc ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **chromemanagement:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/7dbad7dfe181cf00498525bc639c83bb2c26b2f1 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **chromepolicy:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/bba0a3b2f6c9ba480824ca7a5b0d524e1d8ced60 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **cloudidentity:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/ed8c25e19dcfe727343dd585e45bb14b4a827576 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **container:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/32269217419037596f5e44e801387183a5455fe5 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **contentwarehouse:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/8d85891c425e85f34d25b605079364998af2721e ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **datacatalog:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/a1778cbac5fb8d8bd4c7c1fd4f223909dd1557fa ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **dataflow:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/d41a6484a236399a74d5f092142534b871856b58 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **datapipelines:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/8b0a8c50339e4f995e34fd3a6d8af3d27b4ffa87 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **dataplex:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/677a1001d5fc8bb587d4a38562720e82d12b5804 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **dialogflow:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/b1ec06774cea4050a42b1c9bf79f50f9fa971e3c ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **displayvideo:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/8054c4fcb3adfb3f94ca0db636dbcd43491ed68b ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **file:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/057157a5c1b490330b99e168a6941fd175d96037 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **integrations:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/1a962ac3acb34b2ccca3fe9efa9548e343ac76d8 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **playintegrity:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/5ff792d937be384ad65cb2d40628a0255521e642 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **prod_tt_sasportal:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/13e911de2a94834f91cc96bfa755dc16d961b8c1 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **run:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/9c22354060eaa98f58eb63c4a9bdb05d79cb3c8c ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **sasportal:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/044e97c5d5a781ca06eb6efa86c400aee9120a0c ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))
* **texttospeech:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/2ea91bd43d7243f2ea89450fab32770d93cc0f91 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))


### Bug Fixes

* **bigquery:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/11e4350aa1de3105d1ab7c9f28038860714b1d37 ([e5e34bd](https://github.com/googleapis/google-api-python-client/commit/e5e34bd79d8fc11c3a7d0b4c2d2ec862268609fc))

## [2.71.0](https://github.com/googleapis/google-api-python-client/compare/v2.70.0...v2.71.0) (2022-12-20)


### Features

* **accesscontextmanager:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/038fdb69dcb6ea01f6eb56901ff0e76e6bbaf3ab ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **alertcenter:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/6057d89b613fb2a30ac2d26b90933ad0afa083d1 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **androidenterprise:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/ec22103603074d33ad2a41bed36debc63b3bb528 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **apigee:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/43f435c459205c8305f248efe78e6bd72a1b95c3 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **batch:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/3dd983b5616c058887d38e9423388d236acc27dc ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **clouddeploy:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/9a176a474cfd18a4b53d9b6b78bb432e6dd4cb0b ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **compute:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/bba3627ef5ae35a101b223b3da2739224e1598aa ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **container:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/98d6112970c5236cff5f36bf543a166ea27ca74c ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **contentwarehouse:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/00fa4bb30f92fdc325b23bd71b3ebd57fdcce4c7 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **datafusion:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/db1dddc7ca75258fde5cc59997599ce57ad8f01d ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **datamigration:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/12effe4a38299bb6f1fc61afeb1359200e9eff0b ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **datapipelines:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/91b60afaa437d7b29a96d83d3b89e3e855a81598 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **dataplex:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/04bafe3e118a1bbb2c75fc7f4e2e105f04bd4434 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **dataproc:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/1ad16fafbdfbf4d983112e5e811ea75f3727e67a ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **datastream:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/30f292141f98047d5acd526297f3f0e5bb79536e ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **firestore:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/89b34a91c7b56b03d59648bb582d3db1c5e06a4a ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **gmail:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/a4ca99c42e5c618e57071a800f49d784a0bb6eea ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **notebooks:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/f732fd307f07f53afc5344620456d0e662f81624 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **retail:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/d94dee346b3ae88d9d28bd97098bd2aba8093850 ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **speech:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/339a5d6c9cf9ecdcfe6c1ac33ae2ede71973584e ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **texttospeech:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/ee942d9363c422443d9ec24c0dac8e373b37721f ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))
* **workloadmanager:** Update the api https://togithub.com/googleapis/google-api-python-client/commit/93f0e30afae73ea3ce888783de0a6bf53604e40d ([a0329cc](https://github.com/googleapis/google-api-python-client/commit/a0329cc6488bb26a9de14c00c7244b7fadd4bfc3))

## [2.70.0](https://github.com/googleapis/google-api-python-client/compare/v2.69.0...v2.70.0) (2022-12-13)


### Features

* **appengine:** update the api https://togithub.com/googleapis/google-api-python-client/commit/f3ae3793e74aae883aa8f3bca7d2d75227c99cbd ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **bigquery:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9d8a28de9f2709a066cc62765132688f5a4eeba3 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/4b6ec2a405226f54a846e820be38c4be7e161df3 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **cloudbilling:** update the api https://togithub.com/googleapis/google-api-python-client/commit/6de2af2c211a03d3f9443a89f222c1953d6bec9b ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **cloudchannel:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bfbc1b18e9676ab2a7ef322c9ae2ff40bfc0c05e ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3ad8d540283d6153aeb7e7e5da043515fdd8feae ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **connectors:** update the api https://togithub.com/googleapis/google-api-python-client/commit/632cba551d23e3ac8c9044c56f1e3ebbce77ba1c ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **contactcenterinsights:** update the api https://togithub.com/googleapis/google-api-python-client/commit/6e512d6e138192e0312e44534b7904e95c36d0fe ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **container:** update the api https://togithub.com/googleapis/google-api-python-client/commit/05c853aec288828267afb32571d7f5ad8ac97cdf ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **contentwarehouse:** update the api https://togithub.com/googleapis/google-api-python-client/commit/720850e6a8a7cf0cd96170a3b82da993c2967b26 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **dataflow:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1b55a02805496e9431dbf173221958419400f905 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **dataproc:** update the api https://togithub.com/googleapis/google-api-python-client/commit/952d0d1df1ce352ec5d53d9d2eb4fa07629d3c62 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **documentai:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9e0a2601bc52633ff3e3f70800977724fd1f7e0b ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **gkehub:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e7a24b27433543dc8afd609bf6340a219456deef ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **ids:** update the api https://togithub.com/googleapis/google-api-python-client/commit/d7ca9ebf543d4cb3dbfae00a58862c7300466741 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **metastore:** update the api https://togithub.com/googleapis/google-api-python-client/commit/23800233fe99f56885846fdcd927801b5641b6d3 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **networksecurity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/5cd2d575dc6b58695c3c3f3d32424949f2189f0f ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **pubsublite:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ddc2cac9d91b7eb18421695895b41965c2658ac2 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **recaptchaenterprise:** update the api https://togithub.com/googleapis/google-api-python-client/commit/85bf9110ba2ab06d6cc22e8b6c4b7b74309ea0fd ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **servicenetworking:** update the api https://togithub.com/googleapis/google-api-python-client/commit/310a96ffbd7672f55acc62a129f54b98b46506d9 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **sts:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e5219026edb8f430f68775cf96e0195a39e1a613 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))
* **workflowexecutions:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3ff77236759bf338f5f295ae0e7453184bfbd745 ([1506e28](https://github.com/googleapis/google-api-python-client/commit/1506e28f20275c6313076ff1bde2dd0e4c729773))

## [2.69.0](https://github.com/googleapis/google-api-python-client/compare/v2.68.0...v2.69.0) (2022-12-08)


### Features

* **analyticsadmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1277148ed4bb16c03802a6d11bb15ab138bf6c19 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **assuredworkloads:** update the api https://togithub.com/googleapis/google-api-python-client/commit/0777a539623f6a0e5c0ee8a0014c49797e14a826 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **baremetalsolution:** update the api https://togithub.com/googleapis/google-api-python-client/commit/21f9266331d46ae55a4749d485d5937797d75c03 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **batch:** update the api https://github.com/googleapis/google-api-python-client/commit/5b1f5b056998a149f675ecdf8794563a9e9460fc ([f6e9d38](https://github.com/googleapis/google-api-python-client/commit/f6e9d3869ed605b06f7cbf2e8cf2db25108506e6))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/42d7975db499e1298a45b5d7ea086dddbfd3e5ec ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/ef1b5979776140ff203a53e82d0427ebda0112c0 ([f6e9d38](https://github.com/googleapis/google-api-python-client/commit/f6e9d3869ed605b06f7cbf2e8cf2db25108506e6))
* **cloudfunctions:** update the api https://togithub.com/googleapis/google-api-python-client/commit/27456f04a82bd30a897822da45adba98b00d0b73 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **cloudsearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2ebbbba9e1ceac8db6b3a90e56d00bad3c6183c5 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **cloudsupport:** update the api https://togithub.com/googleapis/google-api-python-client/commit/660300bb6094cdafa87016f16becc956489d723f ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **composer:** update the api https://togithub.com/googleapis/google-api-python-client/commit/b223e46fa38d9cabcf81b66ca78e9b1d4e88c01b ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/23ca08a7e9717d0aefff49823f4d594ed118ec25 ([f6e9d38](https://github.com/googleapis/google-api-python-client/commit/f6e9d3869ed605b06f7cbf2e8cf2db25108506e6))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2a5e985835d9e6a6eff7d88c2d8aac08fa4677df ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **content:** update the api https://togithub.com/googleapis/google-api-python-client/commit/93233da7ebde3542aaa004402c77bc19e6c919be ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **dataplex:** update the api https://togithub.com/googleapis/google-api-python-client/commit/714d395fa712c56f1d207e4408ca1a252fd3d162 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **dialogflow:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1d14a2f69b29855ec25b488babfbceb0609a519c ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **displayvideo:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1a3f64b4fd8e4f1774e1c6e6a70ad91a5a550590 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **gamesConfiguration:** update the api https://togithub.com/googleapis/google-api-python-client/commit/5e1872ea1691596119064e2d09043a99c15adac3 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **metastore:** update the api https://togithub.com/googleapis/google-api-python-client/commit/eba8d4f0e129812a600e4e8e6c33f4ab88c95180 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/cb568e1f19afa239b1b5dfbc1bc14554c130c15c ([f6e9d38](https://github.com/googleapis/google-api-python-client/commit/f6e9d3869ed605b06f7cbf2e8cf2db25108506e6))
* **networkmanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/c65d33b8ca6b2aa014bc39bd4ca32ed1e9ebd96c ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **paymentsresellersubscription:** update the api https://togithub.com/googleapis/google-api-python-client/commit/fd60e1157653d8b018ac093b01a32d3434148df4 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **securitycenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/c0c746a361421b6d250817f4d397d2c34dc2c4e9 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **servicemanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e3f20cd1141dd5ca47b2323eb0fa029e255c78ec ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **spanner:** update the api https://togithub.com/googleapis/google-api-python-client/commit/c2007c17ae0eb31027417903a034dbc98eade638 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/76c66c741eef394307e290ccad3dde13c950d2cf ([f6e9d38](https://github.com/googleapis/google-api-python-client/commit/f6e9d3869ed605b06f7cbf2e8cf2db25108506e6))
* **texttospeech:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bb64e3c504126472671203b1affec77396db89e7 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))
* **vmmigration:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3e1a2c94e7c20c7fef3f746bf40f74c06b7c2e29 ([fa65fca](https://github.com/googleapis/google-api-python-client/commit/fa65fcadac2a32844a78700c2395e4701b2701dc))


### Bug Fixes

* Fix media upload URI when API endpoint is overridden with client_opions.api_endpoint ([#1992](https://github.com/googleapis/google-api-python-client/issues/1992)) ([d0f8a05](https://github.com/googleapis/google-api-python-client/commit/d0f8a05b5c236f99d88fc6e0ef671a0a3eb58a4b))

## [2.68.0](https://github.com/googleapis/google-api-python-client/compare/v2.67.0...v2.68.0) (2022-11-30)


### Features

* Add support for Python 3.11 ([#1973](https://github.com/googleapis/google-api-python-client/issues/1973)) ([1106672](https://github.com/googleapis/google-api-python-client/commit/110667251e8b2c8852945bfe238f399742148cda))
* **androidmanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2dd64637ec67d4802fdee296a9c178cacf22d0d8 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/f9d3cb6e430faeb9b942b42de748efa166509f57 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **chromemanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/61558ed3f2924f8afa2aaba3a2485422fafda07a ([03f4753](https://github.com/googleapis/google-api-python-client/commit/03f4753bdb3476369592384dbd5fd7c90e6a94a6))
* **cloudasset:** update the api https://togithub.com/googleapis/google-api-python-client/commit/89473b2ca0e27fae3d1c6d7f92e16933f2829c88 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **cloudsearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e602008ba98c9c4daf5b68d4308fa99f47e4fee4 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **composer:** update the api https://togithub.com/googleapis/google-api-python-client/commit/626bf19259ba4717090b182ca20ad13b6acf40b3 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **contactcenterinsights:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ebb648aa643aad895798ff1aa58e051e2dd06bad ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **container:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9ccf94909892076fb071c1e79e10ea0973c49d71 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **datapipelines:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1dadbf77eea1fc5538643f876e7cecf36acc9318 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **dataplex:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2d0cd12f1711e71e58e1835341e269e339096e63 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **dns:** update the api https://togithub.com/googleapis/google-api-python-client/commit/c250e0e81554847ba62d663c3f3020aa677701b8 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **documentai:** update the api https://togithub.com/googleapis/google-api-python-client/commit/79ca84ab16a8cde17cdc0293c27f0e72b9cde5d5 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **securitycenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/86e1526a1de990a72eda1e52c2df8078b48fc973 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **serviceconsumermanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/51e6ed6970b305f0225d5fd07e0aa9fb776ffd02 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **servicenetworking:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3130518d7a1c2f3f787a1a9cbdd23c3018de8f59 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **serviceusage:** update the api https://togithub.com/googleapis/google-api-python-client/commit/7475ad606bad6f0fe5b8c95530e943df3ef322c8 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))
* **sqladmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bcc83f0b0cdd3646d37ae669dc3d1f04665e89bc ([03f4753](https://github.com/googleapis/google-api-python-client/commit/03f4753bdb3476369592384dbd5fd7c90e6a94a6))
* **testing:** update the api https://togithub.com/googleapis/google-api-python-client/commit/a456ae80c81a8a0baea7f3871dfc56cee625dd05 ([9b5767f](https://github.com/googleapis/google-api-python-client/commit/9b5767f0d652b4e82a6dd2459e268b4d5b2854ff))

## [2.67.0](https://github.com/googleapis/google-api-python-client/compare/v2.66.0...v2.67.0) (2022-11-16)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/96ecedffbedd0d4b415b5cc90c05766caac7e2ca ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **androiddeviceprovisioning:** update the api https://togithub.com/googleapis/google-api-python-client/commit/363d601fabed44b7e11f32e8b8cee65c7748b431 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/94d9e6788e02c6f04cb11f1f2b6f1bc778cd8786 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/6117c0bdff883ce31a96313f194129f845e3fbf3 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **artifactregistry:** update the api https://togithub.com/googleapis/google-api-python-client/commit/11a6e6cde55da8aa44592c76c95f4f93d220e815 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **bigtableadmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e16758ccc17a92ce0ebc17af3ab2066d9abf7d1c ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/d28f4691ede4d3ba50adaefd49438f5eb64d5851 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/1ccb2d454470aa5aa3806d9c53ba2c2c8d1c7516 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **cloudchannel:** update the api https://togithub.com/googleapis/google-api-python-client/commit/dadefbbe30afd0287c412e06ed41f5c336bc3d93 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **cloudidentity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/4ff3cd171f544d7bccb37fda1f560e8bc5377801 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/944c62bc66c5eed4772172e50ae77258aa81e94d ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **composer:** update the api https://togithub.com/googleapis/google-api-python-client/commit/610e7ee4e7eb2f934f1ea29a4b13012718d25ce3 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/574751c9c7bfc731b04f0421f3d5549bb9c926af ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9b7a7197983589a6d4e53f2f8ef301536e924ed8 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/3589f25b45b4a5b1e765481b7e250edb01dbdf89 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/3fa559427d9cfe7fd081630d7ed0ebfb9f593cc6 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/6e7b51629bfd1028a656a5d1c3fce5c85cbde574 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **container:** update the api https://togithub.com/googleapis/google-api-python-client/commit/29a50b8d8f3a35df57ff6926178ae53da6a3261e ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/d7b6c5f3e5a72dd063faae1d97509758efeed1a9 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **contentwarehouse:** update the api https://github.com/googleapis/google-api-python-client/commit/48d3f8e86129e8a80a9e9554b003b3ae2942918b ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **contentwarehouse:** update the api https://togithub.com/googleapis/google-api-python-client/commit/cc2b41c74bb0af1f18be50486a9102af35b666ec ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **datacatalog:** update the api https://togithub.com/googleapis/google-api-python-client/commit/57b9ac7c9a7a3aab667f9812152ff4c6e5c5a7dc ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **datamigration:** update the api https://github.com/googleapis/google-api-python-client/commit/d85e5f751bea54ffe6bdb2532d02f739c1eac55e ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/91e186b2f243be19153fe8124ccc92884a24677c ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/fd8a2fae079cd8d7fe618eeeadad7c08bcd58474 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **displayvideo:** update the api https://togithub.com/googleapis/google-api-python-client/commit/8ad115246f27fff444cfdc22f9173f2d4cff5cf6 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **dlp:** update the api https://togithub.com/googleapis/google-api-python-client/commit/31b8027abe2087c0fc8bbd83958f214c6e3c5874 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/01f65d3ef946dc9a45b240b90b3104c6bda31117 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **doubleclicksearch:** update the api https://github.com/googleapis/google-api-python-client/commit/4c4d21f7898530181d2b7990f0fbbe996572c5c6 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **drivelabels:** update the api https://togithub.com/googleapis/google-api-python-client/commit/73df6dd7e87cd4fedc4282a423140ce2caac7701 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **essentialcontacts:** update the api https://togithub.com/googleapis/google-api-python-client/commit/5279786e8a200f62f4ef0e5484d012c67e0cabde ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/2dfc188ffc3e17839ffb80e01f158743ca64dea9 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **gkehub:** update the api https://togithub.com/googleapis/google-api-python-client/commit/585c894fde715c514d196f7472fc074b6a4ad848 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/9e5ca02da86f708c78eff54221bb41aa39664719 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **identitytoolkit:** update the api https://github.com/googleapis/google-api-python-client/commit/57db5e8c72773e31ef303d347c3bab529fd78277 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/e4f5df0abe607ed2b7249c712cd2a645d5ad6569 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **mybusinesslodging:** update the api https://github.com/googleapis/google-api-python-client/commit/c2d35dea61cb6cf479fc0e185e6799b4317a63e2 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/7b734bdb36c0f7a8576a9911b24f58254f2dfd7d ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **networkconnectivity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/cffec44da93322cb7d73f9a2f54cfd0ec9ce5445 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **networkmanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/41509e63d36365d7b1c5a8b56bbdff8c89faee8d ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **policysimulator:** update the api https://github.com/googleapis/google-api-python-client/commit/355cf0bd45a94d7e599e98aca30b392d84df2ad9 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/0d068efa7806816c9eeac2bf8672886cda30458f ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/8c186950dd3698ef7d79ceabdad7b1f17d6ab080 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/213eb42ccf3a960dad445577bb0b76d56c26ab35 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **run:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bf0d06a0cf5ec92671018bfb0d458ee9668092b1 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **securitycenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1cfdc18b614e3769e137ba3c751122624aadc1a8 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/81eb1f2b883697e8978f3e4a6f7a18f444412f62 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/b51beb5e5948bf5efb0a14ad5c9a7c97341a39b0 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/c380036db6a825199d62fbc0098865922bba5572 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **vmmigration:** update the api https://togithub.com/googleapis/google-api-python-client/commit/53fdd26c30045b17960918d88acb032d645b5309 ([e4faf09](https://github.com/googleapis/google-api-python-client/commit/e4faf093d059688eb1a57689c2ac79563b61eaf5))


### Bug Fixes

* **cloudresourcemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/fe9086de83a6ed7c141a31dd94808e378bb2d4bd ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/221e1505c1507e105e08d2a7d38c45138e6dcc12 ([92fed84](https://github.com/googleapis/google-api-python-client/commit/92fed8464a1f667cbfe8470100a256bd17ee343d))

## [2.66.0](https://github.com/googleapis/google-api-python-client/compare/v2.65.0...v2.66.0) (2022-11-01)


### Features

* **alertcenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9a9b5adb894773c7754a85288b3dbe7c65caa354 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **androiddeviceprovisioning:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e3a929d4a0a89be6b2c9fe8a663028996d0dae3a ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **androidpublisher:** update the api https://togithub.com/googleapis/google-api-python-client/commit/98699752ee41ec202f226445056a22e6a4ce28a1 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **appengine:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3b4ebcfb140c65bd7c34d5ddb355e04152376e5a ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **artifactregistry:** update the api https://togithub.com/googleapis/google-api-python-client/commit/fe3896b0d7401e9a197971e4bbb449eddfe1cdb6 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **assuredworkloads:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3987df7506017aa40003b85d8553ccb29ff7fbc9 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **assuredworkloads:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ffbd7e4de8da5bf8e08b918ec6e9e6cd4abdd054 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **baremetalsolution:** update the api https://togithub.com/googleapis/google-api-python-client/commit/04b23d9cb93758f31467b465290b5077f0d9aec3 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **beyondcorp:** update the api https://togithub.com/googleapis/google-api-python-client/commit/98ef5fcf5173d711fa8f123156fd33ba7909561e ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **bigquery:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e7a8f0e6ad642160c10f1e094bca224a9c9467c0 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **bigtableadmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/4b424cf2d71fa9d77702efe543ba28ec31e30a49 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/39808f18b91b042b7999667be8f2dfcf2b499d32 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/75d4d8900a3b76c8fac5afd105859643e8adc22f ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **chromepolicy:** update the api https://togithub.com/googleapis/google-api-python-client/commit/53723bec0c1ce4961e1deaf4bfe0a91b97c65095 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **cloudbuild:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2712d19798c90bfc5ad0c669c400e59061591d21 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **cloudfunctions:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ef7b4070846752dadf0f44b065c1385c8d6e582b ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **cloudsearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/0724423a80fe35463249ffce4bfe560aec05be20 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **cloudtasks:** update the api https://togithub.com/googleapis/google-api-python-client/commit/b46ddfdbdb9f3c37308b09eb5361624a3169310f ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **composer:** update the api https://togithub.com/googleapis/google-api-python-client/commit/57822a710613ed77e524458441f1a8d57de8d95c ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/32386b1144d3bd9b7f51e9ce89b277ef90af7df9 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/6ef14bce9bdd661f91596e88648083845e7d9866 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **connectors:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bddbbf67262395894382da5fd44b402ec5eef15b ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **containeranalysis:** update the api https://togithub.com/googleapis/google-api-python-client/commit/d37d7c49987f14a068ee271fff172c41d32b5be6 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **content:** update the api https://togithub.com/googleapis/google-api-python-client/commit/94dde782a67a20cb7c28ca81e96726c3c7da36d0 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **contentwarehouse:** update the api https://togithub.com/googleapis/google-api-python-client/commit/0005b665c471cbba98a18df1c40d32fea0eb74a7 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **contentwarehouse:** update the api https://togithub.com/googleapis/google-api-python-client/commit/412a5247763d810107c0cd59e390fd42ce3513d0 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **datacatalog:** update the api https://togithub.com/googleapis/google-api-python-client/commit/25af7f8ed30583eaa03c3a8d41ad861f0ad0287c ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **dataplex:** update the api https://togithub.com/googleapis/google-api-python-client/commit/89c2a7df58b695b9c3eb7acff522e96bd4a5db1f ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **dataplex:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ca9cc14d9a1017e142ec1f287e66c79df276ce5f ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **dataproc:** update the api https://togithub.com/googleapis/google-api-python-client/commit/421f03b0652e95bfaf94e5969680498b48959833 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **dataproc:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ed3f0016c539d7af0706696543b01c8ba891681a ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **datastore:** update the api https://togithub.com/googleapis/google-api-python-client/commit/61b8061c19696958d3ee92d50a9d0a97eee3c2da ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **dialogflow:** update the api https://togithub.com/googleapis/google-api-python-client/commit/7c2479b010a193b03888508310bc823a277f8c5a ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **displayvideo:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ff9240b7e303916d24a13ae8b18116a6e3693c57 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **documentai:** update the api https://togithub.com/googleapis/google-api-python-client/commit/4a93526b97217bf4073289663ad030a7d732e1e4 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **doubleclicksearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/bfaf4b3a17d06cb612daf0392e1a3f25b460f847 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **drivelabels:** update the api https://togithub.com/googleapis/google-api-python-client/commit/522e74b34eb2472cdc54460c0bce68806c49d0f1 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **firestore:** update the api https://togithub.com/googleapis/google-api-python-client/commit/34e443e6ad3898b7ba902e58c7296eb172ac8230 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **gkehub:** update the api https://togithub.com/googleapis/google-api-python-client/commit/b0b59a978c4b6a6b03a8c5f2cd96214635728365 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **healthcare:** update the api https://togithub.com/googleapis/google-api-python-client/commit/8de48da07280f5a9e85423a96818f9785e5235a7 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **integrations:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e9280c5ffafccc928f311d3bf272ad099889613a ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **managedidentities:** update the api https://togithub.com/googleapis/google-api-python-client/commit/167f3d8cc7ac154dd705527dd0fbbb79fa39d6ff ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **managedidentities:** update the api https://togithub.com/googleapis/google-api-python-client/commit/aa5c6a2bbb967e47b1fe664f04d55cb77ee93850 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **metastore:** update the api https://togithub.com/googleapis/google-api-python-client/commit/72770adb32136579055168db9ee01e7506c9ff97 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **monitoring:** update the api https://togithub.com/googleapis/google-api-python-client/commit/aec2980b590813a9789221984a06d48cf5f93e37 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **networkconnectivity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2ae379c0d93c541e8a9ff968c54c48f2d9537e99 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **playintegrity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/15a8fe0e296f6b7f833f282b6fad96397d862989 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **redis:** update the api https://togithub.com/googleapis/google-api-python-client/commit/0b9b8fa1e76d9eae203e480becd7176f180fb0c8 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **retail:** update the api https://togithub.com/googleapis/google-api-python-client/commit/566f33e7ebe9290d81306b0a0b2b86b9357610bb ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **retail:** update the api https://togithub.com/googleapis/google-api-python-client/commit/606bdc24eebb7dc151bde794d4a1898446d11457 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **run:** update the api https://togithub.com/googleapis/google-api-python-client/commit/67d316d4d1108b899625adfd147acbc7e189a2ae ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **run:** update the api https://togithub.com/googleapis/google-api-python-client/commit/f0fdbaf02e95899481a795346cf1d2d4bde32552 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **servicecontrol:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3d8009279ecb0c9dfcaa76d08ab4722540bd6890 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **servicedirectory:** update the api https://togithub.com/googleapis/google-api-python-client/commit/aa20cbd8cddb3e7b85ec4d4595e3096796b5033f ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **speech:** update the api https://togithub.com/googleapis/google-api-python-client/commit/03f32f826408963c24793b93985d592fe746239c ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **sqladmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/488798ac2921276a33a74b54b7b62b93ef27c1e7 ([cb89554](https://github.com/googleapis/google-api-python-client/commit/cb89554f28463ce707081aee95244127e963cfdf))
* **tagmanager:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3dd7507c30d93ecb40587caa1043bd1db650e555 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))
* **translate:** update the api https://togithub.com/googleapis/google-api-python-client/commit/83da452f035a5656023a32151a1d0146d0ac3c90 ([60963d0](https://github.com/googleapis/google-api-python-client/commit/60963d0effc0be8ad41e72b661e1c0088a6a8e36))


### Documentation

* Fix a typo in UPGRADING.md related to static_discovery ([#1956](https://github.com/googleapis/google-api-python-client/issues/1956)) ([bc03ac6](https://github.com/googleapis/google-api-python-client/commit/bc03ac6840a32076f89aba84132eeaa2a729bf58))

## [2.65.0](https://github.com/googleapis/google-api-python-client/compare/v2.64.0...v2.65.0) (2022-10-18)


### Features

* **alertcenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/99b94eeb1cf0f695d921ac1d9081c0841f6b1693 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **analyticsadmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/41818c6eb42aa3551fc2a326208f9cc083cb1953 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **assuredworkloads:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9756c064a5cff42e367677216c48ff6649817dd5 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **chat:** update the api https://togithub.com/googleapis/google-api-python-client/commit/6dce01ba90d86496038bad226a14a9d714fb6e37 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **chromepolicy:** update the api https://togithub.com/googleapis/google-api-python-client/commit/180883247dcfcd777de04758a7928ca84e2764da ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **cloudbuild:** update the api https://togithub.com/googleapis/google-api-python-client/commit/555317bfb60133f8ff82d4ac28651631404980d4 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **cloudsearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2717d97f6ccd16b03f70adbb317fb330f74f3e2d ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **containeranalysis:** update the api https://togithub.com/googleapis/google-api-python-client/commit/322df84348b8765bc6dce442c5d03209963a0e6b ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **container:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ea99aeeb561642071866b71f54ae84be95ae5bcc ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **dlp:** update the api https://togithub.com/googleapis/google-api-python-client/commit/618362554c62d453579ff52933234a93ea5dfae3 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **doubleclicksearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1e7db3e4969b55ecf98bbb78d3edc53f4bf08a15 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **firebase:** update the api https://togithub.com/googleapis/google-api-python-client/commit/569cb7e362206b8a7563b689ccd720ed29259997 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **notebooks:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9ff1945acf3a74221759c2ceb9eb9a22c22b7c09 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **retail:** update the api https://togithub.com/googleapis/google-api-python-client/commit/32de4a02de0fd9e11755418f13c623f5b5c56674 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **securitycenter:** update the api https://togithub.com/googleapis/google-api-python-client/commit/b1c67c818d662fe97e82b000931be739766fbe55 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **tagmanager:** update the api https://togithub.com/googleapis/google-api-python-client/commit/188cd231f843aafb1c49cafe64052ec190e477a8 ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **verifiedaccess:** update the api https://togithub.com/googleapis/google-api-python-client/commit/e2dccf7393b2e15986b1ba88ea6aa2b4f621dc17 ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))


### Bug Fixes

* **prod_tt_sasportal:** update the api https://togithub.com/googleapis/google-api-python-client/commit/9000eddf5e2e22242ebc94cb0af60363ff5c41df ([5d54a7d](https://github.com/googleapis/google-api-python-client/commit/5d54a7debaa68277c556706598ddfe53b5bac4d7))
* **sasportal:** update the api https://togithub.com/googleapis/google-api-python-client/commit/36e8c8bc1b9cb3bbab1abdb2936d7a9cc9cea87a ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))
* **smartdevicemanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/f7cc8d243a3c6b16cdf7aafae285b2efbb65d1fc ([7110d89](https://github.com/googleapis/google-api-python-client/commit/7110d89d1a7018fc101ff98760450c098e6ab861))

## [2.64.0](https://github.com/googleapis/google-api-python-client/compare/v2.63.0...v2.64.0) (2022-10-04)


### Features

* **analyticsadmin:** update the api https://togithub.com/googleapis/google-api-python-client/commit/efb691ee5e2fd19dcd8ce99b02b04dc8bd4b7df5 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **assuredworkloads:** update the api https://togithub.com/googleapis/google-api-python-client/commit/6c5991727e9d02381db21f857646e778cf54e0d4 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **beyondcorp:** update the api https://togithub.com/googleapis/google-api-python-client/commit/1bbd2aa828e53f9939afd0d8119d62c89228ec6a ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **bigquery:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2ee419bab63b4a5984cab0636037cd3dcc1dd89e ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **certificatemanager:** update the api https://togithub.com/googleapis/google-api-python-client/commit/2fe105a191156da096820c0f2a0cbd725227e553 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **chromemanagement:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ec3508a2f33e3b1965f3977b8f32c9be90363b97 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **chromepolicy:** update the api https://togithub.com/googleapis/google-api-python-client/commit/f2478699397d683731136325d64d038abb8c0de6 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **cloudasset:** update the api https://togithub.com/googleapis/google-api-python-client/commit/a40c120368e20ae5956d688006afe2597988aced ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **cloudidentity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/8358d459d15087669fc9ecc691a4dca7b637df38 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **cloudsearch:** update the api https://togithub.com/googleapis/google-api-python-client/commit/fc29ead2fdfb4273cdc00cb7bd3f09dd50e37f51 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **cloudtasks:** update the api https://togithub.com/googleapis/google-api-python-client/commit/016214975099347cdc4870ce8e6d9b14bd2e7bd3 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **compute:** update the api https://togithub.com/googleapis/google-api-python-client/commit/703edfa4d3c78cbc184b190cc28214b0beb04f75 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **containeranalysis:** update the api https://togithub.com/googleapis/google-api-python-client/commit/404f0c97171a8ea968d7c04f350161729c5ea51b ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **dataflow:** update the api https://togithub.com/googleapis/google-api-python-client/commit/ff764b43fb1460be84361acd97d777524273902c ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **documentai:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3c5cb8204cddde3e98a5d1f715f20c042088acfc ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **driveactivity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/8be6614b72b681a129d4e63973ab825a88a5a860 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **firebasestorage:** update the api https://togithub.com/googleapis/google-api-python-client/commit/b4bda575312e64f6c3d007932533abdca1ef0210 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **monitoring:** update the api https://togithub.com/googleapis/google-api-python-client/commit/68d24a114ed9d8fdb71288d9e9699896a8c7e5a4 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **paymentsresellersubscription:** update the api https://togithub.com/googleapis/google-api-python-client/commit/3c1010ec174189184667846a5be38ebc491f7bd6 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **playintegrity:** update the api https://togithub.com/googleapis/google-api-python-client/commit/909483c18603a4ff6fb8f698cfdaea6dd180f098 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **recommender:** update the api https://togithub.com/googleapis/google-api-python-client/commit/359dea09eb0bed801549b18ce00829962d96da36 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **retail:** update the api https://togithub.com/googleapis/google-api-python-client/commit/fe492fe48af35dc21ce26029dac44a2606faf336 ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))
* **spanner:** update the api https://togithub.com/googleapis/google-api-python-client/commit/edc7eae706f45c562b01159f0bb6fa7338a27aba ([3bf7830](https://github.com/googleapis/google-api-python-client/commit/3bf7830e2f81bda9fb6e297e4f4a63d9ae47a1b6))

## [2.63.0](https://github.com/googleapis/google-api-python-client/compare/v2.62.0...v2.63.0) (2022-09-27)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/144cc44f83c5f4c685ddf538f3b2af8884c2679f ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/7700e75b5bcd5caacdedff92060bb1c921195b8b ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/6c1c8840a001b9a517eebf7ba94d0063cc65c6cf ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/38f6bdc02559e8c2c6b0b6aa673fc442f32ea912 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/aa4b0e13b0f19414dbbc69c8dcddbba8f5dcb0fd ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/c4be0100f273105c2c32f81b742909f58c444cae ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **chromeuxreport:** update the api https://github.com/googleapis/google-api-python-client/commit/4ec5814b3fc287669cc522ee2700a4c5767155d4 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/e58a7a14ea5e60ad022d44eb74cbf16bc7ced172 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/ba6cba013c8c2a312a3c23ea6d417ef9b0dbb474 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/4a3ac99611de5eb738473b0e1f1a12395abacd34 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/897fdef639aebd0cdcb740ca4ec3e86f7dd88d69 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/6a205afaed231dd686d703bc398355ce0ab25028 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/74c6fd58e4d767696db644c72a0dbc8eae585303 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **dfareporting:** update the api https://github.com/googleapis/google-api-python-client/commit/686052c0b808783b6cfb657d1e000397ae61d718 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/f648b88510fc1fab8f70ff994092385bcbf74948 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/e3e66ac69f7ece0b123dae3660afe384da6c3362 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/afd03ee211984f6fcac984b665d4d2136d2591d9 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/14020d79cffdf32dbe9e1ceba05e975ad1bbaee6 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **identitytoolkit:** update the api https://github.com/googleapis/google-api-python-client/commit/5311cf958ab3e52a87759d9329f242db980ce40a ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **language:** update the api https://github.com/googleapis/google-api-python-client/commit/1c0a0faa31007fae7319f6fdb08747eca2f8f174 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/6c2f068340abf51ae3e1c9f21bfd7a6ce312f7ad ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/5e7fcb9123b777e3ddd5965d8e5bf8147c481744 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/43ac616a1bad15634d03e94c3cc8c797cc383d2e ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/546cd30a23c433bcdd20dd09f3c7eae0719df1c4 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/58a7d6aecb461dff621cf2e489dbce563b8b60fc ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/47c7a75fb0f0be14309edd201d065677198480f3 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/e7668dfe076d22468fedada6a9bfcce4626a0dd5 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/f9760216c101a6b3290c64851f3bde11429a5b42 ([6e17850](https://github.com/googleapis/google-api-python-client/commit/6e17850df1cc6b3ed8a2e8d5d17ac5f082d59326))

## [2.62.0](https://github.com/googleapis/google-api-python-client/compare/v2.61.0...v2.62.0) (2022-09-20)


### Features

* **analyticshub:** update the api https://github.com/googleapis/google-api-python-client/commit/2cedffbb22a6e35606a4bfe2a53659d7eb51a29b ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/24238de0ec1217ab561bc2f2b036902a0a9dfdb3 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/997e916d31f872f46a547dbe01a7b934d78901a5 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/92ed528e52437f31f847b8707d7771fb94601f02 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/db416b5adeeb3798d51053d15954d4a9d4b2e742 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/a7eed1e84355a854288c0e4641c99ac9dcb936f3 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/70bd2645b516d85169c237d820c894f7c802f392 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/73b68e5ead37d294ba141c07242e509c32b9117b ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/4fe448c2aca8c375f15a9cab6376d9ebcce24bc9 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/6b5939f52dcea65745f975834ef15c50c3f138bf ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/34f565996691cfe1d9f7e9f591827814dbf892ef ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/29836a3a88e04b3504cea614522e931e5aa86ef7 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/bf6630520fceb9690b9231f1e8fbeb03f1a6f29c ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **identitytoolkit:** update the api https://github.com/googleapis/google-api-python-client/commit/9ab1181d09b6bb7164a690c362a7a1087a5b2316 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **manufacturers:** update the api https://github.com/googleapis/google-api-python-client/commit/d1c509547d0578b1703016a0da377cb220f623fe ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/a92bfb1c384b7c54b4e7fc8c4b08ea09226e724b ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/25a029df4f27696c9e13b6955deb1f5f3161fc75 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/62a1ccf9773b8de9ed9f582384d4f5182fd78104 ([4385b0d](https://github.com/googleapis/google-api-python-client/commit/4385b0db8af24676206727b2296d87bcc2decd95))

## [2.61.0](https://github.com/googleapis/google-api-python-client/compare/v2.60.0...v2.61.0) (2022-09-13)


### Features

* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/24f7278f5f09d8b8890a6544a4ffe854239aaa7c ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/88ef8471d4cd1fd30000f7a6941421473a95d8a2 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/5793c3d3595161e840b1ca89af2a0c00396afb88 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/acd95531ce44a62bb3c884982227af92a2f1418b ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/6bc396fb90a6dc61da7c87735e98044993ed6efb ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/0794f6273825c22bcdae0ab49e1f01142b77628a ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **cloudtasks:** update the api https://github.com/googleapis/google-api-python-client/commit/df6dd7698db9aadfbad3e94cbcbd14ca025d480c ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/1e5aef27cc4dda4516c3090c6ec62fdc29ade36b ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/a47cea3d9929175e4b20490cea8832fa870c7748 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/bf841ba0b4fb3ac4e9ca9f5a28a01a1b71fd887e ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/72c8848fa887fcbe9532e089b3b114de6a2fbbbc ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/2f0a662d081e42b1096490c2003b7c4c92ec1a51 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/bbb8a0f43f128568b1970d38237dc7d6be800b02 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/cf545d4f47d90d2bc6d967a83670c37d0f0e694a ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **orgpolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/cb5496625b9e489bf1e0b7d07ba5e2f83f96bf4d ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/e6983842f59a77c71fbd74e35711a404fe46e780 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/c2255c36a8920d5b985c7b54f5a32c8f6727c134 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/ac3899191d086f93f50dce37df83885a9f1f0cd5 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/04f2f52550577096297c5ee0ec90cdcad00d1d71 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/9e2a3910b5c84138c151044471443d76dce3358b ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **translate:** update the api https://github.com/googleapis/google-api-python-client/commit/8808b81d7457aa5c9eae4f3efec084cc60f01ed9 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))
* **workflowexecutions:** update the api https://github.com/googleapis/google-api-python-client/commit/4d868a7018905d402eaa6a7067283b67235748a6 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))


### Bug Fixes

* **tagmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/f640063261b5e31f228d70dc515f874cf2d825c9 ([92878d2](https://github.com/googleapis/google-api-python-client/commit/92878d2d8cc1e71939e464b7d439958345de0538))

## [2.60.0](https://github.com/googleapis/google-api-python-client/compare/v2.59.0...v2.60.0) (2022-09-06)


### Features

* **apigeeregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/a288244db58b3e799ee7d6dc6391f3e635af6425 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/a583aac925a0980c97799a5d6d1bba477685058b ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/e3f69d93fe1333c3c1c8d4c901c5f7da20317235 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/da659010678000dc1942947c04fac94d2cdb03ba ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/cf1029e74fafb84943f4146789177ae68b8c9650 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/12e0087aa75cdc1d5b8fb2411ce1f71ae7e92b82 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/114c935bd1c6cdf40d539968aa7efd8ecaf7acec ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/57e629a4a41da50e67ee3a894e535709c7d881ce ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/ea0a13677493daf63467aa43bb19a2e9c5210d27 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/a1a5231a7823aa576b1410dd11130b176307e0ea ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/a2684bdda5c51e505efbf94169736cc0b7fafd72 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **identitytoolkit:** update the api https://github.com/googleapis/google-api-python-client/commit/3641ad00fc35eb55c762a9a0bbf1cab37ffa6d10 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/d2139ca0f1500e5573b054a52c1705c6d427a609 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **playintegrity:** update the api https://github.com/googleapis/google-api-python-client/commit/423619b80449eee76e33dbf568b6e1cf6129ffbe ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/05e10458da67802924cc189fe3adbea0fdf7dba7 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **testing:** update the api https://github.com/googleapis/google-api-python-client/commit/a64a080d9b775bc77c2178fc14d4484046c1a0da ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))


### Bug Fixes

* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/9d0192788006f95b9a831500c3e5df957f6773f5 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))
* **policysimulator:** update the api https://github.com/googleapis/google-api-python-client/commit/9d29e554831eea21ae4736e7fdcb49f332d266e7 ([114bc5e](https://github.com/googleapis/google-api-python-client/commit/114bc5ea00cc110d3f76776a7a8ed2c7e98cd259))


### Documentation

* **samples:** Replace APPENGINE_RUNTIME with GAE_ENV ([#1893](https://github.com/googleapis/google-api-python-client/issues/1893)) ([af3160d](https://github.com/googleapis/google-api-python-client/commit/af3160d1d722a679071328cff7c0ecbd3af6fab5))

## [2.59.0](https://github.com/googleapis/google-api-python-client/compare/v2.58.0...v2.59.0) (2022-08-30)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/634da9d534b582f1382001ece93f7fd40efe36b6 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **analyticsdata:** update the api https://github.com/googleapis/google-api-python-client/commit/33270042624f4fb88a212834946da54407527faa ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/2b94b8215ce707c1f72c64aa43ace6c7717f651b ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/91232ae03ec95b808d91320a7b5a2c6b2544a1ed ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/86868a251879573359d0acdec887deffff4bfb8b ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/5e01e28387569a67b3476292c887b5ab74fada06 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **datamigration:** update the api https://github.com/googleapis/google-api-python-client/commit/414fb914320538feee8f273c831ef78d8ea8384c ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/e07157242d5382869351011a8d09b7e22283fbf4 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/df9734531f4b0affdb82e9f52ce7e620de0b2e1a ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/ed08e4d666e694f927ea2f6233cfc63c43662433 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **iap:** update the api https://github.com/googleapis/google-api-python-client/commit/3e79bd5b0a64f84e8a0a34ab09c79912a4bebb07 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/ebfd6dd2c109a375e398bff9880cfd525588b405 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **mybusinessplaceactions:** update the api https://github.com/googleapis/google-api-python-client/commit/c33cbe560d3bcf0c5923610df350869bbbf9e71a ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/3a33cab117cf34595d08f7390988d9ceea89b5b1 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/8bafc8e5daf828919569228207d727f4dd394a2b ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/ffeec4b8ca793c0f7e751a15c2ed88be8f29a6fb ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/61c11a22b48fb0fa5c189438869686d75d70c687 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/50e84559b2ecf96c943b266e713f136a4cda6794 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))


### Bug Fixes

* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/25769cc615e24898fb79b3e4dfbfdd3a15053ad2 ([fcbdcbf](https://github.com/googleapis/google-api-python-client/commit/fcbdcbfb3d57972feb29d33598cf2b1553e9760a))

## [2.58.0](https://github.com/googleapis/google-api-python-client/compare/v2.57.0...v2.58.0) (2022-08-23)


### Features

* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/c4fe80ae2f6433bffee06c09f233ca46d54ae986 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/783a01cb3ee2785ffb6b3e598b1bddb21706c894 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/dbd092e7fa9a3189b125a32c71d27e499ec005f8 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/90f98d13d11db9a6e690df9c0310eb5094479e41 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/187e71fdfe58d3b2833fc34a82b7eff2f4e4d467 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/67081e018d953f95e81456ca5ab5dca4e3bdc42c ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/f9b16e5ac6b1de335f5408c74c97901c2b40e889 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/d41a45060ba0f8e24ab25513c3ffcd84061013b6 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/072238b5d7586871069b7cf99f552a238e92d014 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/380907f0e9d2c11eae684876fff6336eb0755c8d ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/ca27b614293c77f6901578ccc4cf8646b4d514c4 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/82e05896571a953faf24453b236ee6b49455bd43 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/3e8252b8ad09c893153e7b91d0f5564597fbfd90 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/425521b94a49febd11ba9375c538f14c62537faa ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **orgpolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/c318440453b64108aca52b296b42c1dda04475e1 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **playintegrity:** update the api https://github.com/googleapis/google-api-python-client/commit/28a7dc83daaa8ce99bbf1d622c898826ee744a04 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/e326c357d61376c64aee08d0630ed9b9f5bb61a1 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **secretmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/956320a450d5b112b3c275fa8886f80f1e509631 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/de8b5b13744fcf98c647fb5664a4e88fffca07f6 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/dc2597a7d89b3f744b5c1b4476ffeafe960951bf ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/104f2af0cc2d36d43da57c7545f3fcc8c7f1cb3d ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/903bea9ded70c8977785086cced79faf438c275c ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **tagmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/27df08b5315c7cc38877aa898cb5fd3bd468fff1 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))
* **transcoder:** update the api https://github.com/googleapis/google-api-python-client/commit/7bd32cedfbe5fd31360cfd4363e54d278946eacb ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))


### Bug Fixes

* **dfareporting:** update the api https://github.com/googleapis/google-api-python-client/commit/802b87692eb73c5df5df39b91c6b50d8ef94b7d5 ([5471a41](https://github.com/googleapis/google-api-python-client/commit/5471a4104c1642e6167180d0fbe0425cf93406b7))

## [2.57.0](https://github.com/googleapis/google-api-python-client/compare/v2.56.0...v2.57.0) (2022-08-16)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/cc2547b9c19463890b69d4069ec2cbb10b425dd3 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/daf379ede87eb0a75e6b426ebaffced514a085b2 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/823cc8702fed1c73581589e60fcae81eaa2d475f ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/397bfe81c693a51deb6a3608f2642f7bee6d5072 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **certificatemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/f067d95dc4dfe814affe1a9cc6df8d55973ea5c5 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/d81242160ad8fc0c974b035b651d25410e2a6655 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/c602e9721e79101d5622a6bdd31ec1235fe5f789 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/3026a1f15f1286abea23c12b07393fe23d23130f ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/d5dae7023f6fcd9249142fa7bc0b115dcc6d5605 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/39419960c2aa454225e6a6cb86b71416cf81b410 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/32db7467f2acd8088a4d5ef10b84fd42e539aa74 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/ca129604e53e7ede837ddb123d9f5debc58d5b6d ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/6437135fadb435b6bb78daa4f6c62999078a0424 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/34dbb5159e7a183dc5223e2226cf553c017af591 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **manufacturers:** update the api https://github.com/googleapis/google-api-python-client/commit/9f3dc9dfcac9561064f1772af3f0e2efac48871e ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **mybusinessplaceactions:** update the api https://github.com/googleapis/google-api-python-client/commit/aa970e8b0429baaf99331e44a674bf70b1c1c6ad ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/d2c2f0d4ba83410862b3c043b762a016dff9ad1d ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/32dc147601805de7362a5cc20b203378ead62d26 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/cd4a8cc802340e7012d99140a418408c104aed3c ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **toolresults:** update the api https://github.com/googleapis/google-api-python-client/commit/0194ce51b2585a9c332d0abab1fb86e9e8dbb41a ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **translate:** update the api https://github.com/googleapis/google-api-python-client/commit/5bd2f6db6b99d976fd47c1f1120b6d63f3312986 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))
* **vision:** update the api https://github.com/googleapis/google-api-python-client/commit/b3117f3c141ac6d73134b54b4267a0fa19906cb9 ([b2ea631](https://github.com/googleapis/google-api-python-client/commit/b2ea63185433c10ced064045747f26b9f5adf42e))

## [2.56.0](https://github.com/googleapis/google-api-python-client/compare/v2.55.0...v2.56.0) (2022-08-09)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/69ac3be9c5e576e1422508be5924627fed9c7a05 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/125ef1daa47e6084dc1f12a1267e6f805ff42ac8 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/5d2a6dffbecf1ea194a65a5c1d73c1e2aa7547e1 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **authorizedbuyersmarketplace:** update the api https://github.com/googleapis/google-api-python-client/commit/b1e8c38bf32e5e1821072c5d8649b75f7cb8bd93 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/01d40f6a1c6f4cbe021c805f23c0ebacab596581 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **beyondcorp:** update the api https://github.com/googleapis/google-api-python-client/commit/41eb915e82395b7af54f84c2178dbe430e695478 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/9580b4d8f1a9354b685c674adecc7ec0f7906a3b ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **blogger:** update the api https://github.com/googleapis/google-api-python-client/commit/8a727f6ae9cc4fb031e6b9c23af05456639c8b19 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/042b80d1fd44a8ecacfb6f4c2bfeca4802c10642 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/b381018fff817fa297dc2cf840dcff67211a90e0 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/91fb06935fda2d69cbb81e41edd340c7402faef8 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/7463513e42840cf9a7f7459742aa650ff1050715 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/c5f6895d9c92b01a87160ff5744d71a95bce9428 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **cloudsupport:** update the api https://github.com/googleapis/google-api-python-client/commit/3c68638a25be3a207bc9a83ddd25748c4bd6b6fb ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/678d6aad609bb24ede5904ae6b429305d4becaad ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/506f96d2ebcfed759b46ac13a9d35d6ec2e5f9c1 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/f3207d67d73d53e513e4f3f47cdc7a7ead82e67a ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/ce8d53d131ddad2b28d2cc9b78672fcd4077b864 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/540292b10ca68bd6329b13709144816e12112037 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/e6503d33a6f27f5443ef02ad220e7ea2bbdf1f92 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/13d2f8acc00f589503f62bcc73ea824438073af2 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/7f5f751f93fad20f9c171d6c50c34c9855da9a47 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **gameservices:** update the api https://github.com/googleapis/google-api-python-client/commit/876284eba48a9ce1fa73148f4d56e13eca76a14f ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/98d28621d08e6aa11d70d6017ebdb43b0a859dce ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/331b5c0c21c2534b1eb6dbcc923f22664bc0b2a1 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/d5c8eb84ed2182cdf2d87e2ccc3d1bcb215a364d ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/929acf8b7ace5fd683ac00172f4b5211bcec7405 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/70e4256a58599727febbfb1a17b547e31b6cb6d8 ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))
* **servicedirectory:** update the api https://github.com/googleapis/google-api-python-client/commit/fa2c777d0558963539d712bd7849f8bc6a60b58c ([bef54ff](https://github.com/googleapis/google-api-python-client/commit/bef54ff8932f27be456bd6ad3f83fa14e663d1fa))


### Documentation

* Fix a few typos ([#1858](https://github.com/googleapis/google-api-python-client/issues/1858)) ([1040301](https://github.com/googleapis/google-api-python-client/commit/10403015d5b91c27c60dfb118430c1c471b40cf5))

## [2.55.0](https://github.com/googleapis/google-api-python-client/compare/v2.54.0...v2.55.0) (2022-07-26)


### Features

* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/66596c09a6b1d4ba31305ea243af6387fb8d7b36 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **androidenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/0213854b4eb39348120c630bc2144f5f01a3a059 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/16e5edeb2a31e7f43a253411e9cd356a63de4b78 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **beyondcorp:** update the api https://github.com/googleapis/google-api-python-client/commit/2cb54c8d6caf6cd14cd10c085980d555dd3c89ea ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/5d5705d05d55c9c10676c8a1baa9721a126a8c41 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/757d79e338ad0c21737a8ff8505755da0e1abc4c ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/b22e69a8c13c0a22b5ff4d630c6be6bb70986482 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/6df7615e883ddb46b7f27603037b1cb42c7dae91 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/922d704140967fd2c6d6ee9371e407f1930021f6 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/bba182faf7b25acc6b2fda3568f326a2d98dfb40 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/dfb3217102ca60e84a1c1e48cc8d0a1194aa1f6b ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/e7aecbf9b80906c5f6465fcbdb8d4b333e1a2fa4 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/73a9ebb623753cd34ec4064c1f5b8cffc0baa1f9 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **iap:** update the api https://github.com/googleapis/google-api-python-client/commit/aa98e5065ab458296173f0aef634a5f63f6034c2 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/7c1a73107ae2de899baace102408347f95b306e7 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/fb6bc73173f23b0e1e7c0c8b01b1ffe6bc3fef1a ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/f4231ebae9bd625fd7447223b0417d4bccad0359 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/14c35b66e69bd088327f696f79a625fcffa98980 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/0daa6e2510c66d462831fc227c8c88b4444f2d34 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/2545e9bbc65e0b6351d30301a4636dbdb3f0bc6d ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/57d8d5a234c33189c7ea2d8fe209ff074c5a3c82 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **streetviewpublish:** update the api https://github.com/googleapis/google-api-python-client/commit/af184b8521208e6cab1e1d29e71a98fd916d242b ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/34db6c376e7698180b897b9d90384304cd57533c ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/57b9539b1198e2db9ee04cc5c1df1893ab6360d4 ([4af699d](https://github.com/googleapis/google-api-python-client/commit/4af699d02c3c18dcd4f5d91a7052be3a8b43447c))

## [2.54.0](https://github.com/googleapis/google-api-python-client/compare/v2.53.0...v2.54.0) (2022-07-19)


### Features

* **apigeeregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/9f30db4e832cd1369273d7b9342fc7247029ba0a ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/166131a38dd2a09ed8005e6ace9227194ae013f2 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **certificatemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/318a536b3032d299194439a47fff3ae5a7b7201c ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/b5bb878f4559ba796ac1ec1624f0c27ae1e74a91 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/df983ba85172cc3f0ee1a99155c449e15b224285 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/f6b2cad08f7c87a5001023c85281e0c80a1e57ee ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/d4ea38ae66a3e3ae47ec93f25053a036dc65d113 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **cloudtasks:** update the api https://github.com/googleapis/google-api-python-client/commit/785511348f6ee00cc0b67c230c258067df4c65ef ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/0861cb7b948b7abb3dd0ac3d9482775ddb9e2564 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/afe85f56e58475e5a51ca46b1a0c8f304e3d1d38 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/05688d8cef0aa5bf91024e48b614d84103f35565 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/fc428158e1f9f98a7b3744087b66f4a9dc7f62a7 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/24b6a0e825f3f4f6e97bd9cff731d137c6a235a3 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/56fb20ac3ca019d21b94ae4c8db83e8e065a4bf3 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/a0d5f488f457dc3be364a573ce4e610b1923d790 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/7fdfb91f6723dea05af302b5b8ac089d2be5f808 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **mybusinessaccountmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/cb875b8ddaab637aadc187e1c25268d9633b39c8 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/68e45cdf1cce8a7be282369dc027113dc61c2d39 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/daf5183d0c6bdb2ae0a75be0a409171c2f26360d ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/9c5ed43310c474937f68e9911aac8f665cc2521b ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/bd1e2e47f90ed83daf4e6665684619d6e641a036 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/e344e6f08ebcef5a5a3139ffda9e2cd86eaa78b8 ([3b42d88](https://github.com/googleapis/google-api-python-client/commit/3b42d88fa264a213f2a8b1f66f7c5d0a140bcf4d))

## [2.53.0](https://github.com/googleapis/google-api-python-client/compare/v2.52.0...v2.53.0) (2022-07-14)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/cb666792405edbbc5abb17529ec3380d472f798c ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/2fb45288c36a1022f801309ea9c821ecef3cb7e3 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/287b57f81f204043bd7d19838f8592f21dab43e1 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/23680d4d09a44d8bd41cc751151bbfd2b19b68e0 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/ab77edbb8a75cddd3aa74b324329eed5b786c815 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **bigqueryconnection:** update the api https://github.com/googleapis/google-api-python-client/commit/8eda4b52d298dcd4cbde751edf7c73188b3d1078 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/fd8bc438c77b528a264c3211b6d9ebb25ac143ef ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/0672d42d4ecc68dddf73227ce5c6761c48e0ddec ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **cloudsupport:** update the api https://github.com/googleapis/google-api-python-client/commit/42e42fcdf7e739c620353fb58cf4bb50cf1c41d7 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/b088456cec0626de1dd2219a839c54db4fd6f32e ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/202ad0b1598de7e3551a417f84c8b806bd2369c6 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/736871622fc0de07fd0539de7598747900ffe66c ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/920db5b7438fb877b07e137e8b55a84c3fe619c3 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/1c609a3f0ccfa0ab28f9190f6f934a4392646db4 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/ba34067d8b04ed0957cca7b98cb8e8bba7c3a079 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/096f7a7218bbb545d22034278d0f2583bea94ac5 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/63917b5758999d706afee51d0446cf91e526e134 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/6f9ceab3e101ca12713d5089090f8bc09a8ce702 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/5800103355038f06cc05e458accb143c2351f819 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/152b6ab479d0d2c1d0c678d1d02c2f474f2def71 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/7a04e8dc2ed63530ad982cc29f4228757e08ebfa ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/d786e1787deb7843336d737a484f79f7197c209e ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/f5da1e5bc7716cc6bbf553e5a72267751c03705e ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **servicedirectory:** update the api https://github.com/googleapis/google-api-python-client/commit/d753dc955d01c5396387218189705ab4affb9c4f ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/9c161eba5d389a6f8b546ebdb99ed40b948bd04d ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **streetviewpublish:** update the api https://github.com/googleapis/google-api-python-client/commit/200b6618acfcf8cfe9f13fe8c0a84a0275974bf5 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/285687684d4e5983e950634baf8a3d927ed5c479 ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/5cb2ae5a787fca502561c3674c932023d6ace8dd ([d5ec01e](https://github.com/googleapis/google-api-python-client/commit/d5ec01e7c7444be9be5ec2de0e0660e5f531a56f))


### Bug Fixes

* require python 3.7+ ([#1842](https://github.com/googleapis/google-api-python-client/issues/1842)) ([6839a0d](https://github.com/googleapis/google-api-python-client/commit/6839a0d784975374010e96d93048a9975bec7726))

## [2.52.0](https://github.com/googleapis/google-api-python-client/compare/v2.51.0...v2.52.0) (2022-06-28)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/de31d203b1af49ef1dcb87c87852ee4d68495655 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/f356ef4c82bddef19bec32651d000e52538fbd9f ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/e092934dfdfe714f61d355eed101086df6073b1d ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/4dcabd8f9859954cbb4c3ca454618e54454af3cd ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/f0918bf8b9d61e0d782d496654658dacdc538a3b ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/e7ceba62a4578b1cf6167de0b64753464d90505e ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **beyondcorp:** update the api https://github.com/googleapis/google-api-python-client/commit/6f77d5910d4b0ce529b78434da5bb4aaec12978a ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/2e0ef3404da46c0f9722d73a0bac2f715ce7ce20 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/b0f8ae7273442de8da28859f3d71286ed242927c ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/d7cebe34e9879ed27e0c94bb6223a485fa8bdd24 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/4d24378e01a7b947d2514363b02ec4dae06867b6 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/2229e24359420e5a8b7dc93adfa4fa4a6fad24af ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/fc212f8566aa56e6bf66623d9f7b1d13694f792b ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/10cff4b7fe7baa5881899e8ca1feacb8c6310e5a ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/526cc47a0620fddbbccc25f24db85e99970be8a6 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/482698c4cce739dc8c8005f540d9cdbcfcb48025 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/21f18cf22d2359e6478368d6b8a5dc6e44e74073 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/3bd956b43bd62e964eb77d9df1a579487f370565 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/c2685713869e57fd4300387ac8ac40e20f89b1a2 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/2a0d0048a31152382eedbdc6946d96728eb9f92f ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **domains:** update the api https://github.com/googleapis/google-api-python-client/commit/2b6c76a6c51d6c767ff876b25e556be11d71a281 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **domains:** update the api https://github.com/googleapis/google-api-python-client/commit/e16ceaefe6088e4570db2a3277bfa48c9b29d16e ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/27ec8d12128eb63c5a0a8772e84bdf925b185435 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/612b90aa8623930ca0a2aa725a38d570958d8022 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/6daf95383f2e7e4f8ad9f758400abf8d0116e0fb ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/fe21b512dab39efaa73dd7d0fa9ddee322a930bc ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/dbf5c472c2c485a56f6bd5869820685357088556 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/57d704113bea1aeab825a69bad9b8053288df762 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/4be64bdecde04db896be32169f8fbe8920e1eec4 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **secretmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/32d917391c7cff15e6c0dd1c5750e4398b17c8b8 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/07d2410421f98ab6510cf5e422dd7e4118109807 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/b4bff9c1a83930d03bde5e9c3f27c0f50ab96895 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/a413c0daae2181b7e7da6edd4c78c7b50bc7285e ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/90db1c5cd2d6c08b0d2e408b1864142a997f2ada ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/9300e53512f019dd129f554dfe39e352fe384142 ([53b1d58](https://github.com/googleapis/google-api-python-client/commit/53b1d58a395c6fec7dd5424ac50198e6e902aab8))
* **streetviewpublish:** update the api https://github.com/googleapis/google-api-python-client/commit/810d56c18864a80c08752de73853e96d37ebea60 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/d5d9447f03c5cba48733ed14c8b7049963127c16 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))


### Bug Fixes

* **deps:** require google-auth 1.19.0 ([#1824](https://github.com/googleapis/google-api-python-client/issues/1824)) ([7f478ae](https://github.com/googleapis/google-api-python-client/commit/7f478aea4e6221121369e1bf2ec88055c24e8710))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/fb1b469b90da3c8f6d3de98b01debe550e50268f ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/300c0960a1fcc039b05851a0c3833044d135c118 ([f3ecc98](https://github.com/googleapis/google-api-python-client/commit/f3ecc980ed84eeeedc3bde12e2b6818b228828f5))

## [2.51.0](https://github.com/googleapis/google-api-python-client/compare/v2.50.0...v2.51.0) (2022-06-14)


### Features

* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/442e22f119a67c38e33d49cd801366090fabd564 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/b610123fce8d04f6a50f63bfac7141426fdcb603 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/7a6743ddbab713688b938dcfb6fbc3e06a9e5d28 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/717360c38c2db34d9d908b047bbf51f669789e8c ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/c2d081d477790f3d5112752bbda1e26b0799d1c8 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/338c9e7049410153a5c0912b4e60a08def584cb1 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/3e500d9a4af04d2d0e980bea862fc0e85f1311d7 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/4a20d52f761e61138a80add5262b593f20d5c6ba ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/4a1b8ebd41084ed9b9c78ed69c6c16a412126b20 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **datastore:** update the api https://github.com/googleapis/google-api-python-client/commit/983ba40399f1020cb4142ae4cffb60259ef82079 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/3ae9b8e8fb03484a1eadc0ca23cda246f3625f81 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/b1ef77b890f614d9777eb27d3126790cf1d011a4 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/32d4f147f17d1fc6dc3b7cde3cd5c36df2fafb45 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/b529083fbf9f0d37b13e9b119bf9f6f068a1251f ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/d35c6cb19d92dcdf980e06bff2d9213c1ca7b1a6 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/d628b6b5968f7484fb3f4db01c400faa110f3a2f ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/e65d2cc485a50127813eb19005c36aace3282834 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **jobs:** update the api https://github.com/googleapis/google-api-python-client/commit/4ca8a71451b37a26d0743baa49843889fc63149c ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/e59593dc35b07f2ea01f626f2339f391562d93d4 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/c9f40c1bbae6223b2639765d0c37c54e49976314 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/40c368d9d8c95acade45401087a09a21532ec3ae ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **transcoder:** update the api https://github.com/googleapis/google-api-python-client/commit/41ffecab6f517645ccc8c0bab3e4f3f4104a1c38 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/31870fadf1ea097e39f3acdb2ece1f7652dfd21f ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/f6c9cf9cd54dd34425ca7ae37612835fa5d5da97 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))


### Bug Fixes

* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/a0c165e93355f8b279ed758e59cb1946d2c56d29 ([3538838](https://github.com/googleapis/google-api-python-client/commit/35388388fb712062ac23cc8dc50caa41cf56b249))

## [2.50.0](https://github.com/googleapis/google-api-python-client/compare/v2.49.0...v2.50.0) (2022-06-07)


### Features

* **accesscontextmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/e6f96be2c2f9ebe086829a155a095ac4c17da2b5 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/3f77945c4f07d3e94317915f8dfb7c0f62b498ba ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/1e8afffab7fbb0d78b8a93050588bb01bfa45731 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/0f73a4a8e8cea90c080df6124347f2db5352167f ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/cd0db01e2fc7b68b086424fa367a9dea3ea7c1f1 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/355e7c6fd65f0109c2504dcfe69db8ee9b132788 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/5f9ef8589b9e5b30a17f84fe709fe6bf5edc64dc ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/e99fff33e7b8834da64963c90cf2bb73a094c999 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/234c3a3a33c479cbea4920663b4a274a874a5179 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/94438523b102ddf5c3cb641e8992aa3f276f1aa1 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **cloudresourcemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/324fcf116eade19f408292681ae7a2cbb38a792a ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/2bf29de28baac6693a5f645e8db176b4c2b184b4 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/40b5fd6d78aba27236017c9ef19f2585cb82a5cc ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/a98cf9e6d23747909f53b2fd0d226353dc4decd7 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/e2c58b5a047a6bbb706733240b93d64b7e4eab17 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/d3ebf7d4b93eb6a5677f97d4618c516e2402d1bc ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **datafusion:** update the api https://github.com/googleapis/google-api-python-client/commit/05a4c82ecdcf56f8aa9e6a3e9a8e6674fd975908 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/4592dcbf1be5c76fb63791513b2a8584f240769a ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/bf1fa0956dd3c0fc3c6574bc5d9067d505cc0e3c ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/a534b6afba64ad864c58c6b4b2658e4b96feb681 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/2d529a88d5a40b8329cce812211490418afd5ead ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/7cfed854c6e99503e3a7e76d66ce0e02c437e7b0 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **firebasedatabase:** update the api https://github.com/googleapis/google-api-python-client/commit/6d1734cd65c35fce2640e860cc63b618fdf990f9 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **firebasehosting:** update the api https://github.com/googleapis/google-api-python-client/commit/44b4f1466e4b93257fa15bf09db97b638f234f7f ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/b3b52f817f44d98c4bcda42975992df95946b8f5 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **games:** update the api https://github.com/googleapis/google-api-python-client/commit/c4784729971277b93d6693932a5f44490dab36b8 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/1339a33fe7cb8158bed368a8efc973a091e36e46 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/00aaeb3145aaa67a7084528ce11542243afad98b ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/5b9d09da5f205a62a0cfdf7fba64bc154ac4f4c5 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/ddc1cfc24b6ba3b98691949751e0c0bb1eef4cf9 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/787a5e5d03031f32ff7ea6623f7c002a28d2006a ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/4d8d69e7a26b01e82da522835f99af26ecced262 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/8f554ccbbfccaa315249ecc4b4ce5268fd943f7c ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/122a2261829d40f9938af810638105da8f1599ee ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/130c317f5a85477047629cec186d2f78918bc190 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/5dbe3b641d12c4bb0c63689f5e4f2f2da3f06f50 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/d207c0dc0462396b1595292d02e5540546b63616 ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/8260f14e447911b383fd844a7f00e3a3e66467f9 ([133e48c](https://github.com/googleapis/google-api-python-client/commit/133e48c8914b6e0f53f480dee3ef372511507174))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/82a4625d4f51c555d7d0f55135c59a4241e3641a ([b01eeab](https://github.com/googleapis/google-api-python-client/commit/b01eeab6a88c7530461311910846785f3245c37b))


### Documentation

* fix changelog header to consistent size ([#1818](https://github.com/googleapis/google-api-python-client/issues/1818)) ([b698f9c](https://github.com/googleapis/google-api-python-client/commit/b698f9cf7a0d60cc0e2eb3a39f1946ec650aa37a))

## [2.49.0](https://github.com/googleapis/google-api-python-client/compare/v2.48.0...v2.49.0) (2022-05-25)


### Features

* **accessapproval:** update the api https://github.com/googleapis/google-api-python-client/commit/96c1b90e3121a379f2fa5af6abb8acb1ef166f24 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/2bbca8fd64edce0d0e59bc1bb1ad0f4570cdd15f ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/fe198270098b5cd962b9b9084f52cff6551167c0 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/c025232f2ece48e9890ca68a47b4a69812d95e5b ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/053dd5bbd6c99fdfc3acfee6a26b958bd17605bb ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/7400fdbe8b48a390522ab812c04fd55f4d1f4234 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/7740f6736e3d70a1e358a21fe067ad610ec4bec2 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/d5f6be96a1c8a5c7e3f3e35f8f5d8152d2be62ad ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/162471e7c7c9eb37b64531334db4d7c52cb48f0f ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/09285b87fddf21f8ec8b57c91b49183dfb176b61 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/d8b241d7ea2dcd2078dd0af0da7ce31b1bd10ce5 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/ff69e6548d552e67b858c944e8eefa0fe2b2794c ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/9072ecd03ee478feaafff3aa7fb29a85b8767284 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **docs:** update the api https://github.com/googleapis/google-api-python-client/commit/d4dac665b66dd4fc546f5f276954fec510dd257b ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/5907ddf733178eaf3c1c90b73c53736b39e9ec7e ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/e1492762b86a533f9db39077044caa30af3f5758 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/bab37f8b7ea08149ad73cae8d3c0a9699df753f5 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/86327282eb20299388c3d4bf103e95a35ed9ac30 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/7a31c6366dd15f902f8bb7e863aebcd698045827 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/65822a859a52ac17c12ebf9303adce79b7250e2f ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/d24800a32ad5d5d273ac83c150fb3c2c7f61f375 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **playdeveloperreporting:** update the api https://github.com/googleapis/google-api-python-client/commit/590c39587bbf9c7cb46d24ed4187bdf9e643e4a1 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **pubsub:** update the api https://github.com/googleapis/google-api-python-client/commit/8479f669975cf3a026697d4657beb0f677487f06 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/d47388abe8cc8424ef306a37bfaf0f4a571ce5a8 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/6c130312fb7d7237d5130b4f298c7bcd3528bb20 ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/77735311449d464299f47869c30f0e7beed690bb ([b6c3521](https://github.com/googleapis/google-api-python-client/commit/b6c3521681823ada0a5b6e0d58ad45f65735654e))

## [2.48.0](https://github.com/googleapis/google-api-python-client/compare/v2.47.0...v2.48.0) (2022-05-17)


### Features

* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/967d773d4c69816ac7ace5feb3af6e0765e7cddd ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/30ad1999e8076ed6b72a0828ac3ea03e54f75e6b ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/15415da4212b6684a66818d83871dd12b7b96f08 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/77af0ebaf6a17994af53c9b718b56cba7fa173f0 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/50deaf91ec56930ad615b8ed1220b78d30088ad8 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/b2b450446b747719b81764eedd43621d1a258318 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/835512f4e8b14f87f1e5c18a23c695edbc7931a7 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **civicinfo:** update the api https://github.com/googleapis/google-api-python-client/commit/ed264ebd1ee2570ba1a6b6501394e1d753cf0ab4 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/0410feba7d41c5a48859c7fb24e9eae13e799be4 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/fea82f61b7e233f5916f4590bc35fbae7d89f007 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/990cc9932e50e21528c68179fb32ad46e3ee4cd2 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/cd774af2d139a15a448be181a810697a45c56c03 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/2663ed11e21f443e211888b8df159cce7c2b4a57 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/6915b9a59bbf3a85539a79c16e3b40b8cb0b7d2c ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/db29444538348988924b952fd49e68f430a62bc3 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/0ebbb28773ff8d947533db6b417343610423155f ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/81466826cecbf67f44971d67184c31fd2d7e84d9 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/395a825be73f8d7657006d35a9aeaf74401aa043 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/992327dfbb5096433c41ebe2cecfbf956dd68241 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/9adb1c6be56c3f472fa63ce94cd67bc89cdfd05b ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **datafusion:** update the api https://github.com/googleapis/google-api-python-client/commit/8087fa1fffc9ff7801aeb5e9f31bc5af3e1b4279 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/a963bc73eb83f7411a37cec73916082c0ac9ef36 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/f4d781d38e3ceceb11c2c2b1ca77fdf6331e87c1 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/a174397a01c651f11ea156955f229df31b93d677 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/e3ad6a0b77b943128bd1e858f50fd969042136a1 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/d06f3fc181cc09b87ad6e54633fd9762a20e14a6 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/13a17f0715f2717e9f43b59cd6cbcba473d69f84 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **docs:** update the api https://github.com/googleapis/google-api-python-client/commit/0c73a0d765aad2338beaae81f2b96807708b2fe0 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/79b0c5a529aef9096b8511753600fbe2437c8120 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/be2d4d7739d9b626556cc75b00bf08fb31fb6d81 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/0368593b0f6c72df16a7fe19cb474ea123a1203c ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/904f2b96067e9001b63cbb041538dcd328a2a85a ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/a9ce2474e845454aaf36006d5b133f104685d49b ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/c9b0f9b18463a3c95d4b277f967eb1ba5a70b7df ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/b8d0ef0aab8a83e0dd3442b68bea3bb8e1ab4355 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/c8b24e13d7e80c520105263b262b0061e853f2cd ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/6ea37ef1566addbddebab0430717c3492f29a3e6 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/a27320a44fd6aa2d0d253b99af32e7f8c5fbe01f ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/dae6904e5265a1eda2f3d43c5c2d0893e95bf4c7 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **realtimebidding:** update the api https://github.com/googleapis/google-api-python-client/commit/d5ccaffe6a4452959b0ff68fd1164d780b3bcf9d ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/b5be5fc96f5debe4b28029c181b6b294e3383572 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/a326fdd93838a1b4ea03ead487e44fc20049cc0b ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/98248b5f1e31486485de83b051c42fe1f18abcf4 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/5aaae810c559dbd4d6ca4b73b75c9dea82e52e9d ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/f919cc022be09307483ea7aaebcaa469375c8da2 ([29ceb38](https://github.com/googleapis/google-api-python-client/commit/29ceb38f76614d0dd9bd42efd1ad3edc9fdd2fae))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/5fc90e536d5ecfb7bc72038b33602d8837d44f4c ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **servicecontrol:** update the api https://github.com/googleapis/google-api-python-client/commit/1cf79d3fc3843012989beaa87352e4675ec147e2 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/278892a6ae6a4291157180e11eec187061717a31 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/9490dbd845d6532148824244d27e02be8e902a71 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/2a56bff0d1b600e80bf117a7e44df6ea9d24c036 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/5bcdbf59feba3009d4a9beec128ffa26e3d11918 ([f2c8fa6](https://github.com/googleapis/google-api-python-client/commit/f2c8fa604de7f9fadaabe3d97b332c1c7fa7bd00))

## [2.47.0](https://github.com/googleapis/google-api-python-client/compare/v2.46.0...v2.47.0) (2022-05-03)


### Features

* **admob:** update the api https://github.com/googleapis/google-api-python-client/commit/9e22dca4130706a21fed290fa5ae7fa5ca7bd495 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/903f0b85f4f95c5263dfa1e24ceb05f8fc694107 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/80d174467cc563fa4fd81760ce3c7551feec34a2 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/4e49c7be10653b21cb213b40399ffd34069c7a05 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/20df986e2b2cad1f4c75d881bfa70f7f1462bd56 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/0468e92be30eb77cdca9c719159e044dd0edae4f ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/fd8adb394cb4bdca5ec350ae603ffbe36aa00d3a ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/c2df6c0e77d17d4964cb641f2c36fba7ebfc5657 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/8ca090f51da56ca1d4105eaf1bb693e402974d90 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/4c07bc069a11d8818ee9ab58be50d63966e7dd42 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/9f134a6aa858be3f95758e951b945ead12436046 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/6f3aac8536300cc39a6afb2cd66f4f6b8eb45003 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/97bd0355563e3baee40f2804468e7cc8c96f6a90 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/bbf02c71a0f96153bac38da400ea338ce8a5629a ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/c3de5dae223f8b8b33b83e77d9b533a0b04a638b ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/403e8813f8d8df8d0e7c7b0dbbb27ba996c6988b ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/ce0552a45960084acb26e1eb757c9061d877052b ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/2da81e791a6f0be4fa51b209ab0be3d688cb925d ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/b6aa7f55b298beab3168b715f83d072ec6d539a7 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/8030d88e4e32497de5695f642965250f22d62b92 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/1d84067e81d24a8a8bf869445fd19ff229e7e1a6 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/e0c6bb2346f82c0ba155b6c88a3d4e6b8cecf7e3 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/2880f47e92cb57572cec6992161a85508b2aafa3 ([e8e1bf9](https://github.com/googleapis/google-api-python-client/commit/e8e1bf98f82f9cbed50bea39a324317e79f58cb9))

## [2.46.0](https://github.com/googleapis/google-api-python-client/compare/v2.45.0...v2.46.0) (2022-04-26)


### Features

* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/dfaeb43d3e1896a011d611651695f6b7fbf2e2c5 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **bigqueryreservation:** update the api https://github.com/googleapis/google-api-python-client/commit/1a85de3a726b840c06d2b55e36d1352881342fd3 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/94044225b078ecf5f378d3add86cb3f4afec5b9a ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/3db2f5c1c873e0def3c85b7ee46386774fefd73e ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/56a38b080d29039dff8d6c756a21d9704e7c7aaf ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/c05cb3357a67eefe80038b1aa3e4dfc8ccb7ab6f ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **doubleclicksearch:** update the api https://github.com/googleapis/google-api-python-client/commit/96507843666e6600538166f86df62220f16d4eaa ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/52acfadcfd9007aaf26245d3c14a5530ff6d3a3e ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/ce1faebaebbc8329fd5ab7e2883bde621f0603a9 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/ada585788f0f29d47b12a89a0d23b62508703fea ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/883bf741abb0ab73f14d23f0d578994f9c2b4f00 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/e5391040e9b1f4389b1944c7bb37a09d49e57244 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/009f7d672bf413989dba7a5e21edd6b38d6c2d91 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/d05adee3f771d4d1b1f7b9a75599e4285ab900a4 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/dafa308bd12826dc67ef0b08f5563f54a2f8e847 ([fba18bf](https://github.com/googleapis/google-api-python-client/commit/fba18bfa6c1cecf14b46a3df07dddf6c9960e1f0))

## [2.45.0](https://github.com/googleapis/google-api-python-client/compare/v2.44.0...v2.45.0) (2022-04-19)


### Features

* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/3d3760060eeaefb591f9a1e54d79e2ca245cf290 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/aa290538423aecb18e36d1586807d76be9b0b123 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/629a96880a9bd3eb395220276061ce4b4db7ac60 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/2d508727d12b197f2c400ffc6b400fd524ab35ff ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **certificatemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/40bf958d8c9a4d4569f7a16263c9de9c3a701977 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **civicinfo:** update the api https://github.com/googleapis/google-api-python-client/commit/95321d901b90e9d09d2478074b595baef79fb223 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/3eee9cadcf600e4aa2171966b196639d1fdb7534 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/acd6b20379db7630e59aaae13e7077f7b0a2e2e2 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/7c592ee048886b8e686c938e656f23b6dc9685ae ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/53c9c70ec03baaf10d4c6535f8f24f1ee89ca34d ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/31197674cda7b1ec540fa20e47473e5b64760b45 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/aea557f145d7d7903906e4cf82a12dbf25c19582 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/9a6bad2524ec5556ee2701f9d0bd7ed3b5d72abd ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/b527c56f6f4243839dca1502ee6659f825a80179 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/3be993ade8d3f0c1d4d53b17df567c6493a15450 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/a77aded8ef786e6dee271fba1b4a216866a52b23 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/cc08e8e21cbd481866b2d1e317a5fdc3a4b0be87 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **policytroubleshooter:** update the api https://github.com/googleapis/google-api-python-client/commit/3f20c2e6dccebf4ffb9208bc32046f777ff6d269 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/bacc9efbbe9f43154d10370f369d4f2ffae5301c ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/1b566dcf9ccf99d77500750af5868d67541f708d ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/6d783b7a675ff268e33c8a46ae5a92eeac7bc27a ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/a0b42c2c2c9a9b96d3511d1295021094c981f8d7 ([e691ed3](https://github.com/googleapis/google-api-python-client/commit/e691ed3b8f65eaafa765459c4894def15ad030db))

## [2.44.0](https://github.com/googleapis/google-api-python-client/compare/v2.43.0...v2.44.0) (2022-04-12)


### Features

* **androidenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/1c3e29583cf3025e49e848cab41a50ccd2d3263c ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **apikeys:** update the api https://github.com/googleapis/google-api-python-client/commit/73c71d8cce0bcf8003c4cb551256139245765a4d ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/b611d716f55d58fc03306f1cf28f105d7403efb8 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/cb0e654f8c94701c8a50c4c6b0ee6f0be3b90184 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/fd7c5f5b1e680eff33e9614c1da1ee3c8cdd1910 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/07cccbd39377de0b4df8c35ddbaaabf162bb35b7 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **cloudresourcemanager:** update the api https://github.com/googleapis/google-api-python-client/commit/a7a4ffeeae0184d3616d40657c999662068fb802 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/f02827fd2763056aa06feb5d281f0b8a212fad41 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **dataplex:** update the api https://github.com/googleapis/google-api-python-client/commit/69e3884e8d18a9212d4d2a5ce7761b8d3beff77a ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **datastore:** update the api https://github.com/googleapis/google-api-python-client/commit/52540a9b421e7247d544020403f4bf6488cb9885 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/86ab5a978e43470e0042fe34a3938bd57e733ff4 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/c8674efb1a62f1bbd47abbb75c3dc7eb922795a6 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/0b03ba1c98f40e47df63ee08a791462e60d106cf ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **games:** update the api https://github.com/googleapis/google-api-python-client/commit/c303c8402a0adfa1e7d82aded73c609a5e345967 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/f5e25a680654ba5d4c8f27cb60a1b12b76006065 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/9a702f8dcbcaefb9990e82358fe6137253788424 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **mybusinessqanda:** update the api https://github.com/googleapis/google-api-python-client/commit/17dc4c8a8154aaa32917c0c1c4943e8eabcf5c43 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/72b622148f7af8a497cda1e94a9c97283b73d14a ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/ff0fbc2723d8ccc565f69de8d85444dc13a0c48e ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/0ff1324dc43bac030b42529cae3343e40ffd17bd ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/ebeb360ad0501b53fcc50d18f449c2eeb13fdf90 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/215757fe528921a0be6d3ed52527740c8945cd41 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/75ad6f09b36ebafc748581ca88093f75a74ac8e8 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/e505d23b5e8cc4e9668fd6959be5fb3122e0f99c ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/ded4fe51e1a374d214389b08633847fab6ed0fb2 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/b2edae4e2e8ee6749a2d66318f1e0e0e764f35d1 ([0b5402e](https://github.com/googleapis/google-api-python-client/commit/0b5402e1dce119e118f082ab7ccbf6acec26054b))

## [2.43.0](https://github.com/googleapis/google-api-python-client/compare/v2.42.0...v2.43.0) (2022-04-05)


### Features

* **adsense:** update the api https://github.com/googleapis/google-api-python-client/commit/b1d20ffff49a2fabb1233ed98fd7f9e7bf4c9c77 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/598768787d51646a25f6421edcda768c9234848f ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/9adeaf4149469daa37cfedb4371d18122821fd7f ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/fb58105e607e59add50f2fdaa74f48ac3758c9f7 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/5c076bcc466612c63553fd20cde90d9bf3619071 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/083c844c3884117f142e39d4c3b0836b402e6840 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/2234f878b3adafd2e3ab4e0f952ef72587e1c44a ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/b7e05642cadecc815c84c37de615c134882ea7d9 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/428a1815f6235cb1ca8c9a9cb91a9b02f43707d2 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/170410b0714abe794a768965270c57673f7839de ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/b3fb53a6ad1e7253b3728e0d768144a8c49bfb9f ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/ef6853dc854b8123a5b19cc68c6b6da7a2b9cd63 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/20c1e9602ccdf0960bded76bbb19493a6da46261 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/0cc225b0fafa88a1fb10b0a57d06c3598517a7cf ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/d4b4d5798082fcffb6cfd7d106499492b54d5d32 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/45f66565224d5e8bae40b5dfb016c236d3372803 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/946d92e5dbdcc8b345e7493d5750e34f9075f1e5 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/bc197df918bb33c8d80cf1b722457da37b15cbac ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/45aab7d1fc016add392c2bb6079909e4582e09da ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/fbfe2be1d57d4938e010e2674df83cb816f51a5d ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/bc324ded96549b1e371043313900c27c9907c1f8 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/d104525b371660248f05eda21a04a16e7d0e5fe1 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/e146ba81c50c66e864fc3b409ec738d547efc319 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/4846d8c5f22597642b3b12096a91af385a08f3d4 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/d4159650d73b2a15f76ebda218064fe33e4a8241 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/5eaeb4bf654e86f6d5d96403550fd8be87b93f5c ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **firebasedatabase:** update the api https://github.com/googleapis/google-api-python-client/commit/3d7b1ee97cf20acfe5265508d9283012f6784d59 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/72d910ce1857a0741cde846a89aa565500c95c03 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **games:** update the api https://github.com/googleapis/google-api-python-client/commit/b8e15af702c5fd32044f11645b4adf6e04720e2b ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/c0bec9144549d4eee3e65b7ccc335ebb0c00fdfb ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **iap:** update the api https://github.com/googleapis/google-api-python-client/commit/dbed650ef5d9bf3859651ecfd05f7f20521064ef ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/1d87b493064070669f03506befd8b9db77a683af ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/11670e604e27de2ad6a640a0e762454274e2a70b ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/376399fe70d067d58d65cf338bcd544b34216cc4 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/a69869b42e70e2e93b8ae2869bd925107d57949a ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/2e4354e374b33961465f36b6b2dc6b94d9835ecb ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/11eb944061e530fb027deb1e06371cb8f01c3fc0 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/291b3e3f64507d989e999f0bb7f99dad3fa46c92 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **servicecontrol:** update the api https://github.com/googleapis/google-api-python-client/commit/5f51350561a9e664dd0a1f453468e6060b156e4a ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/bc8a50d79a3519ad639f613c0265e498f77fd179 ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/ed56216ed0f1951521a6c7639612fe89ab634fcc ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/08228001d2df9fe6fb287d76667703cc1e960ac7 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **vault:** update the api https://github.com/googleapis/google-api-python-client/commit/4634b3d0486fd0b2e7fb3ef3885fd154798ead57 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/51e5e049e77d9748f85e83e1a6240b12482cea8e ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **workflowexecutions:** update the api https://github.com/googleapis/google-api-python-client/commit/7c84831d8cb4a7083430297dcebe7bd1c19e4c5c ([4096473](https://github.com/googleapis/google-api-python-client/commit/4096473865e95e6be6245a4889feb50fd91b5521))


### Bug Fixes

* **forms:** update the api https://github.com/googleapis/google-api-python-client/commit/b0d49dbd2827ad80c3d59779fadf754ea4a25a03 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/990a6f5f385eb3ebd2f54f39274f23272aa54612 ([4070437](https://github.com/googleapis/google-api-python-client/commit/4070437ebef99da26ab86b5fc51fcf7a5ae488dc))

## [2.42.0](https://github.com/googleapis/google-api-python-client/compare/v2.41.0...v2.42.0) (2022-03-22)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/908b1fa724a11415a7e181cae916bb882489d1f0 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/ae2e5c2afbc1e6b4c7ea991d86ad57420ee0c760 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/05d347993b1ebcbfa2f8fae88fda23dab826c80b ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **apikeys:** update the api https://github.com/googleapis/google-api-python-client/commit/0a7914ea43f115286281e2f91e743c7b65b34622 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/8e39a75b5e14ed4e9f14889ae07e27d3b720c0ed ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/badd5b1838b6c47241b1f581956caaf447c3c7d0 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/d522ad1d179ff42612ed361258091b0fdf27eeff ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/4a3e8733eb7b1464fc0edd13921abf5f4c47700d ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/4cc4fb7063c50d07d06afdae373b799fc2ee513c ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **datafusion:** update the api https://github.com/googleapis/google-api-python-client/commit/ba1e4f8cfe0d66734da8c473a788fef8a2e2c16d ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/f2773dce6e38d45709369c60e179b83c4722dc9f ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/cd23853a9d2a923a035b1bf4fa1de7ce03e3db17 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/544fbd304651f548fbe4e47c7d6cb0cc829b2d4a ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/2ebd974ccb4de6541a81d7d0a7231d00f1fd3a12 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/8252d87cb38eb09afd7a89b00a1e41c50bca4442 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/8f78e3de8ca5d0e3c2f29fa5546b8ebf6bc39147 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/5c5b504d38cee38749a667e239a20e87ac3f7de2 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/1ac6e1aa7ff24200da4d05ea96b9263f80d72874 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/be17e4deb53d6a989e700ca2ecfb82c479fbd37c ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/a0b990c973fabd4e4867fcc9ba143776fe77126a ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **testing:** update the api https://github.com/googleapis/google-api-python-client/commit/3e0f5527d728f0782795f20c4f303f09698bddec ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **texttospeech:** update the api https://github.com/googleapis/google-api-python-client/commit/8aea2ac640a3271aad629a1e8038408de957f9a3 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/a165ea29b31c0ad3304e5cbfec9db93592b44103 ([5621484](https://github.com/googleapis/google-api-python-client/commit/56214844c720893b15ed28f14e598940a99d7a0b))

## [2.41.0](https://github.com/googleapis/google-api-python-client/compare/v2.40.0...v2.41.0) (2022-03-15)


### Features

* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/49ea8e87b69ab39ec37af1e2ee40ded99c8a9863 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/6cd7b462fbfa2655118f8cb541c12a77d529190c ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/48c242e82ff838cd80e637e1c2b1c48d5fe534af ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/93195a6a493707707186a3e410a04990e26a0d3b ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/bcd6ea147ab3fda1c2a992ce3e026e19bdeeb799 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/39cd4bde6cba0b8af12ce645552899cd6d8afa37 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **fcm:** update the api https://github.com/googleapis/google-api-python-client/commit/d9a7eb4fcd54b754bac2e19b97ef5db7603d42ce ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/6e26f5ce4c0499d4def8ea4521888b8f2d18c041 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/bbad5a0e28e5d7daa9bbeb2f9c853708107424a7 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/eba1e3a3bc4477b5731ced542b5ff81ea987505a ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **mybusinessverifications:** update the api https://github.com/googleapis/google-api-python-client/commit/78fb94ecef8b9d3c44850eb808f9f10973a907f1 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/07dcadcc737b22861ab5ad05c4bfc096ba71f438 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/3d03ad1c7a2652bf5d47d9e09f791b1da14e3b02 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/3a26ea7a6578d9226ed4c8e13951800ad8d7d2a7 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/43c8ed8720983495b1ca323ccdc7de18ca455c44 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/3b229064b4404751ea5c00e8b569b1389276aff9 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/54d02182818eeda0ef7dec22545c477673232b59 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **versionhistory:** update the api https://github.com/googleapis/google-api-python-client/commit/657ba28422aac6f19b155df1384ceb5bdaf4ff11 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/00aa6fc010336c0ac75ccc21933e89560e8b18ca ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/d236f3ae7a44b9018a1690e12b25c0cb0e2828a1 ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))


### Bug Fixes

* **deploymentmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/8b2964fa504b3fa765822d838ce95ac15f96442a ([ca05b70](https://github.com/googleapis/google-api-python-client/commit/ca05b706281aaa777be288f98297bf0dda1d3c7c))


### Documentation

* remove undefined `http` kwarg ([#1723](https://github.com/googleapis/google-api-python-client/issues/1723)) ([f850667](https://github.com/googleapis/google-api-python-client/commit/f85066779b3425147107e274339d5c2ecdd79a60))

## [2.40.0](https://github.com/googleapis/google-api-python-client/compare/v2.39.0...v2.40.0) (2022-03-08)


### Features

* **accessapproval:** update the api https://github.com/googleapis/google-api-python-client/commit/e4560c7b240a1d5ef1ade8c210f1d2bb7b0945e7 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/5bb6ed7b5ee5ab525f62b733039b544463a7391e ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **bigqueryreservation:** update the api https://github.com/googleapis/google-api-python-client/commit/79813fe07b9f46bc2fa46ade2acd34784a9b8d35 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/3cf6af116495a8678ec1e8eb9bd747636dd11e1c ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/6c62fb2b59e6b1ac9aa5e6a2a1999d72ceea34b6 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/5928fe97fa9c893c81e8e158ad67129ddc64f2c0 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **cloudsupport:** update the api https://github.com/googleapis/google-api-python-client/commit/e8092f54a30761295b1b582cfd4aae679a643a9d ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/0d7de78d47dfee656c9b904461c37f2edbf4c34a ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/7de5148f2c1367d84f104914ad9c886897ee965c ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/e5322d7ada7671e9e2b6df3ed7a7a0f68794db86 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/f85d45218fd575758888e911b9ac012864006195 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/6f35004ca3b0478507a32ee009d021acd5bcc27b ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/eb9a5da91c5abed224fac6dc67eca6645f95d664 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **servicecontrol:** update the api https://github.com/googleapis/google-api-python-client/commit/63891f5d6628c8c64ecc5b8adbe3dd09c1d6dc9f ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/043aa17cff73b2a3ca0228dd830a5a23a2999bd3 ([777c7d5](https://github.com/googleapis/google-api-python-client/commit/777c7d596dfe0e96edb484ff734b5383428b0491))


### Bug Fixes

* **deps:** require google-api-core>=1.31.5, >=2.3.2 ([#1715](https://github.com/googleapis/google-api-python-client/issues/1715)) ([8308e5d](https://github.com/googleapis/google-api-python-client/commit/8308e5db5b9f5ac0edf559761eb905c51e53e330))

## [2.39.0](https://github.com/googleapis/google-api-python-client/compare/v2.38.0...v2.39.0) (2022-03-01)


### Features

* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/35141195a8861530813d4a638a598a864bec9a06 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/3704390e8ffb2d25682d68a6523350965b6dec38 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/72c1cbca0fe9e9b3a4dfe49165106e87fd97f360 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/dcd2c37c49834c00fbdd510962898d5e6a6f191c ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/61bf78b268cfcbec154f94f6deab9a2069d1ad38 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/92a4e01199ad06930e77bea3caf2de70158b0ba6 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/56b30805e34dc8e59176fdd69145ed2fbc75ad0b ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/803d36fd01c92a67098eb2cfe5b2480849bc99dc ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **datamigration:** update the api https://github.com/googleapis/google-api-python-client/commit/b8836f7828485aa4e3bcc17f88ddf6a7667a7de8 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/f59636069d852f20f3472ad40539530063ea38b3 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/82cb2c2536e01ea35829ef466a44b8abed396595 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/556c091f1411493e7f6f89986bf68392cb984be2 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/55a2fdd36ed7e8cec07f1fd7839a003542aaaaae ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/ea9f4257b1043d70cfff70fab72d947cecd16a82 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/f1ba7e60420a1a6f941ebd0043ac7ea86a8c6cc3 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/69fb750010d7b91f55bdc99e42f3b3a7c9a664da ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **mybusinessbusinessinformation:** update the api https://github.com/googleapis/google-api-python-client/commit/9d7a59eb7848462d10ecd9433e76eacd7c6fb23e ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/1402417ac4577229bc1d07f67cd2ec82f124a6cb ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/ad805abc44472537ebdd97657a788f688c154df0 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/08b1e677eef31d6049bb00e1fb2587a783697096 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/cc62dc3f3f3767c3c43786a44bf4d2ea11d9426d ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/84599fbce8af340bdf4d66b17df11d7ee6564fc8 ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))
* **vault:** update the api https://github.com/googleapis/google-api-python-client/commit/e665515313981ddcd34515a83adc1e0bcc75328d ([c9d0e01](https://github.com/googleapis/google-api-python-client/commit/c9d0e01dd8eaeddb1c628fc6433fee5473891270))

## [2.38.0](https://github.com/googleapis/google-api-python-client/compare/v2.37.0...v2.38.0) (2022-02-22)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/1759d794657471f26a3bcce48c07039586986e63 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/e81ff79b161b8ca3e00c6f835a4fad727a6c0b30 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/f75d8c1f167cf8cf517eea5c4b63e76396f1f963 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **authorizedbuyersmarketplace:** update the api https://github.com/googleapis/google-api-python-client/commit/58418b702f9ff2ea2673fb3b558f1bab8f5094a6 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **bigqueryreservation:** update the api https://github.com/googleapis/google-api-python-client/commit/20c79b899d0f3a15b343ddc73f6bea79add738b4 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/6b783b348d98e66f6173105ceb4bd52df6be253b ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/5c4693060810f2045c4c6e99657bb40a51600816 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/39e9bd18d0813281f2d87f0bd897d355f348610b ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/63c9fbcd252b0e480a43f3b2eee480faa925269a ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/7e7dd3465e8b2bcdecc7e3d00ca846ed293db06a ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/7e2bd793ef1a36e25503ae39a1e89279d012de39 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/557608ad1fd8d62fcb60a16a864cd842649e7386 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/8f4100e6398a969b840d09870fe49d1f77a6fe2c ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/fbea2226ced3bb80dda63580170f3e3e5d838256 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/c15a96e03fabe0722b150c83709bbc9db34aac3c ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/09e5a74995ca0d2c49577af3998497808b76e71c ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/f1413c2c9a2e76134b0773c3a450654d57bb5ae6 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/8ade2ae4cf1ac6a33bf7a9afa43db8759c56f93a ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/97f33d8e3e2acd208ce2413b4f1be467b1522fc3 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/efca9e57e31072227bef77eab414514d39c9cffa ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/45b2c47f31a87a8a46d9b599a80670d6d940a68b ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/771a60d5fd8fab61ce9ebda6da573bd91907d2c1 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/7dbeeb5648b2d5dc9db9709088f0d70e114ad571 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/b5e395819376ed652ad1c86d5cdcec98ea748aee ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/17a57ccd8f290e29e490a57c7b10689ecd977a18 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/a788cc1c3ba293dd10bd968a2833ceed4c8aafae ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/b9a8d8e0955a498856735aa2ae64afad327b2b50 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/0870408f7f9105b453ac20480165aa1f1ba20b31 ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/afb7ebb6bfae9cfd0de3f6b27ab67dd0080fe0ea ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **mybusinessbusinessinformation:** update the api https://github.com/googleapis/google-api-python-client/commit/62cb6317edec01afc0c512daec3449cb4b847ce2 ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/75118d484d145573cf1737f41b20a00c18037de8 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/77c47e95aeb7695ada12e1208922196659a62e23 ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **playintegrity:** update the api https://github.com/googleapis/google-api-python-client/commit/eb24d8dd5ef27b0b78c0e24e9f85d48673bcc3ad ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/6d21610486264c68579aaece6f43f300118ca659 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/84a51eb3619f277bfcf6df315a276369a5ad0fc9 ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/9a4b43381dacf6f07ceba45f4d35099aaf38a20e ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **pubsub:** update the api https://github.com/googleapis/google-api-python-client/commit/affbc0631d42163299c6df609e107b82dd99934e ([07bfa5c](https://github.com/googleapis/google-api-python-client/commit/07bfa5c5308f432272213c6c4a395cc14c4c5b0d))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/6200c11aa5fc47db3163c4e2a020406f6f533360 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/16afc79a476aefe33bb205c3ab88f900f10c4dd2 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/b8d8b70b460268db9c637ebe9a43d19dfd81dd10 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/5785b708b4a316c8a56af0112239ee97ca73e3a4 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/67fc27226a35557167936982196bcaccb09a5c67 ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/c0ee86478baa4afc4797fa27557e7059b69ce8cb ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/359b15af67fc08a906694c90315d1f7f2a020a4d ([58ef3e0](https://github.com/googleapis/google-api-python-client/commit/58ef3e0171d10c7884523faec8e45907a8ff3032))


### Documentation

* fix typo and unnecessary word in docstring ([#1692](https://github.com/googleapis/google-api-python-client/issues/1692)) ([a47764b](https://github.com/googleapis/google-api-python-client/commit/a47764bc0ee296365e196daa39d038035325d5ed))

## [2.37.0](https://github.com/googleapis/google-api-python-client/compare/v2.36.0...v2.37.0) (2022-02-09)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/1857db051c8c7e81dbd053264be9b6313a46dd0f ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/03592f89e51623a08dcf7819ef060b46179a9996 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/589181796bdde80151efa76ad2e5c84952d898a0 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **apikeys:** update the api https://github.com/googleapis/google-api-python-client/commit/f667d8c813aeda3687d4ae2cbfcf3b2c2c544aee ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/45409ce2ec81c37bab42eff7277d36bb91adbd61 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **baremetalsolution:** update the api https://github.com/googleapis/google-api-python-client/commit/74787f272739205741ce9f7a870efa3d6a4d533b ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/58dcafaa65955f83b7037a2d9ad2aa0e4fd901b8 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/00a4b27d4d090fca3c1370bde5639a5ca412dcf1 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **classroom:** update the api https://github.com/googleapis/google-api-python-client/commit/13d8599ba5adb2aaac81652ab7ec74d1cc56ab36 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/f30d7d4dca8d711f0ef93d771219b9a403a51ba9 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/ee2f63c1e06ce7bf93a0b8e0bd6c618bbe698ec3 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/d88519b3a007953ab614d480bcb7977dcb88078c ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/e8a865c4f0967b476f735babdb88aabee4860b2d ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/1778efa6f205f7018f893c0ee4d4503ac00c77a3 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **cloudsupport:** update the api https://github.com/googleapis/google-api-python-client/commit/d11e33dea5ca90726a71fafd728fd75de176461d ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/4fddcac23e42af7586ec619bfea0551332c842a8 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/5cb3b5297792bb6b09fe531c927f616143a07f42 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/2cb1c07d1fc1cad95618d021347110646c149355 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **datastore:** update the api https://github.com/googleapis/google-api-python-client/commit/c573fc2892cf8f89d51bb71029fc6955a72ff427 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/4d96721c6a3597f7326c728940a0300539cf7bf8 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **digitalassetlinks:** update the api https://github.com/googleapis/google-api-python-client/commit/8c45114614b0cb2afa875135c25389b807b9fab1 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/93c6063662309fc8a40d5bc33f18f5decc66532e ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/c32bbe59ecfa5a443960b83a67827310bc2569c8 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/28c2e2c1131aa664aaf1659938cd74ccbdd46f4f ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/62b8d0dbb4b810d4276cd4f99861b3e7ce50c2dd ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/6749e1b06bcf723b4905f4c26893645761d5b747 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/fb99401ea344309d89e0847511471c7e47ef21f3 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/a5f3d2f80fe0adcf616cd2dce3bda8ba63471837 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **gameservices:** update the api https://github.com/googleapis/google-api-python-client/commit/1dbe4d1ee3d98b3f2bab63ad6521463cfdce98b0 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/7f9103eed817b5ca4965c57ee8aa3935380f8579 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/633c51d227b565897b46df3d3f428ec8171cbc61 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/b61344a758895e618937093a788b278a552f9127 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/f116213c9a75c3d6a1cbf3fd86d3446673b5bb6d ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/f59f0bd0e78b80d7d4cc04ee36cd9aed80c7600d ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/2c2d15dbdaf6d22654139bfddc44add8a16a0f21 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **orgpolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/04de88b33b82667ac5fee74395f7b83b9666feda ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/a2466e30d1b0b4a07b978bf01e4038d7ee32c994 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/e3e13dd5da48c4129fffe6f4d57aff5284d88837 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/55246261f71db655a1ad2344de6629d960790e90 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/6a362da7928c0653af6fc63fc8bbdd7acfca54a2 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/f44e1a01e194cb7d6c6427f334dfb73d2cbcccd5 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/d8098d5dd084f772df52e2eb3ad0313ecb3d9bcd ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **searchconsole:** update the api https://github.com/googleapis/google-api-python-client/commit/ae9b18dba9f204cbaa8f5f1efd3fd07faaabc185 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **secretmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/be08227c4c8b75bffc35341f39e2306ab5912a78 ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/186f055b61cd88ccacab6752a90ed376a186f031 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/46715e557efe8bd7ec8ad092df369d3fdef4aa7a ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/31c607eba22d898e933a9a5573496635003300db ([4e0aa62](https://github.com/googleapis/google-api-python-client/commit/4e0aa62ae80e56036d9a3435d15b7263575b3609))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/7f3cd9c7b4c330d67ccba4357e4234c94f015784 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/695b77dd8a49d629c7fc713cbdb64f34ef6bfe88 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/689775ff02625bb0c7f836b1ee40dad929306456 ([7f9754e](https://github.com/googleapis/google-api-python-client/commit/7f9754e900a35b9a7ecd845383413c68a6150e12))

## [2.36.0](https://github.com/googleapis/google-api-python-client/compare/v2.35.0...v2.36.0) (2022-01-18)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/981bbe36878d2c3d5687c56e89bedf562ff9b619 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/0d1152f61591215b004f3f293cc37b995abe422c ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/195bfc241437417c544b89025ca16e9962915830 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **datapipelines:** update the api https://github.com/googleapis/google-api-python-client/commit/3bb19370a5aac772774c64c703411c6cc7343e4e ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/2fc3a16831166c7ffe87864723f3fecc5edadf66 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/d51a6ee7486c646b061964e8a960a4a7969c0fae ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/459a6363792c76c3b62f0351f6c11c19ebec69bd ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/92ec7cf5969f4630ef6b626aaa102edbefcce2e9 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/8fd4b62bb45609f892902340386691d08916577b ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/b7f92e49126ce0a2b51699f1cdcd9688050202a1 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/e8a20085b2c69058644955733a2806e3e2ca7fa6 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/974f389117b61e70dcae964a4cbbc09de3506c25 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/f48c5289642548735424198ab5ed131521e5d680 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/edd3d24b7b41b0bcfe851358dbf58939be9e64cc ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/0a68f42ad8d594cb024d998e83b536d18d07d35a ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/59c518fb1802074b03a4e55be3efb9ab25692b84 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/1517d9dcd845edf8a55baaef3d27db88f4beaa54 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))
* **servicedirectory:** update the api https://github.com/googleapis/google-api-python-client/commit/298a0e1617d486b3a6353b1b965def9dbc4f76e2 ([4d5c983](https://github.com/googleapis/google-api-python-client/commit/4d5c983f4cb58820b1ae5fc1ee966216b056220c))

## [2.35.0](https://github.com/googleapis/google-api-python-client/compare/v2.34.0...v2.35.0) (2022-01-13)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/0dec51cdb8227155731e9b63a4092da556c02d1e ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/975ea480b8050a519a344cdaecb297e0cde188f3 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/6266ac01c6507d12bfd65ae811b4f4edd9b6954a ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/06362dce43356f7b6dd4253f31f3533f1465885e ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/ce5edd17bfc87c22eddfdc697b16f0b6401d4ca9 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **connectors:** update the api https://github.com/googleapis/google-api-python-client/commit/bc9062b3d55b5b4fbb54e547b8399fbcf09a596b ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/5fedb046b952461db978978802f4227f1611c333 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/a9bdbde1f8c095ecc8693f7cb3ad4c6390d2ed68 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/135360cca2be8f746940df79eefd576b07af125c ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/38c6ad15c360531c96008b81563ca0245e859b0d ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/f4a3a0f31de62c1823c4168df67385deb8e8e2c8 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/d039cf7eadc91759236bbfd6de2d123ae3eae948 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/a8766f583f266fbe7b2d299c3992cc86b758ea31 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/288618ff2301e4e6a49c5211ed7ae8cef978fc60 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/66584093cbed2d24f3184def26e164026607e5ed ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **orgpolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/35d0c20e2c3f7d418703d7b3eea7c353094985e5 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/bbbf1b21186421b529edd01eb99b2a18bf812f9d ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/a2a9eb8c0d104d3320b2928e568bef5e6b439541 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/af2b78b469d050c5eeca0996f7eaaea65930c1e5 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **script:** update the api https://github.com/googleapis/google-api-python-client/commit/79b1292ea77bfaebc837aacffac320e780452a0a ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))
* **texttospeech:** update the api https://github.com/googleapis/google-api-python-client/commit/46901569d6e918d86f2d9dc175ecdd2f8719bb93 ([4896942](https://github.com/googleapis/google-api-python-client/commit/48969422d118e0a30a166de6bd178d45573fe9f3))


### Bug Fixes

* remove adsense.v1.4.json ([#1616](https://github.com/googleapis/google-api-python-client/issues/1616)) ([5d3e588](https://github.com/googleapis/google-api-python-client/commit/5d3e5883b63d6038aa18e48397ce2eab50cb5e2c))

## [2.34.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.33.0...v2.34.0) (2022-01-05)


### Features

* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/945a281fc6a055f37d68a742959bdd18aaf6eb62 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **analyticsdata:** update the api https://github.com/googleapis/google-api-python-client/commit/90327d9a1b198523773d730402c5274c424ddf8f ([797d677](https://www.github.com/googleapis/google-api-python-client/commit/797d67740e7a8493c7e5fccdce3b88b0de90883b))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/a2271c7c184e8d75b6370cf139ca464e4ebe435d ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **clouddeploy:** update the api https://github.com/googleapis/google-api-python-client/commit/e98fcec145aeb43c1a962404c4599b63dbe7443c ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/6a63e51e98ea3d3662b0dd89e95636ddf14ef941 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/4f21ebf8fd2a9fd1e838e74266e8f8ed847c5236 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/bb409be9296aef9c3e106476999e6e1c37d2fa8a ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/5687b00d4ba57a2ddb4311f66ae627f1c4f3807d ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/d026eb98f0eee8889aa7b55d507296074a140da5 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/f96d280615ea04400a22fe9b7fae31bb6e10e4fe ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* expose library version at googleapiclient.__version__ ([#1623](https://www.github.com/googleapis/google-api-python-client/issues/1623)) ([83db1d7](https://www.github.com/googleapis/google-api-python-client/commit/83db1d71395e92fb2bd814a31713bd8ba3f412ca))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/8a11e53e91c04caba64091272b8e8e7a5b482c41 ([797d677](https://www.github.com/googleapis/google-api-python-client/commit/797d67740e7a8493c7e5fccdce3b88b0de90883b))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/6de66e85f4cddf5a26c37c35db2ca0ef561c41fb ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/953a206f931396b030aa521323d05a4467b47d05 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/db02cdb70461284f33d1cce098a1babb191a1e87 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/a8a823f893b0208b9b8e1a71518726c1a919db5b ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/b9be56f5967f7112a3b4620e89fffac4c82907ae ([797d677](https://www.github.com/googleapis/google-api-python-client/commit/797d67740e7a8493c7e5fccdce3b88b0de90883b))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/743505720e00bf57f0f2347b0c9c4b1cbed1ecc9 ([5a6231d](https://www.github.com/googleapis/google-api-python-client/commit/5a6231d31156644fdc0fd5a6ef8a0cef25d1dd9b))
* **testing:** update the api https://github.com/googleapis/google-api-python-client/commit/98d5c1de2a32dce65697bffeb87b3a520ae5a94e ([797d677](https://www.github.com/googleapis/google-api-python-client/commit/797d67740e7a8493c7e5fccdce3b88b0de90883b))


### Bug Fixes

* **deps:** require uritemplate 3.0.1 ([#1629](https://www.github.com/googleapis/google-api-python-client/issues/1629)) ([1c4cfdb](https://www.github.com/googleapis/google-api-python-client/commit/1c4cfdb76560f757cec9dbc56a290ee748a07ef0))

## [2.33.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.32.0...v2.33.0) (2021-12-07)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/835ba4092c656966ec26ec08f6be20d5d1abcf43 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/6abccd47e1e537bbc46447acf1495a610c3dae31 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/f5a2e18eebb360f0b416765166303d362944130f ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/d3602dbfbb01eda58b5930bf17f8fbdfaad1e6cf ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/a3343e30f99a8250ac4dffc401e3106b21e59c13 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/614167472dc908fa47eec9a0921b9538ba068066 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/834349f1c54a0be33fb55e3328f88f25fa6a9419 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/5482a0bade7167307dbbd81455c023a685318227 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/361134dcbcca446cb9e2b004006f3feb1920fd93 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/4d43cceda82a1df22fad872e85e1b7236e239ae8 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **orgpolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/ce6c8aad2d1e8f7d6325c2642f61c07e22fddb5c ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/dbbe2a7c7d9d43564d4032d109dc5e83d4864e84 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/4e21ee29bc68bb989519460ede52c04cc66f203e ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/8898d540b6ac5801da6854209ff3dee1af7dc176 ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))
* **websecurityscanner:** update the api https://github.com/googleapis/google-api-python-client/commit/bb0332e672950a3fbdfe0d383d948a4925bd433f ([8595441](https://www.github.com/googleapis/google-api-python-client/commit/8595441799dfc7cb2ec12d6ecfe893fd87b2fa7c))

## [2.32.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.31.0...v2.32.0) (2021-11-30)


### Features

* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/5aee28e836eb486c4ed73c4ed2afbd9fc0e70f06 ([a7b9714](https://www.github.com/googleapis/google-api-python-client/commit/a7b97147a582605930e25d51f59e2974442c66a4))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/faa6c7f4fab2190989c9a587f35998203517ff2a ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/c0f6be757e47a62337e7963bea576858cbf17341 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/ef184772aa82c3dd136d2da03d7dc7a1d9672e1c ([a7b9714](https://www.github.com/googleapis/google-api-python-client/commit/a7b97147a582605930e25d51f59e2974442c66a4))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/536d4b0a61e15b45439f3f3066410236d50e228b ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/bc7ce92bf38d4eed3fce35cd080bf40b43855ba4 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/574d4ace68dc1bd844f01ec13419b7d055fa857e ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/a86a46ed4f6098a6da8d3bc2db8ae1642e4300f3 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/c4cdd10e83565119457494a21f1abe128ac59083 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/f54ebeac6f8829b81b975a9fcabde5423f769ea9 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/2b33ab2f6823916a872f33c23c9da86b993f0fc0 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/0406443bd63e9bf9312c3ac7a7398ca0a60dac51 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **gameservices:** update the api https://github.com/googleapis/google-api-python-client/commit/8016e68c4c2ac2f065fc1a0c7e86aac35329cf25 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/fbcb756aa75d122f9929a6319b3bdd413cebc293 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/8ce3b8583936958cabce8c7a0cd72ad16817de0c ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **ml:** update the api https://github.com/googleapis/google-api-python-client/commit/cfe625ae36d61eda2f496115ad515a7000d8973c ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/6348dd518b3be79230e3d23beb4e4f2527d67855 ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/0c6c8148b57f793fab971f2f815acef70fde478b ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/5758865ada7f1c87525752f002f82ca8681e927d ([466c9a9](https://www.github.com/googleapis/google-api-python-client/commit/466c9a938ee07debe7d6e35550b473c62f9f3992))

## [2.31.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.30.0...v2.31.0) (2021-11-16)


### Features

* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/be7ffcca66cdcb1dfcd9849538772914c90b3ea0 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/59c97996091063cdad497be989d168ec1e71a178 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/60f5758b975a9bbac044b9005601c5c026125137 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/c517033bea4e84d1c118f77df38e2f33b3741ec2 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/9ac9faa70c053fd1f5b2de7b6ef5947a04270dba ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/618985bd0fa3f0380152e8d33e3b30ba465e1f2d ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **datapipelines:** update the api https://github.com/googleapis/google-api-python-client/commit/a39bb0f9b41255adf6c790130931f64a153ac0e8 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **datastore:** update the api https://github.com/googleapis/google-api-python-client/commit/5050adbdc30c4247e2454a7e063c7f7ea2724bc0 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/fd46c128ec3d0679283e3cddb1c40eb8b5f3728a ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/3ba31828b05604eaa23101d681354b39c75d712d ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/b1840b06a09ec22db69d757706aa98d2bf536a49 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/b13a2490844c5c84c42e26c7e5bafdf700e689df ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/37cce48342813c865a2704ca06841f1801ebb60c ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/8d1f955971aae9e0e4b7956906e43382fcf57d20 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/9c90df783a1fac104920100158ddb7c88d461545 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/bf890b636ae02bb1d84e050df052fa341a29a4c1 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **mybusinessbusinessinformation:** update the api https://github.com/googleapis/google-api-python-client/commit/90e206c145790d0f9a78bbd7acb2667796868db7 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/c8796544acc40e330276b7777c728782217b1bb4 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/ff95700fce7de8bc2a58be64890740140532f865 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/d85fe38478c2cb56b3694e6890f6d53c367e057d ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/35a6d4e716f26c77b3588f28d3097871a29dea7e ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/13f1bcb6311e0ea11ad60a29713c1a0a1fe22f42 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/770bc14b5f95b525bd04e40378a718a38ac31a0d ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/ea30e3a05539e4de70e385a34490153f32c16789 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/80e20909242c4bde06b8adc3afecf1141be34f45 ([815c1ac](https://www.github.com/googleapis/google-api-python-client/commit/815c1ac7e3f7c7ea6df920645adb8cba84b05c22))


### Bug Fixes

* MediaIoBaseDownload range header off-by-one ([#1595](https://www.github.com/googleapis/google-api-python-client/issues/1595)) ([4b73b2e](https://www.github.com/googleapis/google-api-python-client/commit/4b73b2e9d53e63404c8800f2a2b3f1ee86680815))

## [2.30.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.29.0...v2.30.0) (2021-11-09)


### Features

* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/be2e5dd39ea24ffb04bda06bcd6af55fe15a272f ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/4535ce54bf2a6638f1a70c394021f17883fa0f35 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/882fdb3258c3ead813f0895539bc99503d3a4356 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/c330a6f08c004f0809bfbc1b43801dd5c38dc805 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/d0f05277b6caeab32d8283f2ffdf253608c67a78 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/2bfa5a11741e6c653c6297a9e438c0316a9703a0 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/b917688b232d9cc2ca59f25725e9013e2d6d09f7 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **datastream:** update the api https://github.com/googleapis/google-api-python-client/commit/218521cf0ac369533de05f866419d38295f17a40 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/540233d5289624ba149069596ae46233fd31e2b7 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/1e029c853a3232ea499035dd7a9c141d60df4ba1 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/9f998b473a80a9c92e1d9ff7c7e1c35c208c93f8 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/59cea85511b634a99028cb73ef0e73fb1e194b5b ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/efb5b4fc9229f0baa66b928cfa4ba6f6d1315643 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/b4ae2c840870ff9cd6f6fe1f39ab4f00c5e87b08 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/8dffae4069115fdb3dac902eee0bf2c9cbc39ce9 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/f71107495bef44a7d7a9108dcdae2eada7815986 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/c835926b3369ad8f8dbe277e6caa9c995db6342f ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **streetviewpublish:** update the api https://github.com/googleapis/google-api-python-client/commit/35f0b1b607af6386790a6ec49541f87bc3091453 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))
* **translate:** update the api https://github.com/googleapis/google-api-python-client/commit/1f848a58c798840ee0ac4f768324c9f44b3cfc07 ([5dcb723](https://www.github.com/googleapis/google-api-python-client/commit/5dcb723c970982dce020aa7146697c70569458ee))

## [2.29.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.28.0...v2.29.0) (2021-11-02)


### Features

* **adexchangebuyer2:** update the api https://github.com/googleapis/google-api-python-client/commit/49432a596a9d2e0a014afb2c57cc0ceec37aa403 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/faedd49d24634e1646e15cb79a983391a6938faa ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/89fc0743cff2c64a438339003fc1c8fdf99938dd ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/8c2010464ec7a8aa6ffe8a044ae44ea0ab199f45 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/c2acfdbefef85f8a4696ae467bd61d05db25cf31 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/04ba8ef034ac1fd69e8e641c585e762e19078806 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/3c92c46132922d77598527fc98780edca5978ce2 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/037b9e1d5c9865af22a3c70dc44542ea3ce547dc ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **datafusion:** update the api https://github.com/googleapis/google-api-python-client/commit/fc6d716e71875ea73036e576bbaafb2826e01e1d ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/08353cbe37fc4c0dcc1311efead553797067417e ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/7974abc07dceffbc9fdb5365b706ed5e1a9899fc ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/13220f0704b0d5b954520307a6702efead926e5e ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **gameservices:** update the api https://github.com/googleapis/google-api-python-client/commit/ea5f2216765868a1d6e48995f23b74709ca5ebef ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/f4ae68ff69c32b5708f1e5f735cb03f3184f7650 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/5c430ab79811ae3565a83d57ba06e0d48560f791 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/3ad9f05ae340101c6016e4ceeef52661d0c01e21 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/992b9f851e871feb796485e6af936a3d05899e4e ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/972e716c233348d6e5d686f3718607a42e7d728a ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **oslogin:** update the api https://github.com/googleapis/google-api-python-client/commit/1ba23c68428c3c07a778f25dc9fc10998022c414 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/cc7fd94a993048d6ca7cc34e42c4536df6eeb93d ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/2da594c083639420e285d70d26483e46df9fa1a0 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/c16b96450466eb72e8122fc8aca0ce010a113350 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/c502728bfd31e520d4f5f06cc763dc2316cbb221 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **searchconsole:** update the api https://github.com/googleapis/google-api-python-client/commit/eede698004d718213b315b3728793a967a92e87b ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/9f0148f2f0f035b9e3c7d73dbd95a8f961ef3eb1 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **tagmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/fe4351bca507192a682440fa52f50eb98cef4434 ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/d8afe7c7e0a556d31dc904e8878c1bf884a375af ([a41c7b9](https://www.github.com/googleapis/google-api-python-client/commit/a41c7b9247ed1b9f335c40bc4d24c0660331191a))

## [2.28.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.27.0...v2.28.0) (2021-10-26)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/34eef11ba78a6e8eda0ec4dd8348e240ac637122 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/8666e3e7a134d27f832c00ef8fff2e8a5b601774 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **analyticsdata:** update the api https://github.com/googleapis/google-api-python-client/commit/a362e49252915c7da2fe88bfaec9eb7f9c217b11 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **analyticsreporting:** update the api https://github.com/googleapis/google-api-python-client/commit/ec6bf30c38ccf0f258c9f0267c6477b233483702 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/1a6d12e5a619d753e17041696fdfa84626e952d3 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/afc34eebbe98c284718489b94df8bc2293ee31f5 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/421f4d14a998f3da97fd979647b5e05287027679 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/ba90d3f0889eac4fb061bbbe913c31eea57c94bb ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/f06247e899ba2de5d2c1f0a8d6e8cbb0569143aa ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/15898963782a0649d6cb3a0a0c7ba1566b86b853 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/8f976a93038ee562d5ed0c9937d52e4b5e2cb8d6 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/b7876fdb21b0eeab9c07a73bbf0ca43f5f509906 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/742a2f738031268771d7146b64ff0e743df79596 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/117de7bdb601d11ce48c4ad64225d6d207f0597a ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/6abb35b4ba36bfa81516994b9f95a426fa5bbaff ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/59646721f76e0c02a2185111f9adf38d5c134fde ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/3508025ee9545033bc424396f2776916cbe1a3e3 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/851dba5e0f09a3dad06f3c8476d1c19da1a5cf93 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/b62aef0cc1bd0f5f10e1828d941616163136b2f7 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/50c48dfe6b63c9b7ff9deacc140d510cb0c50b50 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/eafbb600bf57440c024be19160c275074c6da03a ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/c6c8169a866814c2f4cbd622ad005d37442204d5 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/ff7bf38f27e52634ef2b9c661d84c9118675944c ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **oslogin:** update the api https://github.com/googleapis/google-api-python-client/commit/c26d08f8dc0507a366afa20e899cdbe90af9e82c ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **playcustomapp:** update the api https://github.com/googleapis/google-api-python-client/commit/1898032f15649aaa4bb8469fbd05743e39fc2a28 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/8eca373bb25b2dc23dfd6c9fdd09420b3c415521 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/7e832748505a52c0b0d2f94163cbedcffe09fcf7 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/1a3763caea5a3b4d50d0981ee4f52cc234fc1223 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/0901d055b0b30eeb9312881cbacde771d647ee56 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/07237cd66afac512e9962069312cf0bb796b0f39 ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **texttospeech:** update the api https://github.com/googleapis/google-api-python-client/commit/6622bd866cc45f42b37a57737872af0f90631e5f ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))
* **vmmigration:** update the api https://github.com/googleapis/google-api-python-client/commit/e29809a6548a53233925e410d2126d6e0b1600fa ([12d387c](https://www.github.com/googleapis/google-api-python-client/commit/12d387c95170487c8da93d4db25acf0bda4a2d2e))


### Bug Fixes

* manage JSONDecodeError exception ([#1574](https://www.github.com/googleapis/google-api-python-client/issues/1574)) ([7d63027](https://www.github.com/googleapis/google-api-python-client/commit/7d630270758459225f7169a03e9a6973b9e5ad82))


### Documentation

* update thread_safety.md ([#1568](https://www.github.com/googleapis/google-api-python-client/issues/1568)) ([0b400f9](https://www.github.com/googleapis/google-api-python-client/commit/0b400f97be45808ade211ca8291b2e1d9476bde1))

## [2.27.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.26.1...v2.27.0) (2021-10-19)


### Features

* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/cdbabdfbdaeed465b667852cef415fdfa7d1024a ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/dcab2830e6a0cf09999149e0d0d84d3a8f3d26aa ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))
* **localservices:** update the api https://github.com/googleapis/google-api-python-client/commit/24da1cc0aff78ef70988e6287e5e55fee20ba8ee ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))
* **networkmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/d0e5a726e9cb4098527bd60fe6818b7c307a865b ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))
* **realtimebidding:** update the api https://github.com/googleapis/google-api-python-client/commit/716ded31624c382be7ecf55ec2de87560b7592ef ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/2aa456adabc7c81cea0061d8538473e3b8980d66 ([f4773f6](https://www.github.com/googleapis/google-api-python-client/commit/f4773f6f0c26b43ce0013c24db1847a3ea3f8899))

## [2.26.1](https://www.github.com/googleapis/google-api-python-client/compare/v2.26.0...v2.26.1) (2021-10-12)


### Bug Fixes

* disable self signed jwt ([#1566](https://www.github.com/googleapis/google-api-python-client/issues/1566)) ([623a71e](https://www.github.com/googleapis/google-api-python-client/commit/623a71e73d33b8474eea20e800c01d0f80dc8b81))

## [2.26.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.25.0...v2.26.0) (2021-10-12)


### Features

* add support for python 3.10 ([#1557](https://www.github.com/googleapis/google-api-python-client/issues/1557)) ([bcc507f](https://www.github.com/googleapis/google-api-python-client/commit/bcc507fd7e0ba338cba4afc9c93d9fc577187425))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/be347fe46fbee592c9a97d405655ef9a121b1d15 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/594b20bfc7b724ab1b19b3a8f1df9783f82b25c7 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/59606ed1d543608549a574ac1229d20c970399de ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **area120tables:** update the api https://github.com/googleapis/google-api-python-client/commit/f35db63f3e1146ee870334abfd317f168f098600 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/ecaafc4d06c170ac5e1cab7127884a4ea0f17a4c ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/7f6e2e7afba57f065155dc329fd6b7fc1c57c897 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/b6310c5ea4221a69c71558b8911f817a99987b18 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/01aebc9962e09b7605975e2eee967ac9362bca24 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/47a79355df5a7e4a87cbaec761c3246abb121fe0 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/14e2dce00734d9b58456787bf14752e4b83d2381 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/3e8173dcdf327abec4f7927cad565a4fdca7382d ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/fa101412c120778403c48795988e884a9d70f5ea ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **domains:** update the api https://github.com/googleapis/google-api-python-client/commit/9217f6280301716c31544762964c61dbae6deb9d ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **iap:** update the api https://github.com/googleapis/google-api-python-client/commit/178edbddc9ff2b40086d3e1dc1d30757986bca80 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/6c7bd384ce9e2e8504a5d97119fbd5bc1527f879 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/89f87e5122b240ae364ece7ff5a70aa4da3c5d76 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/5e0bac188a099153b52d63500667efc3790d8f9a ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/8d4f2af1eb762bb626f94bde61614e482477c83a ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/b74f86c26805582014e9c462a8a6a02321612a62 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/1fe9ba81f62cf517597e12c86a6c0ba7613da7c2 ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/1e3c477f32ceee89c347f322d2e5e54eb9cbebef ([1c9dcfd](https://www.github.com/googleapis/google-api-python-client/commit/1c9dcfd348b6601c1c5ff0f4f71aee262256377e))

## [2.25.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.24.0...v2.25.0) (2021-10-09)


### Features

* enable self signed jwt for service account credentials ([#1553](https://www.github.com/googleapis/google-api-python-client/issues/1553)) ([1fb3c8e](https://www.github.com/googleapis/google-api-python-client/commit/1fb3c8ec61295adc876fa449e92fe5d682f33cbd))

## [2.24.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.23.0...v2.24.0) (2021-10-05)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/06b9b644a64de8853e018fae8e6f6fe2b8980b1e ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/4fece56ae77c96eb2bc2643da1a8f6c8b336f2ad ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/ac11e4444d0ee25cff4b1c57b229c88fce70009b ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/0f65c13243634ac929fe9dadfd876910a1b308d9 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/9f7352c2437557e01bdd3f9e244b7767da17a80d ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/b601ea2ca0cb082af81b1d8b68bdf28d527079bc ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/47661216e6187e2c3d7b7fe328f59d3d9017742f ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/139d65aa6892442083268661ae6863dc63641b66 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/d9533ec30d6d97c93b83a4a59704bef28f67ad70 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **domains:** update the api https://github.com/googleapis/google-api-python-client/commit/fc7e6e07f7260956c8de5cd6fb3270e4b5c90108 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/2a905ea91b12e366a1f68f7db537cb84e3f022ba ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/25fa0e230f58c0840f5002b7578ad21e68079a19 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/e987413f92bf1e16c672a6598a1c363a6457c858 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/4562c5b68a8b7ba55e4da015ba4f34ffa49270ff ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **networkservices:** update the api https://github.com/googleapis/google-api-python-client/commit/6887234c303d04e7ac343b38cc6b556c09bf552d ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/bec27e809d0d67b017971a105900397575d4838d ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/87d70bbf7c05f0f3d8bd4af3ac0c65514cd60b23 ([9d63883](https://www.github.com/googleapis/google-api-python-client/commit/9d63883a02db38ce0464130f170199d8f4bb86b2))

## [2.23.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.22.0...v2.23.0) (2021-09-28)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/c14c42a82fbd61df00b690daa328cea212441f59 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/22e6b63271836d2b195191c0711d3e815d7b3f29 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/5325b3654e42e393911f088e9a8358aeaf733c03 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/df08fb1f3823a5edc96e6caebe24df66e943fa36 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/eaa0b250682d593572168427d92b0c3b9438a503 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **firestore:** update the api https://github.com/googleapis/google-api-python-client/commit/89ee485ce0646fb14d4f4e1d7aae095e504cf4be ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/982014c5e33c29f2e0030b950b2f2ac27afa3f8f ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/440201ddeeae876ab83863def611ec39649d397c ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/58f1c1ba076ed6ecc389ddf66d0c5ac609cd9d17 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/53d51411d39049a98df6909ae16f9c5dfee4f432 ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))


### Bug Fixes

* **oslogin:** update the api https://github.com/googleapis/google-api-python-client/commit/e940d95d04a6aba60b89ece3fd630cc0ab5cde2a ([ad81f3d](https://www.github.com/googleapis/google-api-python-client/commit/ad81f3da411eb38e48137cb67f22a718498bcdc1))

## [2.22.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.21.0...v2.22.0) (2021-09-21)


### Features

* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/493de7636af575bec7e3d646c77d81a4278891e7 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/827a98a27eb06dee06080e01edc1b9d1304bae67 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/967d539cb9dcccfe2eea8fd81e05989f1bd92975 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/fd55971dcc7913faa7c90614e1b44122da9f3c1d ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/be52e3f77f0900ea3369a3f1145702832ea2167a ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/c422dda8dc607554e34899c964c36b32c554bb61 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/9357bc2b4b507ba98fd17988eb93e0c08da00bc3 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **datastore:** update the api https://github.com/googleapis/google-api-python-client/commit/ee1091a834aaf37e6b2a279f901543d43152da74 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/02e062eb95ebadf2f8002c34424a7442d327c765 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/29bd379b11ee39b49d7452f0e9d7aada1536a22f ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/438b148616d638783b17bf7fe060cdb57a8bc473 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/8f732ecf65df8e7aa8ad58258ed5d5a0dfed62ea ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/655a50711fb06b94a3b33a173611cc39cfb2553f ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **pubsublite:** update the api https://github.com/googleapis/google-api-python-client/commit/fc27fe7319f659032e2c3e9fe7be24224dca9fb6 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/de851d225affb67ba9819e9d4c81dc14bc95dcd1 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/9e472d5f1b8f31708fd535a3a8575f0510dad5a7 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **storage:** update the api https://github.com/googleapis/google-api-python-client/commit/6117646c93e672eb34816b6db4d2b84c3c046071 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **sts:** update the api https://github.com/googleapis/google-api-python-client/commit/9e0f476952df90e2fb9b6df287c2ceb2a5417c84 ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/2624f80fe82466181d853c35138e04064b1edcef ([312da31](https://www.github.com/googleapis/google-api-python-client/commit/312da3170e29ba6680fd4dfe4e12099ac5d9e7f9))

## [2.21.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.20.0...v2.21.0) (2021-09-14)


### Features

* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/0e4fed7f1e08a616cbc81243c24391bc20ce5edb ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/04e112ce89d6ddb3aeaae889c2de36070d6c2814 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **bigtableadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/6b77931c3c9aba59d5b326c570a2080252c8beb1 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **cloudprofiler:** update the api https://github.com/googleapis/google-api-python-client/commit/3009ee3c238ae1fa51c529e9f187ec26693138a4 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/e5d01ecee51da0c7a2543b833a1395a94c27bef6 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/fec73562a93b5a532bce6c91f0d30ec4fbd54ddb ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/22caa4f2f8ecb0f0ad6cfac547f9deb76fdcbebb ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/444836b9afe8d3eb8d52a1431652bfda1ad3288b ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/2f3173aa4b4d154c909eea853a0c4c306834e0ab ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **ideahub:** update the api https://github.com/googleapis/google-api-python-client/commit/8ebf9d2bd419561d5eacb78823aa1fc519fe2710 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/393dce7a3e584ad6be58c832ec826fe3b44e353b ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **mybusinesslodging:** update the api https://github.com/googleapis/google-api-python-client/commit/c51a0d15e634c2ab1c7762533f33d59f10b01875 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/bf6e86f6ee8c3985e1ce6f0475ef4f8685b52060 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **streetviewpublish:** update the api https://github.com/googleapis/google-api-python-client/commit/c8cf30cd67f5588d7cbe60631e42f0a49ea6c307 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/855cbfea1f6d46af07c4b80ab26fc30ca46370b7 ([e5e87b1](https://www.github.com/googleapis/google-api-python-client/commit/e5e87b1ca5fb6e81f6d83d970c3e4f683ecdcdea))

## [2.20.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.19.1...v2.20.0) (2021-09-07)


### Features

* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/59348e4809ff48906ffa356a0ecc867eb66376bd ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/a358ffd61a7671a7b3a90ccc329393feb80bc932 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/fe54736e2583dd4f9efefa8fb5a6378741d6bf87 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/5b89c7b9eb3abee497fac27f2ba12208b257240f ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/36050a3ad6fad1e5aec6c18085fbcad1564ceb1f ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/c5bac63feeadd4cccc635d69af7e0f32a5df5bc3 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/e442b58fc9abfbbb37dc5b50cf17ba8dea508cba ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/3f4ac75311743c0b3e77647f3085374b5d898d01 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/0ff4fae98fadd0e31eb09ff81656b87201d75d2b ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/4b0a7ed0cbef5031f7df162e8aa7629ba9073dc3 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/ab13790877b89e112fd27b738462077c45408557 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/b168cc69436840e8c9a170863b13a4db253b9f5c ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/88ebba5edbeb6dab547a6c57541f13dd13b95e23 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **jobs:** update the api https://github.com/googleapis/google-api-python-client/commit/eaffca049c02851d7c1b3a795d901e60616430df ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/ad3f2c91960b905126ae47c0777b27704aa02c64 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/7317835fe784c723ed6e290ab3da515b68a25c5f ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/ec0c06297952f922adfa6b4c265577846d2493d0 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/234d3f983a92fca973fcc42bf8e69e470f50fef5 ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/f30d144526f01a5a69832166d4271b2288fdabad ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))


### Bug Fixes

* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/78ee7f700efa8d29a4a1ca3e23f1381c4d04c86a ([2da5ed1](https://www.github.com/googleapis/google-api-python-client/commit/2da5ed1b0a7dc22442eda584518ed46ef518acec))

## [2.19.1](https://www.github.com/googleapis/google-api-python-client/compare/v2.19.0...v2.19.1) (2021-09-02)


### Bug Fixes

* remove repeated calls to self._get_reason ([#1513](https://www.github.com/googleapis/google-api-python-client/issues/1513)) ([d5cf4e0](https://www.github.com/googleapis/google-api-python-client/commit/d5cf4e0b1537eeafdb96ae831bbdffc5f1c6a94c))

## [2.19.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.18.0...v2.19.0) (2021-08-31)


### Features

* **analyticsdata:** update the api https://github.com/googleapis/google-api-python-client/commit/197540040eaedf672e608435ab0783e4ec203376 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/d253dad6da1a4e0ff1bfb225de9a93ec0b5bbbb5 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/d8c9d9b57835594456c766421e29c9d94a9f09fc ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **bigquerydatatransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/9044b191958b077b84fad16e3f8f93a03b021dce ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/795df26b99759db8f2e45a876b9c1374e2fc14ab ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/5fe2f9ccbacc1a34f16750eeca103124fb4df48c ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/24da17a1f30d97483c3da5d4fffa209cdae5d445 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/bb6c83bbdcfa0867bddb2305c26bf5aced0a4fb9 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/1c2b5b24e32a9587f84e7240e2ebc39576760841 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/bb9bbeaebed4bb164ec1894896e9011253cd65cf ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/f5e7af12443c6eb9130fd62257c78d8339e76a08 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/c9ba1f1852ade510cb9c89c92134b5ea95f7b9e2 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/a8b34005d6ef733ed7230890d8b515a3b80334ec ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/0f222f72fef0fbad5d47c0b054cb695fc99317e1 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/fbfb3cae7338b252f45a9417d46e1842bf2651e3 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/c21f6c964fd613125c920dede0aa4ad46288096e ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/4ea8b8d219de81728f701ca600cf38cec237bc3e ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/abde26f80fd8b856785c60bdcc8eac1233c67980 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/55ba494a751bbbf6f8bbf79a68249b6b4e062748 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/9f85c13a423d972707db785c03c832948fc4ce31 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/69301238fcd311486ba88209d9a1f746b51c1451 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/11b0c0eb16bb850077fc97da2b6cc29ffe4378b0 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **people:** update the api https://github.com/googleapis/google-api-python-client/commit/8a6dc23bda9dc7ab2c39d22e307590fb1c6e15c0 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/552d62b418d122831f0b4a38f577b4e106c6a070 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **sts:** update the api https://github.com/googleapis/google-api-python-client/commit/701b09cd34bf5a16d912b967e72fd23da77c26ec ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **workflowexecutions:** update the api https://github.com/googleapis/google-api-python-client/commit/26e7f6db0d773b7940b6c072b1f383c6edefd9f2 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/805e784420807e19b6e90cda17b03e74c50e7185 ([8bb904c](https://www.github.com/googleapis/google-api-python-client/commit/8bb904cc1545bbc473368259736e2bc8e7e82b3a))

## [2.18.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.17.0...v2.18.0) (2021-08-24)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/8e0c67f316381ec1ad358a079207215293093603 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/9fd19ee8a70661be02219133dda1b80d71ac4f4b ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/9727d32278b91dfa30d4c8c597755323741f8cd4 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **bigquerydatatransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/0b36baa0400731507365bf477cc223729d5a109d ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/c138aff559b32709a8a81c271ab5c0c48ea3acbe ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/3740a88b497c25e6a5aee22f873c33117034f8fa ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/07d2f4383aef325a7351831909e6cfc4b4b9f889 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/90b095a5de68d5aebcfbea16078b4727774366f4 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/3d6892c775b31d0ed6caead07666e423dccdba62 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/1676d9f17b499d3bb13f80ad9c4fbd0621961a41 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/98682633e8d244ca7bbf5b3726ed305e338a1cdd ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **ideahub:** update the api https://github.com/googleapis/google-api-python-client/commit/942102dcc79691866f8febbb732e477d0e5227b4 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/97169382a9d0c80bf56af157a16c5b96cb95e6dd ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/588812ffa314a68be1be61e229a187aecbe587e4 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **people:** update the api https://github.com/googleapis/google-api-python-client/commit/213598c2a41d6724368e1089bc3cbcaa0b2932c5 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/74bee354cf1dbaf388de26e756e9aeebe0baa311 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **slides:** update the api https://github.com/googleapis/google-api-python-client/commit/623c740d1333cfea2b5946cc22ebcc2c44a2197d ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))
* **tagmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/98664145c692ed1ca947bdb081a7463897655d28 ([96afc04](https://www.github.com/googleapis/google-api-python-client/commit/96afc04eaae89dcaae4aaf7a63d5dcbf4b1e7d57))

## [2.17.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.16.0...v2.17.0) (2021-08-17)


### Features

* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/41ae79b3554ffc9f1622e44757751009eeed76f8 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **bigqueryreservation:** update the api https://github.com/googleapis/google-api-python-client/commit/b0483aba20b17580b400283fb0073f07715bf254 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/270312294f1cf89041825b0f31bfcf872fda9854 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/30c122278e75a99b5b2a6ed330f317015134a23d ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **cloudscheduler:** update the api https://github.com/googleapis/google-api-python-client/commit/0405b1db79fe87305be25ba4f9389e94490040a7 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **contactcenterinsights:** update the api https://github.com/googleapis/google-api-python-client/commit/3abcf5334053f5612fd79163f2c433e5793ee782 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/c4935840495b1487d4be47b63f6c416113b9413f ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/21f81c824089d0060dbd624f9755eea554464af2 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/d997b2c0d13203ac29b55c19858ef375380a5b7b ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/68588ad4744aa3c7a3a0afa12a1566f54ab3be94 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/b975c34568f62bbf19f67f4731fe091aeeda8a75 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/c2bcb7081a4f656b9e136ea38637cf262b60f387 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/3bdc7b9d0854918ef65ccb4a3798d2f3f3b19d70 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))
* **sts:** update the api https://github.com/googleapis/google-api-python-client/commit/a8ebc2bef5d0ff6c449d65fcc9c0554c1f388985 ([cdf480e](https://www.github.com/googleapis/google-api-python-client/commit/cdf480e8145d58600a5224efc68ba2ace973ef62))

## [2.16.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.15.0...v2.16.0) (2021-08-10)


### Features

* **accesscontextmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/30216a669249442cac8f0fb8bb347b1352d8f087 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/39b084706537111e8403be6e69f0fc9d82b2f383 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **androidpublisher:** update the api https://github.com/googleapis/google-api-python-client/commit/cf67afc22e94f856773895a4e603e7a9a6bfa20b ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/4485c5f3b32c9bda4f50a2a96c5870414f7d870f ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/995336984e11fb9f91308d14a68faf8f3091d1fa ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/eb7a571470cef08641224558a7bd8eaa07a41bad ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/304bbde2360066caf55575e3be5a04fdc8bf8b09 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **chromemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/0ba28b47236a81a996a3607567b61ab38150617d ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **chromepolicy:** update the api https://github.com/googleapis/google-api-python-client/commit/5654776fdc8361aa0703a7dca8069b576a1b2f73 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/792aa5593ea64ceb4b565e950e153e396274b3b8 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/437e37f1c36268464f90e075ffeaef61580de237 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/6b06387ca29e76d26f257c7a4eb6864fe27e082e ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **cloudchannel:** update the api https://github.com/googleapis/google-api-python-client/commit/0b0444ea192f79c5564745be8b1d52b52a74d1fb ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/7dc278459cbd32bf15b39633327743cfa0beeea3 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **cloudkms:** update the api https://github.com/googleapis/google-api-python-client/commit/ebd3f49f78738792032e431b73233ae0c458bae3 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/92131bff38ab7644e549f3d71f9c0a84755455db ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/9ab94f3f4c2ccafdf8b298dad8c6a5c2aa61a606 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/d446928f941d858022f0e1a1911bbf185920159d ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/53d8b4b3e3c5d16ffd14ba1af1cf1769d9249067 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/0feb05616eb28db7c35e128ebbf338b63446b8cf ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/b49bfdaedbed3378b061e85f937a36e97732fcd4 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **iam:** update the api https://github.com/googleapis/google-api-python-client/commit/0832247d126965b472a271167028499f015de1ae ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **ideahub:** update the api https://github.com/googleapis/google-api-python-client/commit/24483a4f512922f809fc8352b9407e606856b0e2 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/897beb3754da50e117292f5954265076804acb7f ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/dd83236343d603e964613b16e9afa25eff60f97c ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/75a5ced2b372723c21d45b172dd69e0bb91c5509 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/6ffbe182425ec217230fc083e217676e915bb786 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/c8b511a21f7fc7f2471d5f7a3b2d3760e4f8a629 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/e079d43be4291ca10be7caf432012c6553e0398e ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **oslogin:** update the api https://github.com/googleapis/google-api-python-client/commit/d3ec653bdd293a63ae0b3772ce83e1fda73d5de5 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **pubsublite:** update the api https://github.com/googleapis/google-api-python-client/commit/4287a7d537741391a9afe9e669b98010ed4fc0ab ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **pubsub:** update the api https://github.com/googleapis/google-api-python-client/commit/06dfff22baec2551508b93e29e4c36fa442ab299 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **recaptchaenterprise:** update the api https://github.com/googleapis/google-api-python-client/commit/ebfeb8fc00a1c6a8603b35640845c5cdacf53cb2 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/01f2d6cc989ce337537a51ead8ffd3d6fc7e6c5d ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/601afcf08fd96421b64ef4c6f098f09f0748ce69 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/689fff21696add03b8c3ab843374b6bd2dd3cc16 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/41d51e34759b181692ed96d9d490a9cfc5a28459 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/24564836842f792e9373ea505d97e775f64a5960 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))
* **tagmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/47a522aac79ae9283a0c7ee7a2d0716e605d8c21 ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))
* **transcoder:** update the api https://github.com/googleapis/google-api-python-client/commit/1e0b0854e31f52013a8c5423efbd5e34c953e08c ([3e4b5db](https://www.github.com/googleapis/google-api-python-client/commit/3e4b5db2a4aeceb4b99f280e8a843c65284c2f9f))


### Bug Fixes

* **fcm:** update the api https://github.com/googleapis/google-api-python-client/commit/f1dd412cad2a2cdd1863bb2942cf07fc6a42b649 ([b539cc4](https://www.github.com/googleapis/google-api-python-client/commit/b539cc475e81dc6f0d3c0f75b1e0445bb79fe9e5))

## [2.15.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.14.1...v2.15.0) (2021-07-27)


### Features

* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/70810a52c85c6d0d6f00d7afb41c8608261eaebc ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/a577cd0b71951176bbf849c1f7f139127205da54 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/9066056a8b106d441fb7686fe84359484d0d58bc ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/b123349da33c11c0172a8efb3fadef685a30e6e1 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/c525d726ee6cffdd4bc7afd69080d5e52bae83a0 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/13436ccd2b835fda5cb86952ac4ea991ee8651d8 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **eventarc:** update the api https://github.com/googleapis/google-api-python-client/commit/6be3394a64a5eb509f68ef779680fd36837708ee ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/817a0e636771445a988ef479bd52740f754b901a ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/bd32149f308467f0f659119587afc77dcec65b14 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **people:** update the api https://github.com/googleapis/google-api-python-client/commit/aa6b47df40c5289f33aef6fb6aa007df2d038e20 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/d39f06e2d77034bc837604a41dd52c577f158bf2 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **securitycenter:** update the api https://github.com/googleapis/google-api-python-client/commit/999fab5178208639c9eef289f9f441052ed832fc ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **speech:** update the api https://github.com/googleapis/google-api-python-client/commit/3b2c0fa62b2a0c86bba1e97f1b18f93250dbd551 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/cef24d829ab5be71563a2b668b8f6cf5dda2c8e4 ([a36e3b1](https://www.github.com/googleapis/google-api-python-client/commit/a36e3b130d609dfdc5b3ac0a70ff1b014c4bc75f))


### Documentation

* update license to be Apache-2.0 compliant ([#1461](https://www.github.com/googleapis/google-api-python-client/issues/1461)) ([882844c](https://www.github.com/googleapis/google-api-python-client/commit/882844c7b6a15493d0fb8693cd5e9159e3a12535))

## [2.14.1](https://www.github.com/googleapis/google-api-python-client/compare/v2.14.0...v2.14.1) (2021-07-25)


### Bug Fixes

* drop six dependency ([#1452](https://www.github.com/googleapis/google-api-python-client/issues/1452)) ([9f7b410](https://www.github.com/googleapis/google-api-python-client/commit/9f7b4109b370e89c29db6c58c6bd2e09002c8d42))

## [2.14.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.13.0...v2.14.0) (2021-07-20)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/a2e2d768e5412072ef11891ae7fb9145e2c4693d ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **androiddeviceprovisioning:** update the api https://github.com/googleapis/google-api-python-client/commit/83151f4ebd2992a53f815133304d8cb2c72d50c5 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/8e39e1ef5482735fbaaed3be74ee472cf44cd941 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/ebd9b97ec74f0f257ccb4833f747f88d02075926 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **cloudfunctions:** update the api https://github.com/googleapis/google-api-python-client/commit/06332af99b1b1a9894bf4f553e014936225761de ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **cloudsearch:** update the api https://github.com/googleapis/google-api-python-client/commit/4aab6137bb350cb841a6b48fd37df67a209ba031 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/c65f297a775687fbfcbae827f892fc996a3d1ab1 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/af28eef0b37a5d0bb3a299f9fd9740b63f9e23bd ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **dns:** update the api https://github.com/googleapis/google-api-python-client/commit/e2ba913fc51f78ce4b9fb6f9de97f61bd35cd356 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/d1b9df7ee0a041d4cf632a77a626764c37e72889 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/0cd6277980d02363e3d609901d12d62b594adc92 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/f8c39017aa392c0930ab79cdf7f828fe1e97e313 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **firebasestorage:** update the api https://github.com/googleapis/google-api-python-client/commit/66b6961871fea5b1a41a5b8359d7f76d6e390386 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **gameservices:** update the api https://github.com/googleapis/google-api-python-client/commit/31fd4dc22bd1e615caeafc22482caad65bbd55e9 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/58ae34d8dfb4a7827b4f56e99fd48dedc64b4364 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **ml:** update the api https://github.com/googleapis/google-api-python-client/commit/15e0de32f2ea94d6ed3e0c18cd6e59cc239b37e7 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/2b52d9ff5341caec20577538c0c4eaf83a896651 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/c4698a84e526ab47710d2bde22827b337f2f480c ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **people:** update the api https://github.com/googleapis/google-api-python-client/commit/a646e56d40f2c7df40f48d42442c1941fc1c6674 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/ef997b0293c0e075208c7af15fa4e9bd6f29e883 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **secretmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/489541e760eae9745724eb8cad74007903dd4f5b ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/acdb8fccfbb9f243f06dfff68d61cee2e58c9e45 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))
* **testing:** update the api https://github.com/googleapis/google-api-python-client/commit/e2bde192a3e20ebd00995185cd92b47a086be8d9 ([0770807](https://www.github.com/googleapis/google-api-python-client/commit/0770807d690618cb51196d2c1ef812a8e0c03115))


### Bug Fixes

* **deps:** pin 'google-{api,cloud}-core', 'google-auth' to allow 2.x versions ([#1449](https://www.github.com/googleapis/google-api-python-client/issues/1449)) ([96d2bb0](https://www.github.com/googleapis/google-api-python-client/commit/96d2bb04f99d57f0fff2b81e8f4e792782deb712))

## [2.13.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.12.0...v2.13.0) (2021-07-13)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/96675a8d9158ec13353fe241f858201fc51b784d ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/add2fbdc3afb6696537eb087bc1d79df9194a37a ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/f8fae98db6d1943411b1a6c0f5a65dea336569f6 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/0814e009a4a11800db5b4afd7b6260e504c98047 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **datacatalog:** update the api https://github.com/googleapis/google-api-python-client/commit/99706059e58bb3d616253a1af2cd162b5a0b0279 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/d5f09ef30392532bcfdd82901148bdd3ac6eec01 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **docs:** update the api https://github.com/googleapis/google-api-python-client/commit/dc66f4cafba86baff6149b2f6e59ae1888006911 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/523fc5c900f53489d56400deb650f6586c9681a0 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **firebasehosting:** update the api https://github.com/googleapis/google-api-python-client/commit/c83ac386b65f82e7ba29851d56b496b09a29cf98 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/a407471b14349b8c08018196041568f2a35f8d4f ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **ideahub:** update the api https://github.com/googleapis/google-api-python-client/commit/c6b0d83940f238b1330896240492e8db397dcd15 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/863b333da7848029fd1614fd48b46cfbe12afcd5 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/17dc001e4649f54944066ce153e3c552c850a146 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/f3a76c9359babc48cc0b76ce7e3be0711ba028ae ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **slides:** update the api https://github.com/googleapis/google-api-python-client/commit/314d61b9ef8c5c30f9756462504dc0df92284cb2 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/62784e0b1b5752b480afe1ddd77dcf412bb35dbb ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **tpu:** update the api https://github.com/googleapis/google-api-python-client/commit/16bf712cca4a393d96e4135de3d02e5005051b6d ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/ec21dff96d9538ad6c7f9b318eca88178533aa95 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))


### Bug Fixes

* **keep:** update the api https://github.com/googleapis/google-api-python-client/commit/08fee732e96d3220e624c8fca7b8a9b0c0bcb146 ([1a4514d](https://www.github.com/googleapis/google-api-python-client/commit/1a4514d2862f81fc97e424cd550c286cda0fc859))


### Documentation

* add recommendation to use v2.x and static discovery artifacts ([#1434](https://www.github.com/googleapis/google-api-python-client/issues/1434)) ([ca7328c](https://www.github.com/googleapis/google-api-python-client/commit/ca7328cb5340ea282a3d98782926a0b6881a33ed))

## [2.12.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.11.0...v2.12.0) (2021-07-06)


### Features

* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/bc9a38bf901a63525fb4c7b1e94fd4ce5fb441c3 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/eea3c5c177aaded427fd3b5bab80812bf748ef79 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/2e31dd0b58d3c656df5aaa042994c637d0100f97 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/3a3b420d53aabe1fdf6ddca483a3d164f72d6268 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/78c0d8decbe640c522c45850c97002e7da12f4e0 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/a54737fe763fd288e54505faace58040cbf8920b ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **datafusion:** update the api https://github.com/googleapis/google-api-python-client/commit/f6bf3c6b92fbf7072798b987998bf55ee9276389 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/3fde9a3604e4811ce02f1062dcee9cef35b1ad51 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/79c556d389889fb0f48c8cc5ad5ab4a2caaab603 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **groupssettings:** update the api https://github.com/googleapis/google-api-python-client/commit/d537f96a20a699629fa85fbdeadb74ead3b32699 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/d3548c505e4b1065365584493d15f21a19639626 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/d24af68a9621fda9d7a576d3615178604a1482d2 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/cff9039529278d95cee936826b5406867c638430 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/46102d1726393f872420820e6200bb83cefd74b6 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **run:** update the api https://github.com/googleapis/google-api-python-client/commit/db18e29c7f616f212121960fe8efd6fb7cdf9b22 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **slides:** update the api https://github.com/googleapis/google-api-python-client/commit/68634cd565914e6003c851ec5f43fa2ff290afca ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/289512124fc77a69957b912f06e9c3d315aa0526 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))
* **storagetransfer:** update the api https://github.com/googleapis/google-api-python-client/commit/24895f156f10c03f2da686be95d8c70ea34008a3 ([a933dad](https://www.github.com/googleapis/google-api-python-client/commit/a933dad7e72d3093be480ce6af3965f41db1d193))

## [2.11.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.10.0...v2.11.0) (2021-06-29)


### Features

* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/1534f8926019f43dc87a29c1ca32191884556e3b ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **alertcenter:** update the api https://github.com/googleapis/google-api-python-client/commit/7a488d3f0deef3e1f106cff63b1e4f66ad1727bb ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/934358e5c041ffd1449e7c744463e61e94381ed5 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **analyticsdata:** update the api https://github.com/googleapis/google-api-python-client/commit/40f712130674cec09c1dd7560f69a330a335b226 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **androiddeviceprovisioning:** update the api https://github.com/googleapis/google-api-python-client/commit/81a0002a7051aeab647a3296fb18ce7973bf7137 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/2e6c78a93b2c0ee7001eb163ec95f9afc8f35575 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/125f74a61a94af17c01930841a79db46d3a059c5 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/59c51e319602741632201d2ce61a6b03f13e4003 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/e615264971ccee6eb9b450fe3d85614209c0fee8 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/ceddaccf23eb8b809688907cfdef8906cd77d65d ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **cloudidentity:** update the api https://github.com/googleapis/google-api-python-client/commit/22cd08b69b034c2cdfd854e1ac784f834539db3a ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/f494c63a42dc418559292c6269289317d9cebc23 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/e8aaabbc7670aefc4a745916fccb31424745f748 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/72cab88ce591d906ea1cfcbe4dee354cccb623f2 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **file:** update the api https://github.com/googleapis/google-api-python-client/commit/0cd409a2d15c68aca3ea864400fc4772b9b4e503 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **firebaseappcheck:** update the api https://github.com/googleapis/google-api-python-client/commit/9a0131b2326327109d1ba7af97b1f4808dd7a898 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/45ee6b28b86a43f44c707e15a7e06fdf8fce6a0f ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **ideahub:** update the api https://github.com/googleapis/google-api-python-client/commit/73b86d9d37f33aeaed74772d0319ba1350e54ed5 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/a07ed4558c93cb8f7fae49c7b353f46ccfea6c10 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **memcache:** update the api https://github.com/googleapis/google-api-python-client/commit/665ce5b47b9b3238dcfa201b9343bf6447df5994 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/9fd5ffbf37fb052323f5fa68d307c68391c519ac ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **ml:** update the api https://github.com/googleapis/google-api-python-client/commit/cf54d564915a558569c093287b448a7819e215f6 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **monitoring:** update the api https://github.com/googleapis/google-api-python-client/commit/d1ffbfc041f23f904cd8bc35a450871b2909473b ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **networkconnectivity:** update the api https://github.com/googleapis/google-api-python-client/commit/2cc462638aec61f4e775bfce883e725b104eeabb ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **notebooks:** update the api https://github.com/googleapis/google-api-python-client/commit/831ba938855aa4bdefafedf63e01af43350e7ed2 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/c04b4023477393cbb41984b14e0c734fc8587d45 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **paymentsresellersubscription:** update the api https://github.com/googleapis/google-api-python-client/commit/2cd5b1c2ef524f3ab00630508710cce7bee53574 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/8b6bd24e57a79f470c750ad04052f79a3cafe0fa ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **realtimebidding:** update the api https://github.com/googleapis/google-api-python-client/commit/fd514dc8d86182dc17698f3293144928535f709c ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **reseller:** update the api https://github.com/googleapis/google-api-python-client/commit/20226c4401956732772e2a563c7920666135e605 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/38d5156350b79a9933b2806f4bbe443043a33185 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **sts:** update the api https://github.com/googleapis/google-api-python-client/commit/190e13ebe5a4660d8825d3a8708559077a342bdf ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **transcoder:** update the api https://github.com/googleapis/google-api-python-client/commit/fbcacce6a17c1cae45b22f4a2058e730ec84b55a ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/5046950872559fe93b954dc9a4f71fd724176247 ([04bafe1](https://www.github.com/googleapis/google-api-python-client/commit/04bafe14efe7a6d1a7da03de89312062a4afa127))

## [2.10.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.9.0...v2.10.0) (2021-06-22)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/5a2e42e9a4631216c4883d5538c970a5faad59eb ([b1eafb3](https://www.github.com/googleapis/google-api-python-client/commit/b1eafb327669474d202bb2a430ed9e9561102db3))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/5fcc274bcd4a9a71a0a568e2771c443a2b2b20b0 ([b1eafb3](https://www.github.com/googleapis/google-api-python-client/commit/b1eafb327669474d202bb2a430ed9e9561102db3))
* **bigqueryreservation:** update the api https://github.com/googleapis/google-api-python-client/commit/63c00f6819408b943c2a7cc4bd2185828be173c6 ([3659137](https://www.github.com/googleapis/google-api-python-client/commit/365913780592552488cc5792d26b3f22b9e9ed1b))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/512fc42343fa946889ec155456a05f0d64969903 ([b1eafb3](https://www.github.com/googleapis/google-api-python-client/commit/b1eafb327669474d202bb2a430ed9e9561102db3))
* **firebaserules:** update the api https://github.com/googleapis/google-api-python-client/commit/7b2000437a01ecd25e4ba571049f62c5b6dc9d63 ([3659137](https://www.github.com/googleapis/google-api-python-client/commit/365913780592552488cc5792d26b3f22b9e9ed1b))
* **iap:** update the api https://github.com/googleapis/google-api-python-client/commit/18550fd0501057584ef6d2fa329f09b75dad97d8 ([3659137](https://www.github.com/googleapis/google-api-python-client/commit/365913780592552488cc5792d26b3f22b9e9ed1b))
* **keep:** update the api https://github.com/googleapis/google-api-python-client/commit/45eb6dac450c1055a6ced84332529b70b0a8c831 ([b1eafb3](https://www.github.com/googleapis/google-api-python-client/commit/b1eafb327669474d202bb2a430ed9e9561102db3))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/d2220014e787c2a2c90808cfd1e49a25cd783e72 ([3659137](https://www.github.com/googleapis/google-api-python-client/commit/365913780592552488cc5792d26b3f22b9e9ed1b))


### Bug Fixes

* **smartdevicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/772982044da691f9116073855e692f7793edacce ([b1eafb3](https://www.github.com/googleapis/google-api-python-client/commit/b1eafb327669474d202bb2a430ed9e9561102db3))

## [2.9.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.8.0...v2.9.0) (2021-06-12)


### Features

* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/3ed78879365ebef411b2748be8b5d52c047210eb ([33237a8](https://www.github.com/googleapis/google-api-python-client/commit/33237a8250e3becfaa1e4b5f67ef0c887cfc44a9))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/a715d2b2c5d5535f9317c5b3922350de2bfb883a ([0f0918f](https://www.github.com/googleapis/google-api-python-client/commit/0f0918f92a699753b52c77dd236ad84ee00a32a7))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/9fcf80b4e92dca6ebc251781c69764e42aa186b3 ([0f0918f](https://www.github.com/googleapis/google-api-python-client/commit/0f0918f92a699753b52c77dd236ad84ee00a32a7))
* **appengine:** update the api https://github.com/googleapis/google-api-python-client/commit/ffcf86035a751e98a763c8a2d54b70d3a55ca14d ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))
* **chat:** update the api https://github.com/googleapis/google-api-python-client/commit/47ff8a5cac1b7dbd95c6f2b970a74629f700d4fc ([0f0918f](https://www.github.com/googleapis/google-api-python-client/commit/0f0918f92a699753b52c77dd236ad84ee00a32a7))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/4862529435851dbb106efa0311c2b7515d2ad2ea ([33237a8](https://www.github.com/googleapis/google-api-python-client/commit/33237a8250e3becfaa1e4b5f67ef0c887cfc44a9))
* **containeranalysis:** update the api https://github.com/googleapis/google-api-python-client/commit/9a1c70b7df3e074fc9fbd0eebdaf75a91046078c ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/07a6e774ac185442a99437896eaee774946b5846 ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/773910fdf25b084aa3623d24fe99c8a1330fbecb ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))
* **genomics:** update the api https://github.com/googleapis/google-api-python-client/commit/8a1c8a67e7e5b76581cfa95ffa14c01019c305af ([33237a8](https://www.github.com/googleapis/google-api-python-client/commit/33237a8250e3becfaa1e4b5f67ef0c887cfc44a9))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/0fd49e0d39455077e39d850ac464635034d253b8 ([33237a8](https://www.github.com/googleapis/google-api-python-client/commit/33237a8250e3becfaa1e4b5f67ef0c887cfc44a9))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/0927c1989574ae4272e4f753f4d55c88af62d8f2 ([c3f8675](https://www.github.com/googleapis/google-api-python-client/commit/c3f86757bccb6b42552f87d37a645651c58d6c7a))
* **managedidentities:** update the api https://github.com/googleapis/google-api-python-client/commit/e96adbb1ba3e4e56d916cc28474f85543f17ad0e ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/87da2f3605ec1b8986324cddc33f2b5601d3e896 ([26aa9e2](https://www.github.com/googleapis/google-api-python-client/commit/26aa9e282e30ca9c8797ee5346cbe9c0b9ca65a7))


### Bug Fixes

* update content-length header for next page ([#1404](https://www.github.com/googleapis/google-api-python-client/issues/1404)) ([8019f2f](https://www.github.com/googleapis/google-api-python-client/commit/8019f2f96abc6a4375873becb2f17b399f738654)), closes [#1403](https://www.github.com/googleapis/google-api-python-client/issues/1403)

## [2.8.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.7.0...v2.8.0) (2021-06-08)


### Features

* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/e1ea8735612457f6f8b85226887babd904958b25 ([cb945f3](https://www.github.com/googleapis/google-api-python-client/commit/cb945f37130d2950801e02512761f061cef0b54e))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/73965daab29cd6ae78004ede62f8c6c80f5587a3 ([31fbcc0](https://www.github.com/googleapis/google-api-python-client/commit/31fbcc014f8642fb0cde7de47889b55a2eaf3f71))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/b8ce2754752f8157b84091a99594f9a45a8f8eed ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/a73f41e49d7ab6258bd722b4ee6d022c195975c2 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/097e3329e1e5de3ae416cdabc9a73e2fa63a09e9 ([cb945f3](https://www.github.com/googleapis/google-api-python-client/commit/cb945f37130d2950801e02512761f061cef0b54e))
* **dataproc:** update the api https://github.com/googleapis/google-api-python-client/commit/be0dde6ee43f4ff05396d33b16e0af2a1fabfc28 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/f7b0ebc0047427b3633480999ed28e0f37fa77f1 ([50e1b7a](https://www.github.com/googleapis/google-api-python-client/commit/50e1b7a1b5c337926c5d2b2f648f057d67431cd6))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/f6b1a8e2d291c2ac9d2ea590101bb3c8c6fbe6cf ([eb505db](https://www.github.com/googleapis/google-api-python-client/commit/eb505dbed724dbd07b151d06fd1b45037dc7e75f))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/72f3faea1be17c074dc566b33707dad37c9ba16b ([cb945f3](https://www.github.com/googleapis/google-api-python-client/commit/cb945f37130d2950801e02512761f061cef0b54e))
* **lifesciences:** update the api https://github.com/googleapis/google-api-python-client/commit/c524c0a316e4206c8b0e0075e3ed5eceb7e60016 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/54639a05ea77c1a067ed1e3b5df46b2c029c47ea ([4d1153d](https://www.github.com/googleapis/google-api-python-client/commit/4d1153db18a3edf86c5bb83149b4f1c0ba95f810))
* **metastore:** update the api https://github.com/googleapis/google-api-python-client/commit/c9632ee831b9c135f3a0c018b3fdfe73d7e698a4 ([7357b05](https://www.github.com/googleapis/google-api-python-client/commit/7357b05a33a3780716b77161f86f247d92d91903))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/5dbaaad34dec45eb5f5a9e98710b3ec05b4d5429 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **pagespeedonline:** update the api https://github.com/googleapis/google-api-python-client/commit/47d41c544376b1911261410235b63ffe3e5faa91 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/8f7ad0d176d61f9e9a409d7fe35b20c5f1c239a5 ([8759538](https://www.github.com/googleapis/google-api-python-client/commit/8759538c0ab491be1678db74a3ad538957610d70))
* **realtimebidding:** update the api https://github.com/googleapis/google-api-python-client/commit/34d5d2606070b0c6fef053d6b88a65be085227b5 ([31fbcc0](https://www.github.com/googleapis/google-api-python-client/commit/31fbcc014f8642fb0cde7de47889b55a2eaf3f71))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/ca30eddc3d583c1851cc2f70f37c1d9f81f4342f ([50e1b7a](https://www.github.com/googleapis/google-api-python-client/commit/50e1b7a1b5c337926c5d2b2f648f057d67431cd6))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/491bafaefd792deae68c24337ebd7011faeb723b ([cb945f3](https://www.github.com/googleapis/google-api-python-client/commit/cb945f37130d2950801e02512761f061cef0b54e))
* **youtube:** update the api https://github.com/googleapis/google-api-python-client/commit/981cfb0ae51df0d2f48152bb74f79840ca19727a ([50e1b7a](https://www.github.com/googleapis/google-api-python-client/commit/50e1b7a1b5c337926c5d2b2f648f057d67431cd6))

## [2.7.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.6.0...v2.7.0) (2021-06-01)


### Features

* **adexchangebuyer:** update the api https://github.com/googleapis/google-api-python-client/commit/3cf7a8dceb567f3c89c307f3496c381af91b0fc6 ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **admin:** update the api https://github.com/googleapis/google-api-python-client/commit/7bac81fc588ccbe7b5e6c75af52b719e73efd118 ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **androidmanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/877990251a43acbc447a1f2f963beb3bbfc6352f ([bdce941](https://www.github.com/googleapis/google-api-python-client/commit/bdce9419ca05d20e0eecd817f404f292a56ce79c))
* **apigee:** update the api https://github.com/googleapis/google-api-python-client/commit/37f31420ffc3adb1bdd23d7fc91f80701522aac8 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **bigquery:** update the api https://github.com/googleapis/google-api-python-client/commit/086d714317a73331fcfdf4027496c3b36354955f ([508c39f](https://www.github.com/googleapis/google-api-python-client/commit/508c39fa665c901d9d754aa31dc9d1af45469ec4))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/514acdbf2c7eeaf6b1b9773c63b180131418ff57 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/aab557d6c59a5c414d0ac0bc6349763523c9816f ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/eaf742d4e933744abc72c1808f1e5a16dccaa1d4 ([bdce941](https://www.github.com/googleapis/google-api-python-client/commit/bdce9419ca05d20e0eecd817f404f292a56ce79c))
* **dataflow:** update the api https://github.com/googleapis/google-api-python-client/commit/d979251cc4f8f537a875841cc0f6d86bbe0f195b ([38664e8](https://www.github.com/googleapis/google-api-python-client/commit/38664e8dec117413b8d27fc7230eb9c351d2c0de))
* **dfareporting:** update the api https://github.com/googleapis/google-api-python-client/commit/c83912bec60626d3388fbe749d7a395fa3bc6c22 ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **dlp:** update the api https://github.com/googleapis/google-api-python-client/commit/7e3d1c4ab85d50307d42af3048f9a7dd47a2b9eb ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/222030d8c1583f49657862a308b5eae41311d7e7 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **doubleclickbidmanager:** update the api https://github.com/googleapis/google-api-python-client/commit/895ff465e58dffd1f6e29dffd673418c76007e1b ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **firebase:** update the api https://github.com/googleapis/google-api-python-client/commit/6bd0412a11a1a55770415fdc76100b3c76a83a94 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **ondemandscanning:** update the api https://github.com/googleapis/google-api-python-client/commit/b77d12d24d17264123231dd86699fceada262440 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **osconfig:** update the api https://github.com/googleapis/google-api-python-client/commit/c541143744c4b077d0a044455a35d0de227a0bf6 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/1e0f4a6e5e0bfde1ba4c06223d7fb02f63756690 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/4350b35f065e8d651839ebcc047cfaec787b4f98 ([38664e8](https://www.github.com/googleapis/google-api-python-client/commit/38664e8dec117413b8d27fc7230eb9c351d2c0de))
* **serviceconsumermanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/e2046363f037151e02020ea178651b814c11761a ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **servicecontrol:** update the api https://github.com/googleapis/google-api-python-client/commit/facd7ecc18c129cf8010d19d3969e8d5b4598dfc ([ab1d6dc](https://www.github.com/googleapis/google-api-python-client/commit/ab1d6dc365fc482d482de197da7f7583afd04bd0))
* **serviceusage:** update the api https://github.com/googleapis/google-api-python-client/commit/b79b21e71246ab6935214ca751125c83b1990167 ([4c9ccb0](https://www.github.com/googleapis/google-api-python-client/commit/4c9ccb08aa866b5402c5e63c70306b5a3c121ba1))
* **sqladmin:** update the api https://github.com/googleapis/google-api-python-client/commit/f2bb5e677634a0866836353bc40b26d40b1d044b ([a940762](https://www.github.com/googleapis/google-api-python-client/commit/a9407624e954e34bfd989f64ed0f5be74c40d4c5))


### Bug Fixes

* resolve issue where certain artifacts would not be updated ([#1385](https://www.github.com/googleapis/google-api-python-client/issues/1385)) ([31bbe51](https://www.github.com/googleapis/google-api-python-client/commit/31bbe51739f966491f1be8ab67c500c65c049daf))

## [2.6.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.5.0...v2.6.0) (2021-05-26)


### Features

* **adexchangebuyer2:** update the api https://github.com/googleapis/google-api-python-client/commit/e1ebe49bc9e2e007c61188202f0345c96083c19a ([227f8c9](https://www.github.com/googleapis/google-api-python-client/commit/227f8c91ee006acb969a3950b7281e1deed14b69))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/432e17443fb2330b75a8cb9307ba98290fc08e4b ([e63d3a4](https://www.github.com/googleapis/google-api-python-client/commit/e63d3a43f29a5f8125272ce5303f869679963822))
* **composer:** update the api https://github.com/googleapis/google-api-python-client/commit/c2cb2746320fa7b6c1536028794f53576c0f1ddd ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/2cdcd0a21223a229e711778a3cf1b38c63521d96 ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **dfareporting:** update the api https://github.com/googleapis/google-api-python-client/commit/73f7d790e1585322547fe7cb39c8f36e7b400121 ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/8edd852f294eaccfa6a0e7288d54a2d751f53506 ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **displayvideo:** update the api https://github.com/googleapis/google-api-python-client/commit/4f37d8b0d43f2172fdae627605947b3ba15b06c2 ([227f8c9](https://www.github.com/googleapis/google-api-python-client/commit/227f8c91ee006acb969a3950b7281e1deed14b69))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/b2c1bb00a3b41e9cdfe925dd90aa4bc677a55e33 ([108b819](https://www.github.com/googleapis/google-api-python-client/commit/108b819d986cf2cdfcb3db643afa82949e33edc6))
* **gkehub:** update the api https://github.com/googleapis/google-api-python-client/commit/e12ff0958ed9016356c8711039a15334d2f0d6f6 ([227f8c9](https://www.github.com/googleapis/google-api-python-client/commit/227f8c91ee006acb969a3950b7281e1deed14b69))
* **healthcare:** update the api https://github.com/googleapis/google-api-python-client/commit/6dd2d2112db14f6d0a9fca7c50480cdc81c7b48f ([e63d3a4](https://www.github.com/googleapis/google-api-python-client/commit/e63d3a43f29a5f8125272ce5303f869679963822))
* **retail:** update the api https://github.com/googleapis/google-api-python-client/commit/c9d7a149295d827110c789e464b4f97edc13cbaa ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/12683cabbf8deaf0a884147b98c30345786874a6 ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **servicedirectory:** update the api https://github.com/googleapis/google-api-python-client/commit/1a87cd4c32ff6145efb48dcbf12e644da1533f0b ([108b819](https://www.github.com/googleapis/google-api-python-client/commit/108b819d986cf2cdfcb3db643afa82949e33edc6))
* **servicemanagement:** update the api https://github.com/googleapis/google-api-python-client/commit/ac046117b12b43e03e748ebd0c442b340ed99183 ([227f8c9](https://www.github.com/googleapis/google-api-python-client/commit/227f8c91ee006acb969a3950b7281e1deed14b69))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/12d70c78040997c7354bcf66a0afe6b428d493d6 ([108b819](https://www.github.com/googleapis/google-api-python-client/commit/108b819d986cf2cdfcb3db643afa82949e33edc6))
* **servicenetworking:** update the api https://github.com/googleapis/google-api-python-client/commit/c0ad756013c602597e477bc0e22e7b2771689214 ([73a0aa3](https://www.github.com/googleapis/google-api-python-client/commit/73a0aa3b398baf73eb48101d81ca39fcb0edb254))
* **spanner:** update the api https://github.com/googleapis/google-api-python-client/commit/43f1be2ea175a79e463d77cf3155e7b8ab1b26f6 ([227f8c9](https://www.github.com/googleapis/google-api-python-client/commit/227f8c91ee006acb969a3950b7281e1deed14b69))

## [2.5.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.4.0...v2.5.0) (2021-05-20)


### Features

* **adexchangebuyer:** update the api https://github.com/googleapis/google-api-python-client/commit/46d87cb3e1f85ec9201134402b3c3afd2eb55770 ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/9648bae09873a132e7b4627096c153043911be6e ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **analyticsadmin:** update the api https://github.com/googleapis/google-api-python-client/commit/adaafffbdeab31f05f9ad62d0f58846313bb3858 ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **artifactregistry:** update the api https://github.com/googleapis/google-api-python-client/commit/7dd722fe8b0ae822f4847219c442aa67a1aae7fd ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **assuredworkloads:** update the api https://github.com/googleapis/google-api-python-client/commit/9b84ffce415133e860cc55bfbd3b9c15c3d46a24 ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **cloudasset:** update the api https://github.com/googleapis/google-api-python-client/commit/a8228db5ef31724493f0f62bf8062aca9adc44aa ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **cloudbuild:** update the api https://github.com/googleapis/google-api-python-client/commit/c9d8208c0f9579d958224566af369b809e13016a ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **compute:** update the api https://github.com/googleapis/google-api-python-client/commit/685c19d4b5262d27a2b1016e01186188afe610fd ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **container:** update the api https://github.com/googleapis/google-api-python-client/commit/c5cd244f996b1dfb605ef28eb22f8b0e76bffa1b ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **content:** update the api https://github.com/googleapis/google-api-python-client/commit/3b3e9be7e17c4efa89b45ac671a7c7f627a34cd7 ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/0c6b31fd2deb75ca1c023fed36903b638f5e74f8 ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **dialogflow:** update the api https://github.com/googleapis/google-api-python-client/commit/254b9413a2ede306917031a2117f7af2df28a103 ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **documentai:** update the api https://github.com/googleapis/google-api-python-client/commit/6dcec9fd8c0f803d37b4c8355870208e5a8c61ce ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **drive:** update the api https://github.com/googleapis/google-api-python-client/commit/8788823461610f31eebd655915e07def9690da48 ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **genomics:** update the api https://github.com/googleapis/google-api-python-client/commit/d0e6cc48df2d0a00d91ce6fbab83aa82146f3573 ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **logging:** update the api https://github.com/googleapis/google-api-python-client/commit/7f5fa161fd3db9ca6f2df23f5c8bd41ba01e9b9c ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **manufacturers:** update the api https://github.com/googleapis/google-api-python-client/commit/25bf19f14a09428ab3fc6e51b0f6812867f99b04 ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **privateca:** update the api https://github.com/googleapis/google-api-python-client/commit/0a5c31d74f788444640c174c413b12d494a00f1a ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **prod_tt_sasportal:** update the api https://github.com/googleapis/google-api-python-client/commit/af243b57a7039f4e01259fb085c7b07a66106fcf ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **pubsublite:** update the api https://github.com/googleapis/google-api-python-client/commit/dd67e9b117fdc8d0d0ecff6ade657003a95c12f7 ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **recommender:** update the api https://github.com/googleapis/google-api-python-client/commit/4b261d97bea2a8bc042a274c2d904be09da2d82c ([c2cd326](https://www.github.com/googleapis/google-api-python-client/commit/c2cd326ef156fc2652d23e4c64fd06e2d66e3a80))
* **redis:** update the api https://github.com/googleapis/google-api-python-client/commit/5228389cbd5fceb1bf8c2d36086faa147d91e50f ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))
* **remotebuildexecution:** update the api https://github.com/googleapis/google-api-python-client/commit/7c8b314e5508dda81cfb673039ea032f593fa97d ([7700bbf](https://www.github.com/googleapis/google-api-python-client/commit/7700bbffda386345cc4426ef413fc643f6368ef4))

## [2.4.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.3.0...v2.4.0) (2021-05-11)


### Features

* **alertcenter:** update the api ([cbf5364](https://www.github.com/googleapis/google-api-python-client/commit/cbf5364f32932e6dc0baebfb3787a9f2fc889819))
* **analyticsadmin:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **androidenterprise:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **androidpublisher:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **artifactregistry:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **bigquery:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **chromepolicy:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **content:** update the api ([c0b883a](https://www.github.com/googleapis/google-api-python-client/commit/c0b883a43d90c27153eb1d205d52cd5d8b66c39a))
* **datacatalog:** update the api ([e58efe8](https://www.github.com/googleapis/google-api-python-client/commit/e58efe85e5988c93399dd3cf5290620d67baf038))
* **dataproc:** update the api ([cbf5364](https://www.github.com/googleapis/google-api-python-client/commit/cbf5364f32932e6dc0baebfb3787a9f2fc889819))
* **dialogflow:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **dns:** update the api ([c0b883a](https://www.github.com/googleapis/google-api-python-client/commit/c0b883a43d90c27153eb1d205d52cd5d8b66c39a))
* **documentai:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **file:** update the api ([cbf5364](https://www.github.com/googleapis/google-api-python-client/commit/cbf5364f32932e6dc0baebfb3787a9f2fc889819))
* **file:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **firebasestorage:** update the api ([27f691d](https://www.github.com/googleapis/google-api-python-client/commit/27f691d2f256447a41f44c77175edd0f37dddbdc))
* **gameservices:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **gkehub:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **lifesciences:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **monitoring:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **mybusinessaccountmanagement:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **networkmanagement:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **oslogin:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **pubsublite:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **recommender:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **retail:** update the api ([cbf5364](https://www.github.com/googleapis/google-api-python-client/commit/cbf5364f32932e6dc0baebfb3787a9f2fc889819))
* **servicedirectory:** update the api ([44a6719](https://www.github.com/googleapis/google-api-python-client/commit/44a6719b9f0024df4f4a4640743015507dbd0e94))
* **servicemanagement:** update the api ([c0b883a](https://www.github.com/googleapis/google-api-python-client/commit/c0b883a43d90c27153eb1d205d52cd5d8b66c39a))
* **servicenetworking:** update the api ([bfa2f1c](https://www.github.com/googleapis/google-api-python-client/commit/bfa2f1caee54b6f6bc8760a1d20e7014e607bd7f))
* **translate:** update the api ([c0b883a](https://www.github.com/googleapis/google-api-python-client/commit/c0b883a43d90c27153eb1d205d52cd5d8b66c39a))


### Bug Fixes

* preventing accessing predefined discovery URLs when override is provided ([#1324](https://www.github.com/googleapis/google-api-python-client/issues/1324)) ([1c4d199](https://www.github.com/googleapis/google-api-python-client/commit/1c4d1998086d89238ca5d961bc1c8eee5685345c))

## [2.3.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.2.0...v2.3.0) (2021-04-28)


### Features

* **apigee:** update the api ([3fd11cb](https://www.github.com/googleapis/google-api-python-client/commit/3fd11cbfa43679d14be7f09d9cb071d82d156ffa))
* **dataflow:** update the api ([3fd11cb](https://www.github.com/googleapis/google-api-python-client/commit/3fd11cbfa43679d14be7f09d9cb071d82d156ffa))
* **dialogflow:** update the api ([3fd11cb](https://www.github.com/googleapis/google-api-python-client/commit/3fd11cbfa43679d14be7f09d9cb071d82d156ffa))
* **documentai:** update the api ([3fd11cb](https://www.github.com/googleapis/google-api-python-client/commit/3fd11cbfa43679d14be7f09d9cb071d82d156ffa))
* **healthcare:** update the api ([3fd11cb](https://www.github.com/googleapis/google-api-python-client/commit/3fd11cbfa43679d14be7f09d9cb071d82d156ffa))
* **osconfig:** update the api ([afea316](https://www.github.com/googleapis/google-api-python-client/commit/afea316d32842ecb9e7d626842d5926b0bf3e34f))
* **sqladmin:** update the api ([cec4393](https://www.github.com/googleapis/google-api-python-client/commit/cec4393b8e37e229f68b2233a2041db062c2a335))

## [2.2.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.1.0...v2.2.0) (2021-04-13)


### Features

* Adds support for errors.py to also use 'errors' for error_details  ([#1281](https://www.github.com/googleapis/google-api-python-client/issues/1281)) ([a5d2081](https://www.github.com/googleapis/google-api-python-client/commit/a5d20813e8d7589b0cec030c149748e53ea555a5))

## [2.1.0](https://www.github.com/googleapis/google-api-python-client/compare/v2.0.2...v2.1.0) (2021-03-31)


### Features

* add status_code property on http error handling ([#1185](https://www.github.com/googleapis/google-api-python-client/issues/1185)) ([db2a766](https://www.github.com/googleapis/google-api-python-client/commit/db2a766bbd976742f6ef10d721d8423c8ac9246d))


### Bug Fixes

* Change default of `static_discovery` when `discoveryServiceUrl` set ([#1261](https://www.github.com/googleapis/google-api-python-client/issues/1261)) ([3b4f2e2](https://www.github.com/googleapis/google-api-python-client/commit/3b4f2e243709132b5ca41a3c23853d5067dfb0ab))
* correct api version in oauth-installed.md ([#1258](https://www.github.com/googleapis/google-api-python-client/issues/1258)) ([d1a255f](https://www.github.com/googleapis/google-api-python-client/commit/d1a255fcbeaa36f615cede720692fea2b9f894db))
* fix .close() ([#1231](https://www.github.com/googleapis/google-api-python-client/issues/1231)) ([a9583f7](https://www.github.com/googleapis/google-api-python-client/commit/a9583f712d13c67aa282d14cd30e00999b530d7c))
* Resolve issue where num_retries would have no effect ([#1244](https://www.github.com/googleapis/google-api-python-client/issues/1244)) ([c518472](https://www.github.com/googleapis/google-api-python-client/commit/c518472e836c32ba2ff5e8480ab5a7643f722d46))


### Documentation

* Distinguish between public/private docs in 2.0 guide ([#1226](https://www.github.com/googleapis/google-api-python-client/issues/1226)) ([a6f1706](https://www.github.com/googleapis/google-api-python-client/commit/a6f17066caf6e911b7e94e8feab52fa3af2def1b))
* Update README to promote cloud client libraries ([#1252](https://www.github.com/googleapis/google-api-python-client/issues/1252)) ([22807c9](https://www.github.com/googleapis/google-api-python-client/commit/22807c92ce754ff3d60f240ec5c38de50c5b654b))

## [2.0.2](https://www.github.com/googleapis/google-api-python-client/compare/v2.0.1...v2.0.2) (2021-03-04)


### Bug Fixes

* Include discovery artifacts in published package ([#1221](https://www.github.com/googleapis/google-api-python-client/issues/1221)) ([ad618d0](https://www.github.com/googleapis/google-api-python-client/commit/ad618d0b266b86a795871d946367552905f4ccb6))

## [2.0.1](https://www.github.com/googleapis/google-api-python-client/compare/v2.0.0...v2.0.1) (2021-03-04)


### Bug Fixes

* add static discovery docs  ([#1216](https://www.github.com/googleapis/google-api-python-client/issues/1216)) ([b5d33d6](https://www.github.com/googleapis/google-api-python-client/commit/b5d33d6d520ca9589eefd08d34fe96844f420bce))


### Documentation

* add a link to the migration guide in the changelog ([#1213](https://www.github.com/googleapis/google-api-python-client/issues/1213)) ([b85da5b](https://www.github.com/googleapis/google-api-python-client/commit/b85da5bb7d6d6da60ff611221d3c4719eadb478a))

## [2.0.0](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.8...v2.0.0) (2021-03-03)


### ⚠ BREAKING CHANGES

The 2.0 release of `google-api-python-client` is a significant upgrade compared to v1. Please see the [Migration Guide](UPGRADING.md) for more information.

* **deps:** require 3.6+.  (#961)

### Features

* Add support for using static discovery documents ([#1109](https://www.github.com/googleapis/google-api-python-client/issues/1109)) ([32d1c59](https://www.github.com/googleapis/google-api-python-client/commit/32d1c597b364e2641eca33ccf6df802bb218eea1))
* Update synth.py to copy discovery files from discovery-artifact-manager ([#1104](https://www.github.com/googleapis/google-api-python-client/issues/1104)) ([af918e8](https://www.github.com/googleapis/google-api-python-client/commit/af918e8ef422438aaca0c468de8b3b2c184d884e))


### Bug Fixes

* Catch ECONNRESET and other errors more reliably ([#1147](https://www.github.com/googleapis/google-api-python-client/issues/1147)) ([ae9cd99](https://www.github.com/googleapis/google-api-python-client/commit/ae9cd99134160a5540e6f8d6d33d855122854e10))
* **deps:** add upper-bound google-auth dependency ([#1180](https://www.github.com/googleapis/google-api-python-client/issues/1180)) ([c687f42](https://www.github.com/googleapis/google-api-python-client/commit/c687f4207b9c574e539a7eab75201a58f2e91f35))
* handle error on service not enabled ([#1117](https://www.github.com/googleapis/google-api-python-client/issues/1117)) ([c691283](https://www.github.com/googleapis/google-api-python-client/commit/c6912836e88eea45aef7d515383e549082d37717))
* Improve support for error_details ([#1126](https://www.github.com/googleapis/google-api-python-client/issues/1126)) ([e6a1da3](https://www.github.com/googleapis/google-api-python-client/commit/e6a1da3542e230e5287863f339ce1d28292cd92f))
* MediaFileUpload error if file does not exist ([#1127](https://www.github.com/googleapis/google-api-python-client/issues/1127)) ([2c6d029](https://www.github.com/googleapis/google-api-python-client/commit/2c6d0297851c806ef850ca23686c51ca5878ac48))
* replace deprecated socket.error with OSError ([#1161](https://www.github.com/googleapis/google-api-python-client/issues/1161)) ([b7b9986](https://www.github.com/googleapis/google-api-python-client/commit/b7b9986fe13c483eeefb77673b4091911978ee46))
* Use logging level info when file_cache is not available ([#1125](https://www.github.com/googleapis/google-api-python-client/issues/1125)) ([0b32e69](https://www.github.com/googleapis/google-api-python-client/commit/0b32e69900eafec2cd1197ba054d4f9a765a3f29))


### Miscellaneous Chores

* **deps:** require 3.6+ ([#961](https://www.github.com/googleapis/google-api-python-client/issues/961)) ([8325d24](https://www.github.com/googleapis/google-api-python-client/commit/8325d24acaa2b2077acaaea26ea5fafb6dd856c5))


### Documentation

* add networkconnectivity v1alpha1 ([#1176](https://www.github.com/googleapis/google-api-python-client/issues/1176)) ([91b61d3](https://www.github.com/googleapis/google-api-python-client/commit/91b61d3272de9b5aebad0cf1eb76ca53c24f22f9))
* Delete redundant oauth-web.md ([#1142](https://www.github.com/googleapis/google-api-python-client/issues/1142)) ([70bc6c9](https://www.github.com/googleapis/google-api-python-client/commit/70bc6c9db99eed5af7536b87448bd9323db9320b))
* fix MediaIoBaseUpload broken link ([#1112](https://www.github.com/googleapis/google-api-python-client/issues/1112)) ([334b6e6](https://www.github.com/googleapis/google-api-python-client/commit/334b6e6d9e4924398e57bad2e53747584abf8cf4))
* fix regression with incorrect args order in docs ([#1141](https://www.github.com/googleapis/google-api-python-client/issues/1141)) ([4249a7b](https://www.github.com/googleapis/google-api-python-client/commit/4249a7b92e891d1ecaf93944ca9c062ffbd54f77))
* fix typo in thread safety example code ([#1100](https://www.github.com/googleapis/google-api-python-client/issues/1100)) ([5ae088d](https://www.github.com/googleapis/google-api-python-client/commit/5ae088dc027b89517b896a89a0aeb2ca80f492cf))
* Reduce noisy changes in docs regen ([#1135](https://www.github.com/googleapis/google-api-python-client/issues/1135)) ([b1b0c83](https://www.github.com/googleapis/google-api-python-client/commit/b1b0c83ae0737e7b63cb77e4e7757213a216b88e))
* update docs/dyn ([#1096](https://www.github.com/googleapis/google-api-python-client/issues/1096)) ([c2228be](https://www.github.com/googleapis/google-api-python-client/commit/c2228be4630e279e02a25b51566a0f93b67aa499))
* update guidance on service accounts ([#1120](https://www.github.com/googleapis/google-api-python-client/issues/1120)) ([b2ea122](https://www.github.com/googleapis/google-api-python-client/commit/b2ea122c40ccac09c9e7b0b29f6b2bcca6db107b))

## [1.12.8](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.7...v1.12.8) (2020-11-18)


### Documentation

* add httplib2 authorization to thread_safety ([#1005](https://www.github.com/googleapis/google-api-python-client/issues/1005)) ([205ae59](https://www.github.com/googleapis/google-api-python-client/commit/205ae5988bd89676823088d6c8a7bd17e3beefcf)), closes [#808](https://www.github.com/googleapis/google-api-python-client/issues/808) [#808](https://www.github.com/googleapis/google-api-python-client/issues/808)

## [1.12.7](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.6...v1.12.7) (2020-11-17)


### Documentation

* Update Webmasters API sample ([#1092](https://www.github.com/googleapis/google-api-python-client/issues/1092)) ([12831f3](https://www.github.com/googleapis/google-api-python-client/commit/12831f3e4716292b55b63dd2b08c3351f09b8a15))

## [1.12.6](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.5...v1.12.6) (2020-11-16)


### Documentation

* Change error parsing to check for 'message' ([#1083](https://www.github.com/googleapis/google-api-python-client/issues/1083)) ([a341c5a](https://www.github.com/googleapis/google-api-python-client/commit/a341c5a5e31ba16da109658127b58cb7e5dbeedd)), closes [#1082](https://www.github.com/googleapis/google-api-python-client/issues/1082)
* Update oauth docs to include snippet to get email address of authenticated user ([#1088](https://www.github.com/googleapis/google-api-python-client/issues/1088)) ([25fba64](https://www.github.com/googleapis/google-api-python-client/commit/25fba648ea647b62f2a6edc54ae927c1ed381b45)), closes [#1071](https://www.github.com/googleapis/google-api-python-client/issues/1071)

## [1.12.5](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.4...v1.12.5) (2020-10-22)


### Bug Fixes

* don't raise when downloading zero byte files ([#1074](https://www.github.com/googleapis/google-api-python-client/issues/1074)) ([86d8788](https://www.github.com/googleapis/google-api-python-client/commit/86d8788ee8a766ca6818620f3fd2899be0e44190))

## [1.12.4](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.3...v1.12.4) (2020-10-20)


### Bug Fixes

* don't set content-range on empty uploads ([#1070](https://www.github.com/googleapis/google-api-python-client/issues/1070)) ([af6035f](https://www.github.com/googleapis/google-api-python-client/commit/af6035f6754a155ee6b04bbbc5c39410c7316d6a))


### Documentation

* fix typo in oauth.md ([#1058](https://www.github.com/googleapis/google-api-python-client/issues/1058)) ([30eff9d](https://www.github.com/googleapis/google-api-python-client/commit/30eff9d8276919b8c4e50df2d3b1982594423692))
* update generated docs ([#1053](https://www.github.com/googleapis/google-api-python-client/issues/1053)) ([3e17f89](https://www.github.com/googleapis/google-api-python-client/commit/3e17f8990db54bec16c48c319072799a14f5a53f)), closes [#1049](https://www.github.com/googleapis/google-api-python-client/issues/1049)

## [1.12.3](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.2...v1.12.3) (2020-09-29)


### Bug Fixes

* **deps:** update setup.py to install httplib2>=0.15.0 ([#1050](https://www.github.com/googleapis/google-api-python-client/issues/1050)) ([c00f70d](https://www.github.com/googleapis/google-api-python-client/commit/c00f70d565a002b92374356be087927b131ce135))

## [1.12.2](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.1...v1.12.2) (2020-09-23)


### Bug Fixes

* add method to close httplib2 connections ([#1038](https://www.github.com/googleapis/google-api-python-client/issues/1038)) ([98888da](https://www.github.com/googleapis/google-api-python-client/commit/98888dadf04e7e00524b6de273d28d02d7abc2c0)), closes [#618](https://www.github.com/googleapis/google-api-python-client/issues/618) 

## [1.12.1](https://www.github.com/googleapis/google-api-python-client/compare/v1.12.0...v1.12.1) (2020-09-14)


### Bug Fixes

* **deps:** require six>=1.13.0 ([#1030](https://www.github.com/googleapis/google-api-python-client/issues/1030)) ([4acecc3](https://www.github.com/googleapis/google-api-python-client/commit/4acecc3c0cd31308f9a256f065b7b1d1c3a4798d))

## [1.12.0](https://www.github.com/googleapis/google-api-python-client/compare/v1.11.0...v1.12.0) (2020-09-12)


### Features

* add quota_project, credentials_file, and scopes support ([#1022](https://www.github.com/googleapis/google-api-python-client/issues/1022)) ([790e702](https://www.github.com/googleapis/google-api-python-client/commit/790e70224c8110bfb1191333ce448c2b0fe54ea6))


### Documentation

* convert `print` statement to function ([#988](https://www.github.com/googleapis/google-api-python-client/issues/988)) ([16448bc](https://www.github.com/googleapis/google-api-python-client/commit/16448bc666e032abd83096faadcda56f86f36f18)), closes [#987](https://www.github.com/googleapis/google-api-python-client/issues/987)
* remove http from batch execute docs ([#1003](https://www.github.com/googleapis/google-api-python-client/issues/1003)) ([5028fe7](https://www.github.com/googleapis/google-api-python-client/commit/5028fe76c8075c6594b1999074f91eed7f7dd329)), closes [#1002](https://www.github.com/googleapis/google-api-python-client/issues/1002)

## [1.11.0](https://www.github.com/googleapis/google-api-python-client/compare/v1.10.1...v1.11.0) (2020-08-27)


### Features

* add support for mtls env variables ([#1008](https://www.github.com/googleapis/google-api-python-client/issues/1008)) ([2fc5ca1](https://www.github.com/googleapis/google-api-python-client/commit/2fc5ca1b6aa880aab2067ab7eb96780a1b28d4c7))

## [1.10.1](https://www.github.com/googleapis/google-api-python-client/compare/v1.10.0...v1.10.1) (2020-08-03)


### Bug Fixes

* discovery uses V2 when version is None ([#975](https://www.github.com/googleapis/google-api-python-client/issues/975)) ([cd4e8f4](https://www.github.com/googleapis/google-api-python-client/commit/cd4e8f429422232dd82ef7e9bc685061d5df94a1)), closes [#971](https://www.github.com/googleapis/google-api-python-client/issues/971)


### Documentation

* fix deprecation warnings due to invalid escape sequences. ([#996](https://www.github.com/googleapis/google-api-python-client/issues/996)) ([0f60eda](https://www.github.com/googleapis/google-api-python-client/commit/0f60eda81ea524dcd1358d87b06da701412bb414)), closes [#995](https://www.github.com/googleapis/google-api-python-client/issues/995)
* fix link to service accounts documentation ([#986](https://www.github.com/googleapis/google-api-python-client/issues/986)) ([edb2516](https://www.github.com/googleapis/google-api-python-client/commit/edb2516eb59770546e7960ca633c7be0ca7b1ad4))
* update generated docs ([#981](https://www.github.com/googleapis/google-api-python-client/issues/981)) ([d059ad8](https://www.github.com/googleapis/google-api-python-client/commit/d059ad881c7ae58c67931c48788d0bd7343ab16c))

## [1.10.0](https://www.github.com/googleapis/google-api-python-client/compare/v1.9.3...v1.10.0) (2020-07-15)


### Features

* allow to use 'six.moves.collections_abc.Mapping' in 'client_options.from_dict()' ([#943](https://www.github.com/googleapis/google-api-python-client/issues/943)) ([21af37b](https://www.github.com/googleapis/google-api-python-client/commit/21af37b11ea2d6a89b3df484e1b2fa1d12849510))
* Build universal wheels ([#948](https://www.github.com/googleapis/google-api-python-client/issues/948)) ([3e28a1e](https://www.github.com/googleapis/google-api-python-client/commit/3e28a1e0d47f829182cd92f37475ab91fa5e4afc))
* discovery supports retries ([#967](https://www.github.com/googleapis/google-api-python-client/issues/967)) ([f3348f9](https://www.github.com/googleapis/google-api-python-client/commit/f3348f98bf91a88a28bf61b12b95e391cc3be1ff)), closes [#848](https://www.github.com/googleapis/google-api-python-client/issues/848)


### Documentation

* consolidating and updating the Contribution Guide ([#964](https://www.github.com/googleapis/google-api-python-client/issues/964)) ([63f97f3](https://www.github.com/googleapis/google-api-python-client/commit/63f97f37daee37a725eb05df3097b20d5d4eaaf0)), closes [#963](https://www.github.com/googleapis/google-api-python-client/issues/963)

## [1.9.3](https://www.github.com/googleapis/google-api-python-client/compare/v1.9.2...v1.9.3) (2020-06-10)


### Bug Fixes

* update GOOGLE_API_USE_MTLS values ([#940](https://www.github.com/googleapis/google-api-python-client/issues/940)) ([19908ed](https://www.github.com/googleapis/google-api-python-client/commit/19908edcd8a3df1db41e34100acc1f15c3c99397))

## [1.9.2](https://www.github.com/googleapis/google-api-python-client/compare/v1.9.1...v1.9.2) (2020-06-04)


### Bug Fixes

* bump api-core version ([#936](https://www.github.com/googleapis/google-api-python-client/issues/936)) ([ee53b3b](https://www.github.com/googleapis/google-api-python-client/commit/ee53b3b32a050874ba4cfb491fb384f94682c824))

## [1.9.1](https://www.github.com/googleapis/google-api-python-client/compare/v1.9.0...v1.9.1) (2020-06-02)


### Bug Fixes

* fix python-api-core dependency issue ([#931](https://www.github.com/googleapis/google-api-python-client/issues/931)) ([42028ed](https://www.github.com/googleapis/google-api-python-client/commit/42028ed2b2be47f85b70eb813185264f1f573d01))

## [1.9.0](https://www.github.com/googleapis/google-api-python-client/compare/v1.8.4...v1.9.0) (2020-06-02)


### Features

* add mtls feature ([#917](https://www.github.com/googleapis/google-api-python-client/issues/917)) ([981eadf](https://www.github.com/googleapis/google-api-python-client/commit/981eadf7cfdb576981d92fcda498c76422821426))
* add templates for python samples projects ([#506](https://www.github.com/googleapis/google-api-python-client/issues/506)) ([#924](https://www.github.com/googleapis/google-api-python-client/issues/924)) ([c482712](https://www.github.com/googleapis/google-api-python-client/commit/c482712935d1c1331e33bd7f9968bd3b2be223bb))

## [1.8.4](https://www.github.com/googleapis/google-api-python-client/compare/v1.8.3...v1.8.4) (2020-05-20)


### Bug Fixes

* don't try to import GAE API in other environments ([#903](https://www.github.com/googleapis/google-api-python-client/issues/903)) ([09e6447](https://www.github.com/googleapis/google-api-python-client/commit/09e644719166aecb21a01b6d5ee9898843e7cd58))
* the turn down date for global batch uri ([#901](https://www.github.com/googleapis/google-api-python-client/issues/901)) ([6ddadd7](https://www.github.com/googleapis/google-api-python-client/commit/6ddadd7753134c671628ad3f4598595b0abb1457))

## [1.8.3](https://www.github.com/googleapis/google-api-python-client/compare/v1.8.2...v1.8.3) (2020-05-01)


### Bug Fixes

* downgrade repetitive logging calls to debug ([#885](https://www.github.com/googleapis/google-api-python-client/issues/885)) ([3bf2781](https://www.github.com/googleapis/google-api-python-client/commit/3bf2781e29cb828409f3a8a21939323286524569)), closes [#781](https://www.github.com/googleapis/google-api-python-client/issues/781)

## [1.8.2](https://www.github.com/googleapis/google-api-python-client/compare/v1.8.1...v1.8.2) (2020-04-21)


### Bug Fixes

* Remove `apiclient.__version__` ([#871](https://www.github.com/googleapis/google-api-python-client/issues/871)) ([c7516a2](https://github.com/googleapis/google-api-python-client/commit/1d8ec6874e1c6081893de7cd7cbc86d1f6580320d)), closes [googleapis#870](https://www.github.com/googleapis/googleapis/issues/870)


## [1.8.1](https://www.github.com/googleapis/google-api-python-client/compare/v1.8.0...v1.8.1) (2020-04-20)


### Bug Fixes

* Adding ConnectionError to retry mechanism ([#822](https://www.github.com/googleapis/google-api-python-client/issues/822)) ([c7516a2](https://www.github.com/googleapis/google-api-python-client/commit/c7516a2ea2c229479633690c109f8763dc0b30ed)), closes [googleapis#558](https://www.github.com/googleapis/googleapis/issues/558)
* replace '-' in method names with '_' ([#863](https://www.github.com/googleapis/google-api-python-client/issues/863)) ([8ed729f](https://www.github.com/googleapis/google-api-python-client/commit/8ed729f1d868a8713ab442bf0bf59e77ba36afb6))

### v1.8.0
  Version 1.8.0

  Release to support API endpoint override.

  New Features
  - Add api endpoint override. ([#829](https://github.com/googleapis/google-api-python-client/pull/829))

  Implementation Changes
  - Don't set http.redirect_codes if the attr doesn't exist and allow more httplib2 versions. ([#841](https://github.com/googleapis/google-api-python-client/pull/841))

### v1.7.12
  Version 1.7.12
  
  Bugfix release
  
  Implementation Changes
  - Look for field 'detail' in error message. ([#739](https://github.com/googleapis/google-api-python-client/pull/739))
  - Exclude 308s from httplib2 redirect codes list ([#813](https://github.com/googleapis/google-api-python-client/pull/813))
  
  Documentation 
  - Remove oauth2client from docs ([#738](https://github.com/googleapis/google-api-python-client/pull/738))
  - Fix typo. ([#745](https://github.com/googleapis/google-api-python-client/pull/745))
  - Remove compatibility badges. ([#746](https://github.com/googleapis/google-api-python-client/pull/746))
  - Fix TypeError: search_analytics_api_sample.py #732 ([#742](https://github.com/googleapis/google-api-python-client/pull/742))
  - Correct response access ([#750](https://github.com/googleapis/google-api-python-client/pull/750))
  - Fix link to API explorer ([#760](https://github.com/googleapis/google-api-python-client/pull/760))
  - Fix argument typo in oauth2 code example ([#763](https://github.com/googleapis/google-api-python-client/pull/763))
  - Recommend install with virtualenv ([#768](https://github.com/googleapis/google-api-python-client/pull/768))
  - Fix capitalization in docs/README.md ([#770](https://github.com/googleapis/google-api-python-client/pull/770))

  - Remove compatibility badges ([#796](https://github.com/googleapis/google-api-python-client/pull/796))
  - Remove mentions of pycrypto ([#799](https://github.com/googleapis/google-api-python-client/pull/799))
  - Fix typo in model.py
  - Add note about Google Ads llibrary ([#814](https://github.com/googleapis/google-api-python-client/pull/814))

  
  Internal / Testing Changes
  - Blacken ([#772](https://github.com/googleapis/google-api-python-client/pull/722))
  - Move kokoro configs ([#832](https://github.com/googleapis/google-api-python-client/pull/832))
  
### v1.7.11
  Version 1.7.11

  Bugfix release

  Implementation Changes
  - Pass library and Python version in x-goog-api-client header ([#734](https://github.com/googleapis/google-api-python-client/pull/734))

  Documentation
  - Fix typo in filename used in 'docs/auth.md' ([#736](https://github.com/googleapis/google-api-python-client/pull/736))

  
### v1.7.10
  Version 1.7.10

  Bugfix release

  Implementation Changes
  - Decode service to utf-8 ([#723](https://github.com/googleapis/google-api-python-client/pull/723))
  - Use print() function in both Python2 and Python 3 ([#722](https://github.com/googleapis/google-api-python-client/pull/722))
  - Make http.MediaFileUpload close its file descriptor ([#600](https://github.com/googleapis/google-api-python-client/pull/600))
  - Never make 'body' required ([#718](https://github.com/googleapis/google-api-python-client/pull/718))

  Documentation
  - Add compatability check badges to README ([#691](https://github.com/googleapis/google-api-python-client/pull/691))
  - Regenerate docs ([#696](https://github.com/googleapis/google-api-python-client/pull/696), [#700](https://github.com/googleapis/google-api-python-client/pull/700))
  - Create index file for dynamically generated docs ([#702](https://github.com/googleapis/google-api-python-client/pull/702))
  - Add docs folder with guides from developers.google.com ([#706](https://github.com/googleapis/google-api-python-client/pull/706), [#710](https://github.com/googleapis/google-api-python-client/pull/710))

  Internal / Testing Changes
  - Fix http.py, lint errors, unit test ([#724](https://github.com/googleapis/google-api-python-client/pull/724))
  - tox.ini: Look for Python syntax errors and undefined names ([#721](https://github.com/googleapis/google-api-python-client/pull/721))


### v1.7.9
  Version 1.7.9

  Bugfix release
  - Remove Django Samples. ([#657](https://github.com/googleapis/google-api-python-client/pull/657))
  - Call request_orig with kwargs ([#658](https://github.com/googleapis/google-api-python-client/pull/658))

### v1.7.8
  Version 1.7.8

  Bugfix release
  - Convert '$' in method name to '_' ([#616](https://github.com/googleapis/google-api-python-client/pull/616))
  - Alias unitest2 import as unittest in test__auth.py ([#613](https://github.com/googleapis/google-api-python-client/pull/613))

### v1.7.7
  Version 1.7.7

    Bugfix release
    - Change xrange to range ([#601](https://github.com/googleapis/google-api-python-client/pull/601))
    - Typo in http.py exception message. ([#602](https://github.com/googleapis/google-api-python-client/pull/602))

    - Announce deprecation of Python 2.7 ([#603](https://github.com/googleapis/google-api-python-client/pull/603))
    - Updates documentation for stopping channel subscriptions ([#598](https://github.com/googleapis/google-api-python-client/pull/598))
    - Adding example for searchAppearance ([#414](https://github.com/googleapis/google-api-python-client/pull/414))

    - Add badges ([#455](https://github.com/googleapis/google-api-python-client/pull/455))

### v1.7.6
  Version 1.7.6

  Bugfix release

  - Add client-side limit for batch requests (#585)

### v1.7.5
  Version 1.7.5

  Bugfix release

  - Fix the client to respect the passed in developerKey and credentials

### v1.7.4
  Version 1.7.4

  Bugfix release

  - Catch ServerNotFoundError to retry the request (#532)

### v1.7.3
  Version 1.7.3

  Bugfix release

  - Make apiclient.sample_tools gracefully fail to import (#525).


### v1.7.2
  Version 1.7.2

  Bugfix release

  - Remove unnecessary check in apiclient/__ini__.py (#522).

### v1.7.1
  Version 1.7.1

  Bugfix release

  - Remove unnecessary check in setup.py (#518).

### v1.7.0
  Version 1.7.0

  This release drops the hard requirement on oauth2client and installs
  google-auth by default instead. oauth2client is still supported but will
  need to be explicitly installed.

  - Drop oauth2client dependency (#499)
  - Include tests in source distribution (#514)

### v1.6.7
  Version 1.6.7

  Bugfix release

  **Note**: The next release of this library will no longer directly depend on
    oauth2client. If you need to use oauth2client, you'll need to explicitly
    install it.

  - Make body optional for requests with no parameters. (#446)
  - Fix retying on socket.timeout. (#495)
  - Match travis matrix with tox testenv. (#498)
  - Remove oauth2client._helpers dependency. (#493)
  - Remove unused keyring test dependency. (#496)
  - discovery.py: remove unused oauth2client import. (#492)
  - Update README to reference GCP API client libraries. (#490)

### v1.6.6
  Version 1.6.6

  Bugfix release

  - Warn when constructing BatchHttpRequest using the legacy batch URI (#488)
  - Increase the default media chunksize to 100MB. (#482)
  - Remove unnecessary parsing of mime headers in HttpRequest.__init__ (#467)

### v1.6.5
  Version 1.6.5

  Bugfix release

  - Proactively refresh credentials when applying and treat a missing
    `access_token` as invalid. Note: This change reveals surprising behavior
    between default credentials and batches. If you allow
    `googleapiclient.discovery.build` to use default credentials *and* specify
    different credentials by providing `batch.execut()` with an explicit `http`
    argument, your individual requests will use the default credentials and
    *not* the credentials specified to the batch http. To avoid this, tell
    `build` explicitly not to use default credentials by specifying
    `build(..., http=httplib2.Http()`. (#469)
  - Remove mutual exclusivity check for developerKey and credentials (#465)
  - Handle unknown media length. (#406)
  - Handle variant error format gracefully. (#459)
  - Avoid testing against Django >= 2.0.0 on Python 2. (#460)

### v1.6.4
  Version 1.6.4

  Bugfix release

  - Warn when google-auth credentials are used but google-auth-httplib2 isn't available. (#443)

### v1.6.3
  Version 1.6.3

  Bugfix release

  - Add notification of maintenance mode to README. (#410)
  - Fix generation of methods with abnormal page token conventions. (#338)
  - Raise ValueError is credentials and developerKey are both specified. (#358)
  - Re-generate documentation. (#364, #373, #401)
  - Fix method signature documentation for multiline required parameters. (#374)
  - Fix ZeroDivisionError in MediaDownloadProgress.progress. (#377)
  - Fix dead link to WebTest in README. (#378)
  - Fix details missing in googleapiclient.errors.HttpError. (#412)
  - Don't treat httplib2.Credentials as oauth credentials. (#425)
  - Various fixes to the Django sample. (#413)

### v1.6.2
  Version 1.6.2

  Bugfix release

  - Fixed a bug where application default credentials would still be used even
    when a developerKey was specified. (#347)
  - Official support for Python 3.5 and 3.6. (#341)
 
### v1.6.1
  Version 1.6.1

  Bugfix release

  - Fixed a bug where using google-auth with scoped credentials would fail. (#328)

### v1.6.0
  Version 1.6.0

  Release to drop support for Python 2.6 and add support for google-auth.

  - Support for Python 2.6 has been dropped. (#319)
  - The credentials argument to discovery.build and discovery.build_from_document
    can be either oauth2client credentials or google-auth credentials. (#319)
  - discovery.build and discovery.build_from_document now unambiguously use the
    http argument to make all requests, including the request for the discovery
    document. (#319)
  - The http and credentials arguments to discovery.build and
    discovery.build_from_document are now mutually exclusive, eliminating a
    buggy edge case. (#319)
  - If neither http or credentials is specified to discovery.build and
    discovery.build_from_document, then Application Default Credentials will
    be used. The library prefers google-auth for this if it is available, but
    can also use oauth2client's implementation. (#319)
  - Fixed resumable upload failure when receiving a 308 response. (#312)
  - Clarified the support versions of Python 3. (#316)

### v1.5.5
  Version 1.5.5

  Bugfix release

  - Allow explicit MIME type specification with media_mime_type keyword argument.
  - Fix unprintable representation of BatchError with default constructor. (#165)
  - Refresh all discovery docs, not just the preferred ones. (#298)
  - Update minimum httplib2 dependency to >=0.9.2.

### v1.5.4
  Version 1.5.4

  Bugfix release

  - Properly handle errors when the API returns a mapping or sequence. (#289)
  - Upgrade to unified uritemplate 3.0.0. (#293)
  - Allow oauth2client 4.0.0, with the caveat that file-based discovery
    caching is disabled.

### v1.5.3
  Version 1.5.3

  Bugfix release

  - Fixed import error with oauth2client >= 3.0.0. (#270)

### v1.5.2
  Version 1.5.2

  Bugfix release

  - Allow using oauth2client >= 1.5.0, < 4.0.0. (#265)
  - Fix project_id argument description. (#257)
  - Retry chunk uploaded on rate limit exceeded errors. (#255)
  - Obtain access token if necessary in BatchHttpRequest.execute(). (#232)
  - Warn when running tests using HttpMock without having a cache. (#261)

### v1.5.1
  Version 1.5.1

  Bugfix release

  - Allow using versions of oauth2client < 2.0.0. (#197)
  - Check both current and new API discovery URL. (#202)
  - Retry http requests on connection errors and timeouts. (#218)
  - Retry http requests on rate limit responses. (#201)
  - Import guards for ssl (for Google App Engine). (#220)
  - Use named loggers instead of the root logger. (#206)
  - New search console example. (#212)

### v1.5.0
  Version 1.5.0

  Release to support oauth2client >= 2.0.0.

  - Fix file stream recognition in Python 3 (#141)
  - Fix non-resumable binary uploads in Python 3 (#147)
  - Default to 'octet-stream' if mimetype detection fails (#157)
  - Handle SSL errors with retries (#160)
  - Fix incompatibility with oauth2client v2.0.0 (#182)

### v1.4.2
  Version 1.4.2

  Add automatic caching for the discovery docs.

### v1.4.1
  Version 1.4.1

  Add the googleapiclient.discovery.Resource.new_batch_http_request method.

### v1.4.0
  Version 1.4.0

  Python 3 support.

### v1.3.2
  Version 1.3.2

  Small bugfix release.

  - Fix an infinite loop for downloading small files.
  - Fix a unicode error in error encoding.
  - Better handling of `content-length` in media requests.
  - Add support for methodPath entries containing colon.

### v1.3.1
  Version 1.3.1

  Quick release for a fix around aliasing in v1.3.

### v1.3
  Version 1.3

  Add support for the Google Application Default Credentials.
  Require python 2.6 as a minimum version.
  Update several API samples.
  Finish splitting out oauth2client repo and update tests.
  Various doc cleanup and bugfixes.

  Two important notes:
    * We've added `googleapiclient` as the primary suggested import
      name, and kept `apiclient` as an alias, in order to have a more
      appropriate import name. At some point, we will remove `apiclient`
      as an alias.
    * Due to an issue around in-place upgrades for Python packages,
      it's not possible to do an upgrade from version 1.2 to 1.3. Instead,
      setup.py attempts to detect this and prevents it. Simply remove
      the previous version and reinstall to fix this.

### v1.2
  Version 1.2

  The use of the gflags library is now deprecated, and is no longer a
    dependency. If you are still using the oauth2client.tools.run() function
    then include gflags as a dependency of your application or switch to
    oauth2client.tools.run_flow.
  Samples have been updated to use the new apiclient.sample_tools, and no
    longer use gflags.
  Added support for the experimental Object Change Notification, as found in
    the Cloud Storage API.
  The oauth2client App Engine decorators are now threadsafe.

  - Use the following redirects feature of httplib2 where it returns the
    ultimate URL after a series of redirects to avoid multiple hops for every
    resumable media upload request.
  - Updated AdSense Management API samples to V1.3
  - Add option to automatically retry requests.
  - Ability to list registered keys in multistore_file.
  - User-agent must contain (gzip).
  - The 'method' parameter for httplib2 is not positional. This would cause
    spurious warnings in the logging.
  - Making OAuth2Decorator more extensible. Fixes Issue 256.
  - Update AdExchange Buyer API examples to version v1.2.


### v1.1
  Version 1.1

  Add PEM support to SignedJWTAssertionCredentials (used to only support
  PKCS12 formatted keys). Note that if you use PEM formatted keys you can use
  PyCrypto 2.6 or later instead of OpenSSL.

  Allow deserialized discovery docs to be passed to build_from_document().

  - Make ResumableUploadError derive from HttpError.
  - Many changes to move all the closures in apiclient.discovery into real
  -  classes and objects.
  - Make from_json behavior inheritable.
  - Expose the full token response in OAuth2Client and OAuth2Decorator.
  - Handle reasons that are None.
  - Added support for NDB based storing of oauth2client objects.
  - Update grant_type for AssertionCredentials.
  - Adding a .revoke() to Credentials. Closes issue 98.
  - Modify oauth2client.multistore_file to store and retrieve credentials
    using an arbitrary key.
  - Don't accept 403 challenges by default for auth challenges.
  - Set httplib2.RETRIES to 1.
  - Consolidate handling of scopes.
  - Upgrade to httplib2 version 0.8.
  - Allow setting the response_type in OAuth2WebServerFlow.
  - Ensure that dataWrapper feature is checked before using the 'data' value.
  - HMAC verification does not use a constant time algorithm.

### v1.0
 Version 1.0

  - Changes to the code for running tests and building releases.

### v1.0c3
 Version 1.0 Release Candidate 3

  - In samples and oauth2 decorator, escape untrusted content before displaying it.
  - Do not allow credentials files to be symlinks.
  - Add XSRF protection to oauth2decorator callback 'state'.
  - Handle uploading chunked media by stream.
  - Handle passing streams directly to httplib2.
  - Add support for Google Compute Engine service accounts.
  - Flows no longer need to be saved between uses.
  - Change GET to POST if URI is too long. Fixes issue #96.
  - Add a keyring based Storage.
  - More robust picking up JSON error responses.
  - Make batch errors align with normal errors.
  - Add a Google Compute sample.
  - Token refresh to work with 'old' GData API
  - Loading of client_secrets JSON file backed by a cache.
  - Switch to new discovery path parameters.
  - Add support for additionalProperties when printing schema'd objects.
  - Fix media upload parameter names. Reviewed in http://codereview.appspot.com/6374062/
  - oauth2client support for URL-encoded format of exchange token response (e.g.  Facebook)
  - Build cleaner and easier to read docs for dynamic surfaces.

### v1.0c2
 Version 1.0 Release Candidate 2

  - Parameter values of None should be treated as missing. Fixes issue #144.
  - Distribute the samples separately from the library source. Fixes issue #155.
  - Move all remaining samples over to client_secrets.json. Fixes issue #156.
  - Make locked_file.py understand win32file primitives for better awesomeness.

### v1.0c1
 Version 1.0 Release Candidate 1

 - Documentation for the library has switched to epydoc:
     http://google-api-python-client.googlecode.com/hg/docs/epy/index.html
 - Many improvements for media support:
   * Added media download support, including resumable downloads.
   * Better handling of streams that report their size as 0.
   * Update Media Upload to include io.Base and also fix some bugs.
 - OAuth bug fixes and improvements.
   * Remove OAuth 1.0 support.
   * Added credentials_from_code and credentials_from_clientsecrets_and_code.
   * Make oauth2client support Windows-friendly locking.
   * Fix bug in StorageByKeyName.
   * Fix None handling in Django fields. Reviewed in http://codereview.appspot.com/6298084/. Fixes issue #128.
 - Add epydoc generated docs. Reviewed in http://codereview.appspot.com/6305043/
 - Move to PEP386 compliant version numbers.
 - New and updated samples
   * Ad Exchange Buyer API v1 code samples.
   * Automatically generate Samples wiki page from README files.
   * Update Google Prediction samples.
   * Add a Tasks sample that demonstrates Service accounts.
   * new analytics api samples. Reviewed here: http://codereview.appspot.com/5494058/
 - Convert all inline samples to the Farm API for consistency.

### v1.0beta8
 - Updated meda upload support.
 - Many fixes for batch requests.
 - Better handling for requests that don't require a body.
 - Fix issues with Google App Engine Python 2.7 runtime.
 - Better support for proxies.
 - All Storages now have a .delete() method.
 - Important changes which might break your code:
    * apiclient.anyjson has moved to oauth2client.anyjson.
    * Some calls, for example, taskqueue().lease() used to require a parameter
      named body. In this new release only methods that really need to send a body
      require a body parameter, and so you may get errors about an unknown
      'body' parameter in your call. The solution is to remove the unneeded
      body={} parameter.

### v1.0beta7
 - Support for batch requests.  http://code.google.com/p/google-api-python-client/wiki/Batch
 - Support for media upload.  http://code.google.com/p/google-api-python-client/wiki/MediaUpload
 - Better handling for APIs that return something other than JSON.
 - Major cleanup and consolidation of the samples.
 - Bug fixes and other enhancements:
   72  Defect  Appengine OAuth2Decorator: Convert redirect address to string
   22  Defect  Better error handling for unknown service name or version
   48  Defect  StorageByKeyName().get() has side effects
   50  Defect  Need sample client code for Admin Audit API
   28  Defect  better comments for app engine sample   Nov 9
   63  Enhancement Let OAuth2Decorator take a list of scope
