#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void do_the_thing_with_export_name(void);

#ifdef __cplusplus
}  // extern "C"
#endif  // __cplusplus
