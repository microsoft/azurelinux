#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

void do_the_thing_with_export_name();

}  // extern "C"
