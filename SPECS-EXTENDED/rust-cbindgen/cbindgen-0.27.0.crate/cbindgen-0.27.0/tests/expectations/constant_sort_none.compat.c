#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#define B 0

#define A 0

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern const uint8_t D;

extern const uint8_t C;

#ifdef __cplusplus
}  // extern "C"
#endif  // __cplusplus
