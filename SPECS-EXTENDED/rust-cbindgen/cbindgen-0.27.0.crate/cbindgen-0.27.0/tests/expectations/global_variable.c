#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

extern char MUT_GLOBAL_ARRAY[128];

extern const char CONST_GLOBAL_ARRAY[128];
